import { getStore } from '@netlify/blobs';
import { verifyAuth } from './lib/auth.mjs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    await verifyAuth(req);

    const { productId, questionDate, answer } = await req.json();

    if (!productId || !questionDate || !answer) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const store = getStore('questions');
    const updateTime = new Date().toISOString();

    // 1. Update Global All Questions
    const globalData = await store.get('all-questions');
    let globalQuestions;
    
    if (globalData) {
        globalQuestions = JSON.parse(globalData);
    } else {
         // Migration: Try to get data from legacy 'global-recent'
         const legacyData = await store.get('global-recent');
         globalQuestions = legacyData ? JSON.parse(legacyData) : [];
    }

    let updatedGlobal = false;

    globalQuestions = globalQuestions.map(q => {
      // Compare dates (assuming unique enough) and productId
      if (q.productId === productId && q.date === questionDate) {
        updatedGlobal = true;
        return { ...q, answer, answeredAt: updateTime, answered: true };
      }
      return q;
    });

    if (updatedGlobal) {
        await store.set('all-questions', JSON.stringify(globalQuestions));
    }

    // 2. Update Product Specific
    const productData = await store.get(`product-${productId}`);
    let productQuestions = productData ? JSON.parse(productData) : [];
    let updatedProduct = false;

    productQuestions = productQuestions.map(q => {
      if (q.date === questionDate) { // Product ID is implicit
         updatedProduct = true;
         return { ...q, answer, answeredAt: updateTime, answered: true };
      }
      return q;
    });

    if (updatedProduct) {
        await store.set(`product-${productId}`, JSON.stringify(productQuestions));
    }

    if (!updatedGlobal && !updatedProduct) {
        return new Response(JSON.stringify({ error: 'Question not found' }), {
            status: 404,
            headers: { 'Content-Type': 'application/json' }
        });
    }

    return new Response(JSON.stringify({ 
      success: true,
      message: 'Answer submitted successfully'
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error answering question:', error);
    const status = error.message.includes('Unauthorized') || error.message.includes('Forbidden') ? 401 : 500;
    return new Response(JSON.stringify({ 
      error: error.message || 'Failed to answer question'
    }), {
      status: status,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

export const config = {
  path: '/api/admin/answer-question'
};
