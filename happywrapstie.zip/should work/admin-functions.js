let adminQuestionsCache = [];
let adminOrdersCache = [];

function getAuthHeaders() {
    if (typeof netlifyIdentity !== 'undefined' && netlifyIdentity.currentUser()) {
        return { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${netlifyIdentity.currentUser().token.access_token}`
        };
    }
    // Custom auth relies on HttpOnly cookie
    return {
        'Content-Type': 'application/json'
    };
}

function checkAdminRole(user) {
    const roles = user?.app_metadata?.roles || [];
    const isNetlifyAdmin = roles.includes('admin');
    const isCustomAdmin = user.isAdmin === true || user.email === 'killerskull913@gmail.com';
    
    if (isNetlifyAdmin || isCustomAdmin) {
        const adminTabBtn = document.getElementById('adminTabBtn');
        if (adminTabBtn) {
            adminTabBtn.style.display = 'block';
        }
        
        setupAdminPanel();
    }
}

async function setupAdminPanel() {
    await loadAdminUsers();
    await loadAdminOrders();
    await loadAdminQuestions();
    await loadAdminReviews();
    await loadAdminCompletedOrders();
    setupQAFilters();
}

// Add Reviews Management
let adminReviewsCache = [];

async function loadAdminReviews() {
    try {
        const response = await fetch('/api/get-reviews'); // Gets global recent by default
        const data = await response.json();
        
        if (response.ok && data.reviews) {
            adminReviewsCache = data.reviews;
            renderAdminReviews(data.reviews);
        }
    } catch (error) {
        console.error('Error loading admin reviews:', error);
    }
}

function renderAdminReviews(reviews) {
    let reviewsList = document.getElementById('adminReviewsList');
    
    if (!reviewsList) {
        const dashboard = document.querySelector('.admin-dashboard');
        if (dashboard) {
            const card = document.createElement('div');
            card.className = 'admin-card admin-full-width';
            card.innerHTML = `
                <h3>Recent Reviews</h3>
                <div id="adminReviewsList" class="admin-list-container"></div>
            `;
            dashboard.appendChild(card);
            reviewsList = document.getElementById('adminReviewsList');
        } else {
            return;
        }
    }
    
    if (reviews.length === 0) {
        reviewsList.innerHTML = '<p style="text-align: center; color: var(--gray); padding: 20px;">No reviews found.</p>';
        return;
    }
    
    reviewsList.innerHTML = reviews.map(r => {
        return `
            <div class="admin-qa-item">
                <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 10px;">
                    <div>
                        <strong style="color: var(--primary-color);">${r.userName}</strong>
                        <div style="color: #fbbf24;">${'★'.repeat(r.rating)}${'☆'.repeat(5-r.rating)}</div>
                        ${r.productName ? `<small style="color: var(--gray);">On: ${r.productName}</small>` : ''}
                    </div>
                    <div style="display: flex; flex-direction: column; align-items: flex-end; gap: 5px;">
                        <span style="color: var(--gray); font-size: 12px;">${new Date(r.date).toLocaleDateString()}</span>
                        <button class="btn btn-sm btn-danger" onclick="deleteReview('${r.id}', '${r.productId}', '${r.date}')" style="padding: 4px 8px; font-size: 11px;">🗑️ Delete</button>
                    </div>
                </div>
                <p style="margin: 10px 0; color: var(--dark);">${r.text || r.comment || ''}</p>
            </div>
        `;
    }).join('');
}

window.deleteReview = async function(reviewId, productId, reviewDate) {
    if(!confirm('Are you sure you want to delete this review? This cannot be undone.')) return;

    try {
        const response = await fetch('/api/admin/delete-review', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify({ reviewId, productId, reviewDate })
        });

        if (response.ok) {
            showNotification('Success', 'Review deleted successfully', 'success');
            await loadAdminReviews();
        } else {
            const data = await response.json();
            showNotification('Error', data.error || 'Failed to delete review', 'error');
        }
    } catch (error) {
        console.error('Error deleting review:', error);
        showNotification('Error', 'An error occurred', 'error');
    }
};


async function loadAdminUsers() {
    try {
        const response = await fetch('/api/admin/get-users', {
            method: 'GET',
            headers: getAuthHeaders()
        });
        
        const data = await response.json();
        
        if (response.ok && data.users) {
            renderAdminUsers(data.users);
        } else if (data.error) {
             console.error('Error loading admin users:', data.error);
             const usersList = document.getElementById('adminUsersList');
             if (usersList) usersList.innerHTML = `<p style="text-align: center; color: #ef4444; padding: 20px;">Error: ${data.error}</p>`;
        }
    } catch (error) {
        console.error('Error loading admin users:', error);
    }
}

function renderAdminUsers(users) {
    const usersList = document.getElementById('adminUsersList');
    if (!usersList) return;
    
    if (users.length === 0) {
        usersList.innerHTML = '<p style="text-align: center; color: var(--gray); padding: 20px;">No users found.</p>';
        return;
    }
    
    const tableHTML = `
        <table style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr style="border-bottom: 2px solid var(--border); text-align: left;">
                    <th style="padding: 12px;">Email</th>
                    <th style="padding: 12px;">Name</th>
                    <th style="padding: 12px;">Status</th>
                    <th style="padding: 12px;">Role</th>
                    <th style="padding: 12px;">Actions</th>
                </tr>
            </thead>
            <tbody>
                ${users.map(user => {
                    const isBanned = user.app_metadata?.banned === true;
                    // Check logic compatible with both Netlify and Custom
                    const isAdmin = (user.app_metadata?.roles?.includes('admin')) || (user.isAdmin === true) || (user.email === 'killerskull913@gmail.com');
                    const isActive = user.last_sign_in_at && (Date.now() - new Date(user.last_sign_in_at).getTime()) < 300000;
                    
                    return `
                        <tr style="border-bottom: 1px solid var(--border);">
                            <td style="padding: 12px;">${user.email}</td>
                            <td style="padding: 12px;">${user.user_metadata?.full_name || 'N/A'}</td>
                            <td style="padding: 12px;">
                                <span style="display: inline-block; width: 10px; height: 10px; border-radius: 50%; background: ${isActive ? '#10b981' : '#9ca3af'}; margin-right: 8px;"></span>
                                ${isActive ? 'Active' : 'Inactive'}
                            </td>
                            <td style="padding: 12px;">
                                ${isAdmin ? '<span style="background: #8b5cf6; color: white; padding: 4px 8px; border-radius: 4px; font-size: 12px;">Admin</span>' : '<span style="background: #e5e7eb; color: #374151; padding: 4px 8px; border-radius: 4px; font-size: 12px;">User</span>'}
                            </td>
                            <td style="padding: 12px;">
                                <div style="display: flex; gap: 5px;">
                                    ${!isAdmin ? `
                                        <button class="btn btn-sm ${isBanned ? 'btn-success' : 'btn-danger'}" onclick="toggleBanUser('${user.id}', ${isBanned})" style="padding: 6px 12px; font-size: 12px;">
                                            ${isBanned ? 'Unban' : 'Ban'}
                                        </button>
                                        <button class="btn btn-sm btn-primary" onclick="toggleAdminStatus('${user.id}', false)" style="padding: 6px 12px; font-size: 12px; background-color: #8b5cf6; border-color: #8b5cf6;">
                                            Make Admin
                                        </button>
                                    ` : `
                                        <span style="color: var(--gray); font-size: 12px;">Admin User</span>
                                        ${user.email !== 'killerskull913@gmail.com' ? `
                                            <button class="btn btn-sm btn-outline" onclick="toggleAdminStatus('${user.id}', true)" style="padding: 4px 8px; font-size: 10px; margin-left: 5px;">
                                                Demote
                                            </button>
                                        ` : ''}
                                    `}
                                </div>
                            </td>
                        </tr>
                    `;
                }).join('')}
            </tbody>
        </table>
    `;
    
    usersList.innerHTML = tableHTML;
}

window.toggleAdminStatus = async function(userId, isCurrentlyAdmin) {
    const action = isCurrentlyAdmin ? 'demote' : 'promote';
    if (!confirm(`Are you sure you want to ${action} this user?`)) return;

    try {
        const response = await fetch('/api/admin/set-admin-status', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify({ userId, isAdmin: !isCurrentlyAdmin })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showNotification('Success', `User ${action}d successfully`, 'success');
            await loadAdminUsers();
        } else {
            showNotification('Error', data.error || `Failed to ${action} user`, 'error');
        }
    } catch (error) {
        console.error('Error toggling admin status:', error);
        showNotification('Error', 'An error occurred', 'error');
    }
}

async function loadAdminOrders() {
    try {
        const response = await fetch('/api/admin/get-orders', {
            method: 'GET',
            headers: getAuthHeaders()
        });
        
        const data = await response.json();
        
        if (response.ok && data.orders) {
            adminOrdersCache = data.orders;
            renderAdminOrders(data.orders);
        }
    } catch (error) {
        console.error('Error loading admin orders:', error);
    }
}

function renderAdminOrders(orders) {
    const ordersList = document.getElementById('adminOrdersList');
    if (!ordersList) return;
    
    if (orders.length === 0) {
        ordersList.innerHTML = '<p style="text-align: center; color: var(--gray); padding: 20px;">No orders found.</p>';
        return;
    }

    // Categorize orders
    const sections = {
        initializing: [],
        confirmed: [],
        arriving: [],
        completed: []
    };

    orders.forEach(order => {
        // Normalize status
        const status = (order.status || 'initializing').toLowerCase();
        
        if (status === 'arrived' || status === 'completed') {
            sections.completed.push(order);
        } else if (status === 'arriving') {
            sections.arriving.push(order);
        } else if (status === 'payment_confirmed') {
            sections.confirmed.push(order);
        } else {
            // payment_confirming, initializing, etc.
            sections.initializing.push(order);
        }
    });

    const renderSection = (title, ordersInSection, icon) => {
        if (ordersInSection.length === 0) return '';
        
        return `
            <div class="order-section" style="margin-bottom: 30px;">
                <h3 style="border-bottom: 2px solid var(--border); padding-bottom: 10px; margin-bottom: 15px; color: var(--primary-color);">
                    ${icon} ${title} (${ordersInSection.length})
                </h3>
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="border-bottom: 2px solid var(--border); text-align: left; font-size: 14px; color: var(--gray);">
                            <th style="padding: 10px;">Order ID</th>
                            <th style="padding: 10px;">Customer</th>
                            <th style="padding: 10px;">Method</th>
                            <th style="padding: 10px;">Total</th>
                            <th style="padding: 10px;">Status</th>
                            <th style="padding: 10px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${ordersInSection.map(order => renderOrderRow(order)).join('')}
                    </tbody>
                </table>
            </div>
        `;
    };

    ordersList.innerHTML = `
        ${renderSection('Initializing Orders', sections.initializing, '⏳')}
        ${renderSection('Confirmed Orders', sections.confirmed, '✅')}
        ${renderSection('Arriving Orders', sections.arriving, '🚚')}
        ${renderSection('Completed Orders', sections.completed, '🏁')}
    `;
}

function renderOrderRow(order) {
    const orderDate = new Date(order.confirmedAt || order.createdAt);
    const formattedDate = orderDate.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric' 
    });
    const total = order.orderData?.total || 0;
    const currentStatus = order.status || 'initializing';
    const paymentMethod = order.orderData?.paymentMethod || 'Unknown';
    
    // Status Logic
    let statusOptions = '';
    
    // Define allowed transitions or just all options? 
    // User requested specific flows, but Admin usually has power to fix things.
    // I will show all relevant options.
    
    const options = [
        { val: 'payment_confirming', label: 'Payment Confirming' },
        { val: 'payment_confirmed', label: 'Payment Confirmed' },
        { val: 'initializing', label: 'Initializing' },
        { val: 'arriving', label: 'Arriving' },
        { val: 'arrived', label: 'Arrived' }
    ];

    statusOptions = options.map(opt => 
        `<option value="${opt.val}" ${currentStatus === opt.val ? 'selected' : ''}>${opt.label}</option>`
    ).join('');

    const getStatusColor = (s) => {
        if (s === 'arrived') return '#10b981';
        if (s === 'arriving') return '#8b5cf6';
        if (s === 'payment_confirmed') return '#059669';
        if (s === 'payment_confirming') return '#f59e0b';
        return '#3b82f6'; // initializing
    };

    return `
        <tr style="border-bottom: 1px solid var(--border);">
            <td style="padding: 10px;"><strong>${order.orderId}</strong><br><span style="font-size: 11px; color: var(--gray);">${formattedDate}</span></td>
            <td style="padding: 10px;">
                ${order.name || 'N/A'}<br>
                <span style="font-size: 11px; color: var(--gray);">${order.email}</span>
            </td>
            <td style="padding: 10px;">
                <span style="text-transform: capitalize; background: #f3f4f6; padding: 2px 6px; border-radius: 4px; font-size: 12px;">${paymentMethod}</span>
            </td>
            <td style="padding: 10px;">$${total.toFixed(2)}</td>
            <td style="padding: 10px;">
                <select onchange="updateOrderStatus('${order.orderId}', this.value)" 
                        style="padding: 4px 8px; border-radius: 4px; border: 1px solid var(--border); background: ${getStatusColor(currentStatus)}; color: white; cursor: pointer; font-size: 12px; font-weight: 500;">
                    ${statusOptions}
                </select>
            </td>
            <td style="padding: 10px;">
                <button class="btn btn-sm btn-primary" onclick="viewOrderDetails('${order.orderId}')" style="padding: 4px 8px; font-size: 11px;">
                    View
                </button>
            </td>
        </tr>
    `;
}

// Keep the rest of the file (updateOrderStatus, etc.) but ensure updateOrderStatus handles the new response
window.updateOrderStatus = async function(orderId, newStatus) {
    // Optimistic Update
    const orderIndex = adminOrdersCache.findIndex(o => o.orderId === orderId);
    let oldStatus = null;
    if (orderIndex > -1) {
        oldStatus = adminOrdersCache[orderIndex].status;
        adminOrdersCache[orderIndex].status = newStatus;
        // Don't re-render full list yet to keep UI stable
    }
    
    try {
        const response = await fetch('/api/admin/update-order-status', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify({ orderId, status: newStatus })
        });
        
        if (response.ok) {
            showNotification('Success', `Order status updated to ${newStatus}`, 'success');
            // Refresh to sort into correct category
            setTimeout(() => {
                renderAdminOrders(adminOrdersCache);
            }, 1000); 
        } else {
            const data = await response.json();
            showNotification('Error', data.error || 'Failed to update status', 'error');
            // Revert
            if (oldStatus) {
                adminOrdersCache[orderIndex].status = oldStatus;
                renderAdminOrders(adminOrdersCache);
            }
        }
    } catch (error) {
        console.error('Error updating status:', error);
        showNotification('Error', 'An error occurred', 'error');
        // Revert
        if (oldStatus) {
            adminOrdersCache[orderIndex].status = oldStatus;
            renderAdminOrders(adminOrdersCache);
        }
    }
};

window.viewOrderDetails = function(orderId) {
    const order = adminOrdersCache.find(o => o.orderId === orderId);
    if (!order) {
        alert('Order details not found');
        return;
    }
    
    const modal = document.getElementById('orderDetailModal');
    const content = document.getElementById('orderDetailContent');
    const shipping = order.orderData?.shippingInfo || {};
    const items = order.orderData?.items || [];
    const boxes = order.orderData?.boxes || [];
    
    let boxesHtml = '';
    if (boxes.length > 0) {
        boxesHtml = `
            <h3 style="margin-bottom: 10px; margin-top: 20px; color: #ec4899;">🎁 Box Configurations</h3>
            <div style="background: #fff0f5; border: 1px solid #fbcfe8; border-radius: 8px; padding: 15px; margin-bottom: 20px;">
                ${boxes.map((box, idx) => `
                    <div style="margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px solid #fbcfe8; ${idx === boxes.length - 1 ? 'border-bottom: none; margin-bottom: 0; padding-bottom: 0;' : ''}">
                        <p><strong>Box ${idx + 1}:</strong> <span style="text-transform: capitalize;">${box.boxColor}</span></p>
                        <p><strong>To:</strong> ${box.recipientName}</p>
                        <p><strong>Message:</strong> ${box.message}</p>
                        <p style="font-size: 13px; color: #666;"><strong>Items Included:</strong> ${box.itemsIncluded.join(', ')}</p>
                    </div>
                `).join('')}
            </div>
        `;
    }
    
    content.innerHTML = `
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
            <div>
                <h3 style="margin-bottom: 10px;">Order Info</h3>
                <p><strong>Order ID:</strong> ${order.orderId}</p>
                <p><strong>Date:</strong> ${new Date(order.confirmedAt || order.createdAt).toLocaleString()}</p>
                <p><strong>Status:</strong> <span style="color: #10b981;">Confirmed</span></p>
            </div>
            <div>
                <h3 style="margin-bottom: 10px;">Shipping Details</h3>
                <p><strong>Name:</strong> ${shipping.name || 'N/A'}</p>
                <p><strong>Email:</strong> ${shipping.email || 'N/A'}</p>
                <p><strong>Phone:</strong> ${shipping.phone || 'N/A'}</p>
                <p><strong>Address:</strong><br>
                ${shipping.address || ''}<br>
                ${shipping.city || ''}, ${shipping.country || ''} ${shipping.postalCode || ''}
                </p>
                ${shipping.notes ? `<p><strong>Notes:</strong> ${shipping.notes}</p>` : ''}
            </div>
        </div>
        
        ${boxesHtml}
        
        <h3 style="margin-bottom: 10px;">Items</h3>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
            <thead style="background: #f3f4f6;">
                <tr>
                    <th style="padding: 10px; text-align: left;">Product</th>
                    <th style="padding: 10px; text-align: right;">Price</th>
                    <th style="padding: 10px; text-align: right;">Qty</th>
                    <th style="padding: 10px; text-align: right;">Total</th>
                </tr>
            </thead>
            <tbody>
                ${items.map(item => `
                    <tr style="border-bottom: 1px solid var(--border);">
                        <td style="padding: 10px;">${item.name}</td>
                        <td style="padding: 10px; text-align: right;">$${item.price.toFixed(2)}</td>
                        <td style="padding: 10px; text-align: right;">${item.quantity}</td>
                        <td style="padding: 10px; text-align: right;">$${(item.price * item.quantity).toFixed(2)}</td>
                    </tr>
                `).join('')}
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3" style="padding: 10px; text-align: right;"><strong>Total:</strong></td>
                    <td style="padding: 10px; text-align: right;"><strong>$${(order.orderData?.total || 0).toFixed(2)}</strong></td>
                </tr>
            </tfoot>
        </table>
    `;
    
    modal.style.display = 'block';
    
    // Setup close handlers
    const closeBtn = document.getElementById('closeOrderModal');
    if (closeBtn) {
        closeBtn.onclick = () => modal.style.display = 'none';
    }
    
    // Hide reorder button for admin view as it's not relevant
    const reorderBtn = document.getElementById('reorderBtn');
    if (reorderBtn) {
        reorderBtn.style.display = 'none';
    }
    
    window.onclick = (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    };
};

window.toggleBanUser = async function(userId, currentlyBanned) {
    const action = currentlyBanned ? 'unban' : 'ban';
    const confirmMsg = `Are you sure you want to ${action} this user?`;
    
    if (!confirm(confirmMsg)) return;
    
    try {
        const response = await fetch('/api/admin/ban-user', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify({
                userId,
                banned: !currentlyBanned
            })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showNotification(
                'Success',
                `User has been ${action}ned successfully`,
                'success'
            );
            await loadAdminUsers();
        } else {
            showNotification('Error', data.error || 'Failed to update user status', 'error');
        }
    } catch (error) {
        console.error('Error toggling ban:', error);
        showNotification('Error', 'An error occurred. Please try again.', 'error');
    }
};

async function loadAdminQuestions() {
    try {
        // Use the get-questions API which returns global recent questions if no productId is passed
        const response = await fetch('/api/get-questions');
        const data = await response.json();
        
        if (response.ok && data.questions) {
            adminQuestionsCache = data.questions;
            renderAdminQuestions(adminQuestionsCache, 'unanswered');
        } else {
            console.error('Failed to load questions:', data.error);
        }
    } catch (error) {
        console.error('Error loading admin questions:', error);
    }
}

function renderAdminQuestions(questions, filter) {
    const questionsList = document.getElementById('adminQuestionsList');
    if (!questionsList) return;
    
    const filteredQuestions = questions.filter(q => {
        if (filter === 'answered') return q.answered === true;
        return q.answered !== true;
    });
    
    if (filteredQuestions.length === 0) {
        questionsList.innerHTML = `<p style="text-align: center; color: var(--gray); padding: 20px;">No ${filter} questions found.</p>`;
        return;
    }
    
    const questionsHTML = filteredQuestions.map((q) => {
        const date = new Date(q.date);
        const timeAgo = getTimeAgoAdmin(date);
        
        // Find the index in the original cache to pass to submitAnswer
        // Using productId and date as unique identifier combination
        const originalIndex = adminQuestionsCache.findIndex(item => item.date === q.date && item.productId === q.productId);

        return `
            <div class="admin-qa-item">
                <div style="margin-bottom: 15px;">
                    <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 10px;">
                        <div>
                            <strong style="color: var(--primary-color);">${q.userName}</strong>
                            <span style="color: var(--gray); font-size: 14px; margin-left: 10px;">${q.userEmail || 'User'}</span>
                            ${q.productName ? `<br><small style="color: var(--gray);">On: ${q.productName}</small>` : ''}
                        </div>
                        <div style="display: flex; flex-direction: column; align-items: flex-end; gap: 5px;">
                            <span style="color: var(--gray); font-size: 12px;">${timeAgo}</span>
                            <button class="btn btn-sm btn-danger" onclick="deleteQuestion('${q.productId}', '${q.date}')" style="padding: 4px 8px; font-size: 11px;">🗑️ Delete</button>
                        </div>
                    </div>
                    <p style="margin: 10px 0; color: var(--dark);">${q.question}</p>
                </div>
                
                ${q.answered === true ? `
                    <div style="background: white; padding: 15px; border-radius: 6px; border-left: 3px solid #10b981;">
                        <strong style="color: #10b981;">Answered at ${new Date(q.answeredAt).toLocaleDateString()}:</strong>
                        <p style="margin: 5px 0 0 0;">${q.answer}</p>
                    </div>
                ` : `
                    <form onsubmit="submitAnswer(event, ${originalIndex})" style="margin-top: 15px;">
                        <textarea 
                            id="answer-${originalIndex}" 
                            placeholder="Type your answer here..." 
                            required 
                            style="width: 100%; padding: 10px; border: 1px solid var(--border); border-radius: 6px; font-family: inherit; min-height: 80px; resize: vertical;"
                        ></textarea>
                        <button type="submit" class="btn btn-primary" style="margin-top: 10px;">Submit Answer</button>
                    </form>
                `}
            </div>
        `;
    }).join('');
    
    questionsList.innerHTML = questionsHTML;
}

window.deleteQuestion = async function(productId, questionDate) {
    if(!confirm('Are you sure you want to delete this question? This cannot be undone.')) return;

    try {
        const response = await fetch('/api/admin/delete-question', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify({ productId, questionDate })
        });

        if (response.ok) {
            showNotification('Success', 'Question deleted successfully', 'success');
            await loadAdminQuestions();
        } else {
            const data = await response.json();
            showNotification('Error', data.error || 'Failed to delete question', 'error');
        }
    } catch (error) {
        console.error('Error deleting question:', error);
        showNotification('Error', 'An error occurred', 'error');
    }
};

window.submitAnswer = async function(event, questionIndex) {
    event.preventDefault();
    
    const question = adminQuestionsCache[questionIndex];
    if (!question) {
        showNotification('Error', 'Question not found', 'error');
        return;
    }

    const answerInput = document.getElementById(`answer-${questionIndex}`);
    const answerText = answerInput.value.trim();
    
    if (!answerText) return;

    const submitBtn = event.target.querySelector('button[type="submit"]');
    const originalBtnText = submitBtn.textContent;
    submitBtn.textContent = 'Submitting...';
    submitBtn.disabled = true;
    
    try {
        const response = await fetch('/api/admin/answer-question', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify({
                productId: question.productId,
                questionDate: question.date,
                answer: answerText
            })
        });

        const data = await response.json();

        if (response.ok) {
            showNotification(
                'Answer Submitted',
                'Your answer has been posted successfully',
                'success'
            );
            // Reload questions to see the update
            await loadAdminQuestions();
        } else {
            showNotification('Error', data.error || 'Failed to submit answer', 'error');
            submitBtn.textContent = originalBtnText;
            submitBtn.disabled = false;
        }
    } catch (error) {
        console.error('Error submitting answer:', error);
        showNotification('Error', 'An error occurred. Please try again.', 'error');
        submitBtn.textContent = originalBtnText;
        submitBtn.disabled = false;
    }
};

function setupQAFilters() {
    const filterBtns = document.querySelectorAll('.qa-filter-btn');
    
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const filter = btn.dataset.filter;
            
            filterBtns.forEach(b => {
                b.classList.remove('active');
                b.style.borderBottom = '3px solid transparent';
            });
            
            btn.classList.add('active');
            btn.style.borderBottom = '3px solid var(--primary-color)';
            
            renderAdminQuestions(adminQuestionsCache, filter);
        });
    });
}

function getTimeAgoAdmin(date) {
    const seconds = Math.floor((new Date() - date) / 1000);
    
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + ' year' + (Math.floor(interval) > 1 ? 's' : '') + ' ago';
    
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + ' month' + (Math.floor(interval) > 1 ? 's' : '') + ' ago';
    
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + ' day' + (Math.floor(interval) > 1 ? 's' : '') + ' ago';
    
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + ' hour' + (Math.floor(interval) > 1 ? 's' : '') + ' ago';
    
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + ' minute' + (Math.floor(interval) > 1 ? 's' : '') + ' ago';
    
    return 'Just now';
}

// Make functions globally available if needed
window.checkAdminRole = checkAdminRole;
window.loadAdminQuestions = loadAdminQuestions;
window.toggleAdminStatus = toggleAdminStatus;
window.loadAdminCompletedOrders = loadAdminCompletedOrders;