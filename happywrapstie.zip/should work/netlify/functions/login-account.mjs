import { getStore } from '@netlify/blobs';
import bcrypt from 'bcryptjs';
import { randomUUID } from 'crypto';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { email, password } = await req.json();

    if (!email || !password) {
      return new Response(JSON.stringify({ error: 'Email and password are required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const accountsStore = getStore('user-accounts');
    const accountDataStr = await accountsStore.get(email);

    if (!accountDataStr) {
      return new Response(JSON.stringify({ error: 'Invalid email or password' }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const accountData = JSON.parse(accountDataStr);

    if (accountData.banned) {
      return new Response(JSON.stringify({ 
        error: 'Your account has been suspended.' 
      }), {
        status: 403,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    if (!accountData.verified) {
      return new Response(JSON.stringify({ 
        error: 'Please verify your email before logging in. Check your inbox for the verification link.',
        needsVerification: true
      }), {
        status: 403,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const passwordMatch = await bcrypt.compare(password, accountData.hashedPassword);

    if (!passwordMatch) {
      return new Response(JSON.stringify({ error: 'Invalid email or password' }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Determine Admin Status
    // Hardcoded initial admin or property in DB
    const isAdmin = email === 'killerskull913@gmail.com' || accountData.isAdmin === true;
    
    // If it's the hardcoded admin but DB doesn't have it, update DB (optional but good for consistency)
    if (email === 'killerskull913@gmail.com' && !accountData.isAdmin) {
        accountData.isAdmin = true;
        // We will update the store at the end along with lastLogin
    }

    accountData.lastLogin = new Date().toISOString();
    await accountsStore.set(email, JSON.stringify(accountData), {
      metadata: { userId: accountData.userId, email, verified: 'true' }
    });

    // Create Session
    const sessionId = randomUUID();
    const sessionStore = getStore('sessions');
    const sessionData = {
        sessionId,
        userId: accountData.userId,
        email: accountData.email,
        createdAt: new Date().toISOString(),
        userAgent: req.headers.get('user-agent') || 'unknown'
    };
    
    await sessionStore.set(sessionId, JSON.stringify(sessionData));

    console.log('User logged in:', email, 'Admin:', isAdmin);

    return new Response(JSON.stringify({ 
      success: true, 
      message: 'Login successful',
      user: {
        userId: accountData.userId,
        firstName: accountData.firstName,
        lastName: accountData.lastName,
        email: accountData.email,
        dateOfBirth: accountData.dateOfBirth,
        isAdmin: isAdmin,
        provider: 'local'
      }
    }), {
      status: 200,
      headers: { 
          'Content-Type': 'application/json',
          'Set-Cookie': `session=${sessionId}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=${60 * 60 * 24 * 30}` // 30 days
      }
    });

  } catch (error) {
    console.error('Error logging in:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to log in',
      details: error.message 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

export const config = {
  path: '/api/login-account'
};
