import { getStore } from '@netlify/blobs';
import { emailOtpTemplate } from '../email-templates/index.js';
import { sendEmailSMTP } from './lib/smtp-mailer.mjs';
import { normalizeEmail, generateRandomOTP, hashOTP } from './lib/otp-utils.mjs';
import bcrypt from 'bcryptjs';

export default async (req, context) => {
  // Only allow POST requests
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method Not Allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const body = await req.json();
    const { email, type = 'order' } = body;

    if (!email) {
      return new Response(JSON.stringify({ error: 'Email is required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // 1. Normalize email
    let normalizedEmail;
    try {
      normalizedEmail = normalizeEmail(email);
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // 2. Handle specific types
    if (type === 'signup') {
        const { firstName, lastName, dateOfBirth, password } = body;
        
        if (!firstName || !lastName || !password || !dateOfBirth) {
            return new Response(JSON.stringify({ error: 'Missing signup details' }), { 
                status: 400,
                headers: { 'Content-Type': 'application/json' }
            });
        }

        // Check if user exists
        const accountsStore = getStore('user-accounts');
        const existingUser = await accountsStore.get(normalizedEmail);
        
        if (existingUser) {
            return new Response(JSON.stringify({ error: 'Account already exists with this email' }), { 
                status: 400, 
                headers: { 'Content-Type': 'application/json' }
            });
        }

        // Hash password and store pending data
        const hashedPassword = await bcrypt.hash(password, 10);
        const pendingStore = getStore('pending_signups');
        
        await pendingStore.setJSON(normalizedEmail, {
            firstName,
            lastName,
            email: normalizedEmail,
            dateOfBirth,
            hashedPassword,
            createdAt: new Date().toISOString()
        });

    } else if (type === 'password_reset') {
        // Check if user exists
        const accountsStore = getStore('user-accounts');
        const existingUser = await accountsStore.get(normalizedEmail);
        
        if (!existingUser) {
            return new Response(JSON.stringify({ error: 'No account found with this email' }), { 
                status: 400, 
                headers: { 'Content-Type': 'application/json' }
            });
        }

    } else if (type === 'email_change') {
        // Check if new email is already taken
        const accountsStore = getStore('user-accounts');
        const existingUser = await accountsStore.get(normalizedEmail);
        
        if (existingUser) {
            return new Response(JSON.stringify({ error: 'Email is already in use' }), { 
                status: 400, 
                headers: { 'Content-Type': 'application/json' }
            });
        }

        const { userId, oldEmail } = body;
        if (!userId) {
            return new Response(JSON.stringify({ error: 'User ID is required' }), { 
                status: 400, 
                headers: { 'Content-Type': 'application/json' }
            });
        }

        // Store pending change
        const pendingStore = getStore('pending_email_changes');
        await pendingStore.setJSON(normalizedEmail, {
            userId,
            oldEmail,
            newEmail: normalizedEmail,
            createdAt: new Date().toISOString()
        });
    }

    // 3. Generate a 6-digit OTP
    const otp = generateRandomOTP();

    // 4. Prepare OTP storage object
    const now = Date.now();
    const expiresAt = now + 10 * 60 * 1000; // 10 minutes from now
    const otpHash = hashOTP(otp);

    const otpDataStore = {
      email: normalizedEmail,
      otpHash,
      type, // Store type to ensure OTP is used for intended purpose
      expiresAt,
      attempts: 0,
      verified: false,
    };

    // 5. Store in Netlify Blobs 'otp_codes'
    const otpStore = getStore('otp_codes');
    const otpKey = `otp:email:${normalizedEmail}`;

    await otpStore.setJSON(otpKey, otpDataStore);

    // 6. Legacy: Store Order Data for Verification (if order type)
    if (type === 'order' && body.orderId) {
        const { orderId, name, orderData } = body;
        const verificationStore = getStore('email-order-verifications');
        await verificationStore.setJSON(orderId, {
            orderId,
            email: normalizedEmail,
            name,
            orderData,
            createdAt: new Date().toISOString(),
            verified: false
        });
    }

    // 7. Send Email
    let emailSubject = 'Your Verification Code - HappyWrap';
    if (type === 'signup') emailSubject = 'Verify your account - HappyWrap';
    if (type === 'password_reset') emailSubject = 'Password Reset Code - HappyWrap';
    if (type === 'email_change') emailSubject = 'Verify new email - HappyWrap';

    const emailBody = emailOtpTemplate({
      OTP_CODE: otp,
      EXPIRATION_TIME: '10 minutes'
    });

    console.log(`Sending OTP email to ${normalizedEmail} (Type: ${type})...`);
    const emailSent = await sendEmailSMTP(normalizedEmail, emailSubject, emailBody);

    if (!emailSent) {
      console.error('Failed to send OTP email');
      return new Response(JSON.stringify({ error: 'Failed to send verification email' }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    console.log(`OTP generated and sent for ${normalizedEmail}`);

    return new Response(JSON.stringify({ 
        success: true,
        // plainOtp: otp // Removed for production safety, only add if debugging needed
    }), {
      status: 200,
      headers: { 
        'Content-Type': 'application/json',
        'Cache-Control': 'no-store'
      },
    });

  } catch (error) {
    console.error('Error generating OTP:', error);
    return new Response(JSON.stringify({ error: 'Internal Server Error', details: error.message }), {
      status: 500,
      headers: { 
        'Content-Type': 'application/json',
        'Cache-Control': 'no-store'
      },
    });
  }
};

export const config = {
  path: '/api/generate-email-otp'
};