import { getStore } from '@netlify/blobs';
import crypto from 'node:crypto';

// Replace this with your actual session creation function
async function createSessionForUser(userId, email) {
  // Generate a random session token
  const token = crypto.randomBytes(32).toString('hex');
  
  // Store session in a secure Blobs store (or database)
  const sessionStore = getStore('sessions');
  await sessionStore.set(token, JSON.stringify({ userId, email, createdAt: new Date().toISOString() }), {
    metadata: { userId, email }
  });

  return token;
}

export default async (req, context) => {
  const url = new URL(req.url);
  const code = url.searchParams.get('code');
  const error = url.searchParams.get('error');

  if (error) {
    return new Response(`Error: ${error}`, { status: 400 });
  }

  if (!code) {
    return new Response('No code provided', { status: 400 });
  }

  const googleClientId = process.env.GOOGLE_CLIENT_ID;
  const googleClientSecret = process.env.GOOGLE_CLIENT_SECRET;

  if (!googleClientId || !googleClientSecret) {
    return new Response('Google client not found', { status: 200 });
  }

  const redirectUri = `${url.origin}/api/google-callback`;

  try {
    // 1️⃣ Exchange code for access token
    const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: googleClientId,
        client_secret: googleClientSecret,
        redirect_uri: redirectUri,
        grant_type: 'authorization_code'
      })
    });

    const tokenData = await tokenResponse.json();

    if (!tokenResponse.ok) {
      console.error('Token exchange failed:', tokenData);
      return new Response(`Token exchange failed: ${tokenData.error_description || tokenData.error}`, { status: 500 });
    }

    // 2️⃣ Fetch user info from Google
    const userResponse = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
      headers: { Authorization: `Bearer ${tokenData.access_token}` }
    });
    const googleUser = await userResponse.json();

    if (!userResponse.ok) {
      return new Response('Failed to get user info', { status: 500 });
    }

    const email = googleUser.email;

    // 3️⃣ Find or create user in your Blobs store
    const accountsStore = getStore('user-accounts');
    let accountDataStr = await accountsStore.get(email);
    let accountData;

    if (accountDataStr) {
      accountData = JSON.parse(accountDataStr);

      if (accountData.banned) {
        return new Response(`
          <!DOCTYPE html>
          <html>
          <body>
            <script>
              alert('Your account has been suspended.');
              window.location.href = '/login.html';
            </script>
          </body>
          </html>
        `, { headers: { 'Content-Type': 'text/html' } });
      }

      accountData.lastLogin = new Date().toISOString();
      await accountsStore.set(email, JSON.stringify(accountData), {
        metadata: { userId: accountData.userId, email, verified: 'true', provider: 'google' }
      });
    } else {
      // Create new Google account
      const userId = crypto.randomUUID();
      accountData = {
        userId,
        firstName: googleUser.given_name || '',
        lastName: googleUser.family_name || '',
        email,
        dateOfBirth: null,
        hashedPassword: null,
        verified: true,
        provider: 'google',
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString()
      };

      await accountsStore.set(email, JSON.stringify(accountData), {
        metadata: { userId, email, verified: 'true', provider: 'google' }
      });
    }

    // 4️⃣ Issue backend session token
    const sessionToken = await createSessionForUser(accountData.userId, email);

    // 5️⃣ Redirect with secure cookie
    return new Response(null, {
      status: 302,
      headers: {
        'Set-Cookie': `session=${sessionToken}; HttpOnly; Secure; Path=/; SameSite=Lax`,
        'Location': '/account.html?newSession=true'
      }
    });

  } catch (err) {
    console.error('OAuth callback error:', err);
    return new Response('Internal Server Error', { status: 500 });
  }
};

export const config = {
  path: '/api/google-callback'
};