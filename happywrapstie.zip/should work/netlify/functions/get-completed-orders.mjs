import { getStore } from '@netlify/blobs';
import { verifyAuth } from './lib/auth.mjs';

export default async (req, context) => {
  if (req.method !== 'GET') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405 });
  }

  try {
    await verifyAuth(req);

    const store = getStore('completed-orders');
    const { blobs } = await store.list();
    
    const orders = [];
    for (const blob of blobs) {
      try {
        const data = await store.get(blob.key, { type: 'json' });
        if (data) orders.push(data);
      } catch (err) {
        console.error(`Error parsing completed order ${blob.key}:`, err);
      }
    }

    // Sort by submittedAt desc
    orders.sort((a, b) => new Date(b.submittedAt) - new Date(a.submittedAt));

    return new Response(JSON.stringify({ 
      success: true,
      orders: orders
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error fetching completed orders:', error);
    const status = error.message.includes('Unauthorized') || error.message.includes('Forbidden') ? 401 : 500;
    return new Response(JSON.stringify({ error: error.message || 'Failed to fetch' }), { status: status });
  }
};

export const config = {
  path: '/api/admin/get-completed-orders'
};
