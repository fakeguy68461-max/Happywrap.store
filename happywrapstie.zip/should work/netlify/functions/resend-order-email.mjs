import { getStore } from '@netlify/blobs';
import { sendEmailSMTP } from './lib/smtp-mailer.mjs';
import { getSiteUrl } from './lib/getUrl.mjs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { token } = await req.json();

    if (!token) {
      return new Response(JSON.stringify({ error: 'Token is required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const store = getStore('pending-orders');
    const orderDataString = await store.get(token);

    if (!orderDataString) {
      return new Response(JSON.stringify({ 
        error: 'Invalid token',
        success: false 
      }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const orderData = JSON.parse(orderDataString);

    const siteUrl = getSiteUrl();
    const confirmationLink = `${siteUrl}/order-confirm.html?token=${token}`;
    
    const emailSubject = `Confirm your order #${orderData.orderId}`;
    const emailBody = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #2563eb;">HappyWrap - Order Confirmation</h1>
        <p>Hello ${orderData.name || 'Customer'},</p>
        <p>Thank you for shopping with us! Please confirm your order by clicking the button below:</p>
        
        <div style="margin: 30px 0;">
          <a href="${confirmationLink}" 
             style="background-color: #2563eb; color: white; padding: 15px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block; 
                    font-weight: bold;">
            Confirm Order
          </a>
        </div>
        
        <p>Or copy and paste this link into your browser:</p>
        <p style="word-break: break-all; color: #666;">${confirmationLink}</p>
        
        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd;">
          <h3>Order Summary</h3>
          <p><strong>Order Number:</strong> ${orderData.orderId}</p>
          <p><strong>Total:</strong> $${(orderData.orderData?.total || 0).toFixed(2)}</p>
          <p><strong>Items:</strong> ${orderData.orderData?.items?.length || 0}</p>
        </div>
        
        <p style="margin-top: 30px; color: #666; font-size: 12px;">
          This link will expire in 24 hours. If you didn't place this order, please ignore this email.
        </p>
      </div>
    `;

    const emailSent = await sendEmailSMTP(orderData.email, emailSubject, emailBody);

    if (!emailSent) {
      console.error('Failed to resend email to:', orderData.email);
      console.error('Please check SMTP credentials and configuration');
      return new Response(JSON.stringify({ 
        error: 'Failed to resend email. Please try again or use the direct confirmation link.',
        details: 'Email service configuration error',
        success: false
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    console.log('Resending confirmation email to:', orderData.email);
    console.log('Confirmation link:', confirmationLink);
    console.log('Email sent status:', emailSent);

    return new Response(JSON.stringify({ 
      success: true,
      message: 'Email resent successfully'
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error resending email:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to resend email',
      details: error.message,
      success: false
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

export const config = {
  path: '/api/resend-order-email'
};
