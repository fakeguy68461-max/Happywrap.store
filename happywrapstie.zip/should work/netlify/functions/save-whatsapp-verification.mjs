import { getStore } from '@netlify/blobs';
import { normalizePhoneNumber, generateRandomOTP, hashOTP } from './lib/otp-utils.mjs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { orderId, phoneNumber, orderData } = await req.json();

    if (!orderId || !phoneNumber) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const headers = {
      'Content-Type': 'application/json',
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'DENY',
      'X-XSS-Protection': '1; mode=block',
      'Cache-Control': 'no-store'
    };

    // 1. Normalize phone number
    let normalizedPhone;
    try {
      normalizedPhone = normalizePhoneNumber(phoneNumber);
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), {
        status: 400,
        headers
      });
    }

    // 2. Generate OTP
    const otp = generateRandomOTP();
    
    // 3. Store OTP in a separate slot (store) 'otp_codes'
    // User requested format: otp:+92... -> 567890 (with security/expiry)
    // Updated to key by Order ID for robust per-order verification
    const otpStore = getStore('otp_codes');
    const otpKey = `otp:${orderId}`;
    console.log('[OTP_DEBUG] Storing OTP at key:', otpKey);
    const now = Date.now();
    const expiresAt = now + 10 * 60 * 1000; // 10 minutes
    const otpHash = hashOTP(otp);

    await otpStore.setJSON(otpKey, {
      phone: normalizedPhone,
      orderId: orderId,
      otpHash: otpHash,
      plainOtp: otp,   // DEV ONLY
      expiresAt: expiresAt,
      attempts: 0,
      verified: false
    });

    // Store WhatsApp verification data in blob store
    const store = getStore('whatsapp-verifications');

    await store.set(orderId, JSON.stringify({
      orderId,
      phoneNumber: normalizedPhone,
      orderData,
      createdAt: new Date().toISOString(),
      verified: false,
      status: 'pending'
    }), {
      metadata: { orderId, phoneNumber: normalizedPhone }
    });

    console.log(`OTP generated for ${normalizedPhone}: ${otp}`);
    console.log('WhatsApp verification data saved for order:', orderId);

    return new Response(JSON.stringify({
      success: true,
      message: 'OTP generated and saved. WhatsApp number saved.',
      orderId,
      otp // Returning OTP for testing/demo purposes
    }), {
      status: 200,
      headers
    });

  } catch (error) {
    console.error('Error saving WhatsApp verification:', error);
    return new Response(JSON.stringify({
      error: 'Failed to save WhatsApp verification data',
      details: error.message
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

export const config = {
  path: '/api/save-whatsapp-verification'
};
