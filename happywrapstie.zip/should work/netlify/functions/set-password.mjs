import { getStore } from '@netlify/blobs';
import bcrypt from 'bcryptjs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { userId, email, newPassword } = await req.json();

    if (!userId || !email || !newPassword) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    if (newPassword.length < 6) {
      return new Response(JSON.stringify({ error: 'Password must be at least 6 characters long' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    
    const store = getStore('user-passwords');
    
    await store.set(userId, JSON.stringify({
      email,
      hashedPassword,
      hasPassword: true,
      passwordSetAt: new Date().toISOString()
    }), {
      metadata: { email, hasPassword: true }
    });

    console.log(`Password set for user ${userId} (${email})`);

    return new Response(JSON.stringify({ 
      success: true, 
      message: 'Password set successfully'
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error setting password:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to set password',
      details: error.message 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

export const config = {
  path: '/api/set-password'
};
