import { getStore } from '@netlify/blobs';
import fetch from 'node-fetch';
import { getSiteUrl } from './lib/getUrl.mjs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { token } = await req.json();

    if (!token) {
      return new Response(JSON.stringify({ error: 'Token is required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const store = getStore('pending-orders');
    const orderDataString = await store.get(token);

    if (!orderDataString) {
      return new Response(JSON.stringify({ 
        error: 'Invalid or expired confirmation link',
        success: false 
      }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const orderData = JSON.parse(orderDataString);

    if (orderData.confirmed) {
      return new Response(JSON.stringify({ 
        error: 'Order has already been confirmed',
        success: false 
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Determine initial status based on payment method
    let initialStatus = 'initializing';
    if (orderData.orderData?.paymentMethod === 'jazzcash') {
        initialStatus = 'payment_confirming';
    }

    const confirmedOrderData = {
      ...orderData,
      status: initialStatus,
      confirmed: true,
      confirmedAt: new Date().toISOString()
    };

    await store.set(token, JSON.stringify(confirmedOrderData), {
      metadata: { 
        orderId: orderData.orderId, 
        email: orderData.email,
        confirmed: true 
      }
    });

    const confirmedOrdersStore = getStore('confirmed-orders');
    await confirmedOrdersStore.set(orderData.orderId, JSON.stringify(confirmedOrderData), {
      metadata: { 
        email: orderData.email,
        confirmedAt: confirmedOrderData.confirmedAt
      }
    });

    console.log(`Order ${orderData.orderId} confirmed successfully for ${orderData.email}`);

    try {
      const siteUrl = getSiteUrl();
      await fetch(`${siteUrl}/api/send-confirmation-email`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId: orderData.orderId,
          email: orderData.email,
          name: orderData.name,
          orderData: orderData.orderData
        })
      });
      console.log('Post-confirmation email triggered');
    } catch (emailError) {
      console.error('Failed to send post-confirmation email:', emailError);
    }

    return new Response(JSON.stringify({ 
      success: true,
      message: 'Order confirmed successfully',
      order: confirmedOrderData
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error confirming order:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to confirm order',
      details: error.message,
      success: false
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

export const config = {
  path: '/api/confirm-order'
};
