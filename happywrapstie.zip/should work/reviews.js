// Reviews and Questions JavaScript

// Setup rating stars
function setupRatingStars(containerId, hiddenFieldId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    const stars = container.querySelectorAll('.star');
    const hiddenField = document.getElementById(hiddenFieldId);
    
    // Helper to update visual state
    const updateStars = (rating) => {
        stars.forEach((s, index) => {
            if (index < rating) {
                s.textContent = '★';
                s.classList.add('filled');
            } else {
                s.textContent = '☆';
                s.classList.remove('filled');
            }
        });
    };
    
    stars.forEach(star => {
        star.addEventListener('click', () => {
            const rating = parseInt(star.dataset.rating);
            hiddenField.value = rating;
            updateStars(rating);
        });
        
        star.addEventListener('mouseenter', () => {
            const rating = parseInt(star.dataset.rating);
            updateStars(rating);
        });
    });
    
    container.addEventListener('mouseleave', () => {
        const currentRating = parseInt(hiddenField.value);
        updateStars(currentRating);
    });
    
    // Initialize with default value (usually 5)
    updateStars(parseInt(hiddenField.value) || 5);
}

// Load reviews from API
async function loadReviews(productId) {
    const reviewsList = document.getElementById('reviewsList');
    if (!reviewsList) return;
    
    try {
        const response = await fetch(`/api/get-reviews?productId=${productId}`);
        const data = await response.json();
        
        if (data.success && data.reviews.length > 0) {
            reviewsList.innerHTML = data.reviews.map(review => {
                const stars = '★'.repeat(parseInt(review.rating));
                const date = new Date(review.date);
                const timeAgo = getTimeAgo(date);
                
                return `
                    <div class="review-item">
                        <div class="review-header">
                            <strong>${review.userName}</strong>
                            <span class="rating-display">${stars}</span>
                        </div>
                        <p class="review-date">${timeAgo}</p>
                        <p class="review-text">${review.comment}</p>
                    </div>
                `;
            }).join('');
        } else {
             reviewsList.innerHTML = '<p>No reviews yet. Be the first to leave one!</p>';
        }
    } catch (error) {
        console.error('Error loading reviews:', error);
        reviewsList.innerHTML = '<p>Error loading reviews.</p>';
    }
}

// Load questions from API
async function loadQuestions(productId) {
    const questionsList = document.getElementById('questionsList');
    if (!questionsList) return;
    
    try {
        const response = await fetch(`/api/get-questions?productId=${productId}`);
        const data = await response.json();
        
        if (data.success && data.questions.length > 0) {
            questionsList.innerHTML = data.questions.map(question => {
                const date = new Date(question.date);
                const timeAgo = getTimeAgo(date);
                
                return `
                    <div class="question-item">
                        <div class="question-header">
                            <strong>${question.userName}</strong> asked:
                        </div>
                        <p class="question-date">${timeAgo}</p>
                        <p class="question-text">${question.question}</p>
                        <div class="answer">
                            ${question.answer ? `
                                <strong>HappyWrap Team:</strong>
                                <p>${question.answer}</p>
                            ` : `
                                <strong>HappyWrap Team:</strong>
                                <p>Thank you for your question! Our team will respond soon.</p>
                            `}
                        </div>
                    </div>
                `;
            }).join('');
        } else {
            questionsList.innerHTML = '<p>No questions yet. Ask something about this product!</p>';
        }
    } catch (error) {
        console.error('Error loading questions:', error);
        questionsList.innerHTML = '<p>Error loading questions.</p>';
    }
}

// Get time ago string
function getTimeAgo(date) {
    const seconds = Math.floor((new Date() - date) / 1000);
    
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + ' year' + (Math.floor(interval) > 1 ? 's' : '') + ' ago';
    
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + ' month' + (Math.floor(interval) > 1 ? 's' : '') + ' ago';
    
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + ' day' + (Math.floor(interval) > 1 ? 's' : '') + ' ago';
    
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + ' hour' + (Math.floor(interval) > 1 ? 's' : '') + ' ago';
    
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + ' minute' + (Math.floor(interval) > 1 ? 's' : '') + ' ago';
    
    return 'Just now';
}

// Initialize review and question forms
document.addEventListener('DOMContentLoaded', () => {
    // Setup rating stars for review form
    if (document.getElementById('ratingInput')) {
        setupRatingStars('ratingInput', 'reviewRating');
    }
    
    // Review form submission
    const reviewForm = document.getElementById('reviewForm');
    if (reviewForm) {
        reviewForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const customUserData = localStorage.getItem('custom_user_data');
            const user = window.netlifyIdentity ? netlifyIdentity.currentUser() : null;
            if (!user && !customUserData) {
                alert('Please login to leave a review');
                return;
            }
            
            const userEmail = user ? user.email : JSON.parse(customUserData).email;
            
            const urlParams = new URLSearchParams(window.location.search);
            const productId = urlParams.get('id');
            
            const reviewData = {
                productId: productId,
                userName: document.getElementById('reviewName').value,
                userEmail: userEmail,
                rating: document.getElementById('reviewRating').value,
                comment: document.getElementById('reviewComment').value
            };
            
            
            try {
                const response = await fetch('/api/store-reviews', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(reviewData)
                });
                
                if (response.ok) {
                    showNotification(
                        'Review Submitted!',
                        'Thank you for your review. It is now visible to all users.',
                        'success'
                    );
                    document.getElementById('reviewModal').style.display = 'none';
                    reviewForm.reset();
                    loadReviews(productId);
                } else {
                    const errorData = await response.json();
                    throw new Error(errorData.details || errorData.error || 'Failed to store review');
                }
                
            } catch (error) {
                console.error('Error submitting review:', error);
                showNotification(
                    'Error',
                    error.message || 'Error submitting review. Please try again.',
                    'error'
                );
            }
        });
    }
    
    // Question form submission
    const questionForm = document.getElementById('questionForm');
    if (questionForm) {
        questionForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const customUserData = localStorage.getItem('custom_user_data');
            const user = window.netlifyIdentity ? netlifyIdentity.currentUser() : null;
            if (!user && !customUserData) {
                alert('Please login to ask a question');
                return;
            }
            
            const userEmail = user ? user.email : JSON.parse(customUserData).email;
            
            const urlParams = new URLSearchParams(window.location.search);
            const productId = urlParams.get('id');
            
            const questionData = {
                productId: productId,
                productName: window.currentProduct ? window.currentProduct.name : 'Unknown Product',
                userName: document.getElementById('questionName').value,
                userEmail: userEmail,
                question: document.getElementById('questionText').value
            };
            
            try {
                const response = await fetch('/api/store-questions', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(questionData)
                });
                
                if (response.ok) {
                    showNotification(
                        'Question Submitted!',
                        'Your question has been submitted and is visible to all users.',
                        'success'
                    );
                    document.getElementById('questionModal').style.display = 'none';
                    questionForm.reset();
                    loadQuestions(productId);
                } else {
                    const errorData = await response.json();
                    throw new Error(errorData.details || errorData.error || 'Failed to store question');
                }
                
            } catch (error) {
                console.error('Error submitting question:', error);
                showNotification(
                    'Error',
                    error.message || 'Error submitting question. Please try again.',
                    'error'
                );
            }
        });
    }
});

// Export functions for use in product.js
window.setupRatingStars = setupRatingStars;
window.loadReviews = loadReviews;
window.loadQuestions = loadQuestions;