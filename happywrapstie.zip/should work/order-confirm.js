document.addEventListener('DOMContentLoaded', async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('token');
    const source = urlParams.get('source');
    const orderId = urlParams.get('orderId');

    if ((source === 'otp' || source === 'jazzcash') && orderId) {
        // Try to get details from session storage (passed from checkout flow)
        let orderData = { total: 0, items: [] };
        try {
            const storedData = sessionStorage.getItem('verificationOrderData');
            if (storedData) {
                orderData = JSON.parse(storedData);
                // Clean up
                sessionStorage.removeItem('verificationOrderData');
            }
        } catch (e) {
            console.error('Error parsing stored order data:', e);
        }

        // Order verified via OTP
        showSuccess({ 
            orderId: orderId, 
            orderData: orderData
        });
        
        // Update message based on source
        const msg = document.querySelector('#successState .status-message');
        if (msg) {
            if (source === 'jazzcash') {
                 msg.textContent = 'Thank you. We will verify your payment and process your order shortly.';
            } else {
                 msg.textContent = 'Your order has been verified and is being processed.';
            }
        }
        return;
    }

    if (!token) {
        showError('Invalid confirmation link');
        return;
    }

    try {
        const response = await fetch('/api/confirm-order', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ token })
        });

        const result = await response.json();

        if (response.ok && result.success) {
            showSuccess(result.order);
        } else {
            showError(result.error || 'Failed to confirm order');
        }
    } catch (error) {
        console.error('Error confirming order:', error);
        showError('Network error. Please try again.');
    }
});

function showSuccess(order) {
    const loadingState = document.getElementById('loadingState');
    const successState = document.getElementById('successState');
    const orderInfo = document.getElementById('orderInfo');

    if (loadingState) loadingState.style.display = 'none';
    if (successState) successState.style.display = 'block';

    if (order && orderInfo) {
        const boxes = []; // Box configurations removed
        let boxesHtml = '';
        
        /* Box display removed */

        const orderInfoHtml = `
            <div style="margin-bottom: 10px;">
                <strong>Order Number:</strong> ${order.orderId}
            </div>
            <div style="margin-bottom: 10px;">
                <strong>Total:</strong> $${(order.orderData?.total || 0).toFixed(2)}
            </div>
            <div style="margin-bottom: 10px;">
                <strong>Items:</strong> ${order.orderData?.items?.length || 0}
            </div>
            ${boxesHtml}
            <div>
                <strong>Status:</strong> <span style="color: #10b981;">Confirmed</span>
            </div>
        `;
        orderInfo.innerHTML = orderInfoHtml;
    }
}

function showError(message) {
    const loadingState = document.getElementById('loadingState');
    const errorState = document.getElementById('errorState');
    const errorMessage = document.getElementById('errorMessage');

    if (loadingState) loadingState.style.display = 'none';
    if (errorState) errorState.style.display = 'block';
    if (errorMessage) errorMessage.textContent = message;
}
