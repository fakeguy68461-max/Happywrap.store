// Checkout Page JavaScript

let loyaltyDiscount = 0;
let loyaltyMessage = '';
let isVipUser = false;
let loyaltyRewardItem = null;

async function checkEmailVerification(email) {
    try {
        const response = await fetch('/api/check-email-verification', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email })
        });
        
        if (response.ok) {
            const data = await response.json();
            return data.verified;
        }
        return false;
    } catch (error) {
        console.error('Error checking email verification:', error);
        return false;
    }
}

async function fetchLoyaltyDiscount(email) {
    if (!email) return;
    try {
        const response = await fetch(`/api/get-loyalty-profile?email=${encodeURIComponent(email)}`);
        const data = await response.json();
        
        if (data.success && data.current_order_discount) {
            loyaltyDiscount = data.current_order_discount.discountPercent || 0;
            loyaltyMessage = data.current_order_discount.message || '';
            isVipUser = data.current_order_discount.isVip || false;
            loyaltyRewardItem = data.current_order_discount.rewardItem || null;
            
            if (loyaltyDiscount > 0 || loyaltyRewardItem) {
                console.log(`Loyalty Update: ${loyaltyMessage}`);
                displayCheckoutSummary(); // Re-render with discount/reward
            }
        }
    } catch (err) {
        console.error('Error fetching loyalty discount:', err);
    }
}

// Display order summary
function displayCheckoutSummary() {
    const items = cart.getItems();
    const itemsList = document.getElementById('checkoutItemsList');
    
    // Add Loyalty Reward Item to Display list if present (visual only here, added to order later)
    let displayItems = [...items];
    if (loyaltyRewardItem) {
        displayItems.push({
            name: `🎁 ${loyaltyRewardItem.name}`,
            quantity: 1,
            price: 0
        });
    }

    itemsList.innerHTML = displayItems.map(item => `
        <div style="display: flex; justify-content: space-between; margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px solid var(--border);">
            <div>
                <strong>${item.name}</strong>
                <p style="color: var(--gray); font-size: 14px;">Qty: ${item.quantity}</p>
                ${item.options && item.options.description ? `<p style="color: #666; font-size: 13px; margin-top: 4px;">${item.options.description}</p>` : (item.options && item.options.colors ? `<p style="color: #666; font-size: 13px; margin-top: 4px;">Colors: ${item.options.colors.join(', ')}</p>` : '')}
            </div>
            <div style="text-align: right;">
                <strong>${formatPrice(item.price * item.quantity)}</strong>
            </div>
        </div>
    `).join('');
    
    const subtotal = cart.getSubtotal();
    const shipping = 200; // Fixed delivery fee
    
    // Apply Discount
    const discountAmount = subtotal * loyaltyDiscount;
    // No Tax
    const tax = 0; 
    const total = (subtotal - discountAmount) + shipping + tax;
    
    document.getElementById('checkoutSubtotal').textContent = formatPrice(subtotal);
    
    // Discount Row
    let discountRow = document.getElementById('checkoutDiscountRow');
    if (!discountRow) {
        // Insert discount row if not exists
        const subtotalRow = document.getElementById('checkoutSubtotal').parentElement;
        discountRow = document.createElement('div');
        discountRow.id = 'checkoutDiscountRow';
        discountRow.style.display = 'flex';
        discountRow.style.justifyContent = 'space-between';
        discountRow.style.marginBottom = '10px';
        discountRow.style.color = '#10b981'; // Green
        discountRow.innerHTML = `<span>Discount</span><span id="checkoutDiscount"></span>`;
        subtotalRow.parentNode.insertBefore(discountRow, subtotalRow.nextSibling);
    }
    
    if (loyaltyDiscount > 0 || loyaltyRewardItem) {
        discountRow.style.display = 'flex';
        let discountText = loyaltyMessage;
        if (loyaltyDiscount > 0) {
            discountText += ` (-${formatPrice(discountAmount)})`;
        }
        document.getElementById('checkoutDiscount').textContent = discountText;
    } else {
        discountRow.style.display = 'none';
    }

    document.getElementById('checkoutShipping').textContent = formatPrice(shipping);
    document.getElementById('checkoutTax').textContent = formatPrice(tax);
    document.getElementById('checkoutTotal').textContent = formatPrice(total);
}

// Initialize checkout page
document.addEventListener('DOMContentLoaded', async () => {
    // Check if user is authenticated
    if (!isAuthenticated()) {
        alert('Please login to checkout');
        window.location.href = 'login.html';
        return;
    }
    
    // Check if cart has items
    if (cart.getItems().length === 0) {
        alert('Your cart is empty');
        window.location.href = 'box.html';
        return;
    }
    
    const customUserData = localStorage.getItem('custom_user_data');
    const user = window.netlifyIdentity ? netlifyIdentity.currentUser() : null;
    const isEmailPasswordAuth = user ? user.app_metadata?.provider === 'email' : false;
    
    let userEmail = '';

    if (customUserData) {
        const userData = JSON.parse(customUserData);
        document.getElementById('customerEmail').value = userData.email;
        userEmail = userData.email;
        
        const userName = localStorage.getItem('user_name') || `${userData.firstName} ${userData.lastName}`;
        if (userName) {
            document.getElementById('customerName').value = userName;
        }
    } else if (isEmailPasswordAuth) {
        // ... (existing verification check)
        userEmail = user.email;
         const verifiedStore = await checkEmailVerification(user.email);
        if (!verifiedStore) {
             // ... existing logic
             showPersistentNotification(
                'Email Verification Required',
                'Please verify your email address before placing orders. Check your inbox for the verification link.',
                'error'
            );
            setTimeout(() => {
                window.location.href = 'account.html';
            }, 3000);
            return;
        }
    }
    
    if (user && user.email) {
        document.getElementById('customerEmail').value = user.email;
        userEmail = user.email;
        
        // Also auto-fill name if available
        const userName = user.user_metadata?.full_name || localStorage.getItem('user_name');
        if (userName) {
            document.getElementById('customerName').value = userName;
        }
    }

    // Initialize Map
    initMap();

    // Fetch Loyalty Discount
    if (userEmail) {
        await fetchLoyaltyDiscount(userEmail);
    }
    
    // Listen for email changes (for guest checkout loyalty)
    const emailInput = document.getElementById('customerEmail');
    if (emailInput) {
        emailInput.addEventListener('blur', async (e) => {
            const email = e.target.value;
            if (email && email.includes('@')) {
                await fetchLoyaltyDiscount(email);
            }
        });
    }
    
    displayCheckoutSummary();


    // Form submission
    document.getElementById('checkoutForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // Phone Validation
        const phoneInput = document.getElementById('customerPhone');
        const phoneRegex = /^0\d{10}$/;
        if (!phoneRegex.test(phoneInput.value)) {
            alert('Please enter a valid phone number (11 digits starting with 0, e.g., 03001234567)');
            return;
        }
        
        if (!document.getElementById('confirmLocation').checked) {
            alert('Please confirm your delivery location on the map.');
            return;
        }

        const submitBtn = e.target.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        submitBtn.disabled = true;
        submitBtn.textContent = 'Processing...';
        
        const formData = new FormData(e.target);
        const paymentMethod = formData.get('paymentMethod');

        if (!paymentMethod) {
            alert('Please select a payment method.');
            submitBtn.disabled = false;
            submitBtn.textContent = originalText;
            return;
        }

        let items = [...cart.getItems()]; // Copy cart items
        // Add Loyalty Reward to Items List for backend processing
        if (loyaltyRewardItem) {
            items.push({
                id: loyaltyRewardItem.id,
                name: `🎁 ${loyaltyRewardItem.name}`,
                price: 0,
                quantity: 1,
                image: '', // Optional or placeholder
                category: 'reward'
            });
        }

        const subtotal = cart.getSubtotal();
        const shipping = 200; // Fixed delivery fee
        
        // Apply Discount
        const discountAmount = subtotal * loyaltyDiscount;
        const tax = 0; // No Tax
        const total = (subtotal - discountAmount) + shipping + tax;
        
        // Prepare order data
        const orderData = {
            items: items,
            total: total,
            subtotal: subtotal,
            discount: discountAmount,
            discountMessage: loyaltyMessage,
            paymentMethod: paymentMethod, // Add payment method
            shippingInfo: {
                name: formData.get('name'),
                email: formData.get('email'),
                phone: formData.get('phone'),
                country: 'Pakistan', // Enforce Pakistan
                city: 'Lahore',      // Enforce Lahore
                address: formData.get('address'),
                landmarkType: formData.get('landmarkType'),
                landmarkNote: formData.get('landmarkNote'),
                latitude: formData.get('latitude'),
                longitude: formData.get('longitude'),
                notes: formData.get('notes')
            }
        };
        
        // Add order items and total to form for Netlify submission
        document.getElementById('orderItems').value = JSON.stringify(items);
        document.getElementById('orderTotal').value = formatPrice(total);
        
        try {
            const tempOrder = orderHistory.addOrder(orderData);
            const orderId = tempOrder.id;

            // Clear cart immediately
            cart.clearCart();
            sessionStorage.removeItem('processedBoxItems');

            // Store order data for verification step
            sessionStorage.setItem('verificationOrderData', JSON.stringify(orderData));

            // Redirect to verification method selection
            const totalFormatted = encodeURIComponent(formatPrice(total));
            window.location.href = `verification-method.html?orderId=${orderId}&total=${totalFormatted}`;
            
        } catch (error) {
            console.error('Error submitting order:', error);
            
            let errorMessage = 'There was an error processing your order. ';
            
            if (error.message.includes('Failed to fetch')) {
                errorMessage += 'Please check your internet connection and try again.';
            } else if (error.message.includes('confirmation email')) {
                errorMessage += 'We could not send the confirmation email. Please check your email address and try again.';
            } else {
                errorMessage += error.message || 'Please try again or contact support.';
            }
            
            showPersistentNotification('Order Failed', errorMessage, 'error');
            submitBtn.disabled = false;
            submitBtn.textContent = originalText;
        }
    });
    
    // Leave feedback button
    document.getElementById('leaveFeedbackBtn').addEventListener('click', () => {
        document.getElementById('orderSuccessModal').style.display = 'none';
        document.getElementById('feedbackModal').style.display = 'flex';
    });
    
    // Close feedback modal
    document.getElementById('closeFeedbackModal').addEventListener('click', () => {
        document.getElementById('feedbackModal').style.display = 'none';
        window.location.href = 'index.html';
    });
    
    // Feedback form submission
    document.getElementById('feedbackForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        
        try {
            await fetch('/', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams(formData).toString()
            });
            
            alert('Thank you for your feedback!');
            window.location.href = 'index.html';
        } catch (error) {
            console.error('Error submitting feedback:', error);
            alert('Error submitting feedback. Please try again.');
        }
    });
    
    // Setup rating stars for feedback
    setupRatingStars('feedbackRatingInput', 'feedbackRating');
});

// Setup rating stars
function setupRatingStars(inputId, hiddenFieldId) {
    const ratingInput = document.getElementById(inputId);
    const stars = ratingInput.querySelectorAll('.star');
    const hiddenField = document.getElementById(hiddenFieldId);
    
    stars.forEach(star => {
        star.addEventListener('click', () => {
            const rating = parseInt(star.dataset.rating);
            hiddenField.value = rating;
            
            stars.forEach((s, index) => {
                if (index < rating) {
                    s.classList.add('active');
                } else {
                    s.classList.remove('active');
                }
            });
        });
        
        star.addEventListener('mouseenter', () => {
            const rating = parseInt(star.dataset.rating);
            stars.forEach((s, index) => {
                if (index < rating) {
                    s.style.color = '#fbbf24';
                }
            });
        });
    });
    
    ratingInput.addEventListener('mouseleave', () => {
        const currentRating = parseInt(hiddenField.value);
        stars.forEach((s, index) => {
            if (index >= currentRating) {
                s.style.color = '';
            }
        });
    });
    
    // Set initial rating to 5 stars
    stars.forEach(s => s.classList.add('active'));
}

// --- Interactive Map Logic ---

function initMap() {
    const mapElement = document.getElementById('map');
    const addressInput = document.getElementById('address');
    const useLocationBtn = document.getElementById('useLocation');
    const searchInput = document.getElementById('locationSearch');
    const searchResults = document.getElementById('searchResults');

    if (!mapElement || !window.L) return;

    // --- Configuration ---
    // Lahore Coordinates
    const lahoreCenter = [31.5204, 74.3587];
    // Strict bounds for Lahore
    const lahoreBounds = L.latLngBounds(
        [31.10, 74.00], // Southwest
        [31.85, 74.70]  // Northeast
    );

    // --- Map Initialization ---
    const map = L.map('map', {
        center: lahoreCenter,
        zoom: 13,
        minZoom: 11,
        maxBounds: lahoreBounds,
        maxBoundsViscosity: 1.0 // Sticky bounds
    });

    // CartoDB Dark Matter Tiles (Requested Style)
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        subdomains: 'abcd',
        maxZoom: 20
    }).addTo(map);

    // Draggable Marker
    const marker = L.marker(lahoreCenter, { draggable: true }).addTo(map);

    // --- Helpers ---
    
    async function reverseGeocode(lat, lon) {
        // Update hidden inputs
        const latInput = document.getElementById('latitude');
        const lonInput = document.getElementById('longitude');
        if (latInput) latInput.value = lat;
        if (lonInput) lonInput.value = lon;

        // Set loading state if needed, or just wait
        try {
            // Using the proxy function to keep API Key secure
            const response = await fetch(`/api/location-service?action=reverse&lat=${lat}&lon=${lon}`);
            
            if (!response.ok) {
                throw new Error('Geocoding service error');
            }
            
            const data = await response.json();
            
            if (data && data.address) {
                const a = data.address;
                // Custom Address Formatting Logic
                const formattedAddressParts = [
                  a.house_number ? `House ${a.house_number}` : null,
                  a.road,
                  a.neighbourhood || a.suburb,
                  a.city || 'Lahore'
                ].filter(Boolean);

                // Ensure 'Lahore' is at the end
                if (formattedAddressParts.length > 0 && formattedAddressParts[formattedAddressParts.length - 1] !== 'Lahore') {
                     formattedAddressParts.push('Lahore');
                }
                
                addressInput.value = formattedAddressParts.join(', ');
            } else {
                addressInput.value = "Unable to detect exact address. Adjust the pin slightly.";
            }
        } catch (error) {
            console.error('Reverse Geocoding Error:', error);
            addressInput.value = "Unable to detect exact address. Adjust the pin slightly.";
        }
    }

    function updateMarker(latlng) {
        if (!lahoreBounds.contains(latlng)) {
            alert('Orders are only accepted within Lahore.');
            // Do not move marker if outside
            return; 
        }
        marker.setLatLng(latlng);
        map.setView(latlng, 15); // Zoom in on selection
        reverseGeocode(latlng.lat, latlng.lng);
    }

    // --- Event Listeners ---

    // Marker Drag
    marker.on('dragend', function(e) {
        const latlng = e.target.getLatLng();
        if (lahoreBounds.contains(latlng)) {
            reverseGeocode(latlng.lat, latlng.lng);
        } else {
            alert('Orders are only accepted within Lahore.');
            // Reset to center if dragged out of bounds
            marker.setLatLng(map.getCenter());
            reverseGeocode(map.getCenter().lat, map.getCenter().lng);
        }
    });

    // Map Click
    map.on('click', function(e) {
        updateMarker(e.latlng);
    });

    // Use My Location
    if (useLocationBtn) {
        useLocationBtn.addEventListener('click', (e) => {
            e.preventDefault(); // Prevent form submission if inside form
            
            if (!navigator.geolocation) {
                alert('Geolocation is not supported by your browser.');
                return;
            }
            
            const originalText = useLocationBtn.textContent;
            useLocationBtn.textContent = 'Locating...';
            useLocationBtn.disabled = true;
            
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const lat = position.coords.latitude;
                    const lon = position.coords.longitude;
                    const latlng = L.latLng(lat, lon);
                    
                    if (lahoreBounds.contains(latlng)) {
                        updateMarker(latlng);
                    } else {
                        alert('Orders are only accepted within Lahore.');
                        // Do not move marker
                    }
                    useLocationBtn.textContent = originalText;
                    useLocationBtn.disabled = false;
                },
                (error) => {
                    console.error('Geolocation error:', error);
                    alert('Unable to retrieve your location. Please check your permissions.');
                    useLocationBtn.textContent = originalText;
                    useLocationBtn.disabled = false;
                },
                {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 0
                }
            );
        });
    }

    // --- Autocomplete ---
    let debounceTimer;
    
    searchInput.addEventListener('input', function(e) {
        const query = e.target.value;
        
        clearTimeout(debounceTimer);
        searchResults.style.display = 'none';
        searchResults.innerHTML = '';

        if (query.length < 3) return;

        debounceTimer = setTimeout(async () => {
            try {
                // Call proxy for autocomplete
                const response = await fetch(`/api/location-service?action=autocomplete&q=${encodeURIComponent(query)}`);
                if (!response.ok) return;
                
                const data = await response.json();
                
                if (Array.isArray(data) && data.length > 0) {
                    searchResults.innerHTML = '';
                    searchResults.style.display = 'block';
                    
                    data.forEach(place => {
                        const div = document.createElement('div');
                        div.className = 'search-result-item';
                        // Format display: show name and address parts
                        div.textContent = place.display_name;
                        
                        div.addEventListener('click', () => {
                            const lat = parseFloat(place.lat);
                            const lon = parseFloat(place.lon);
                            const latlng = L.latLng(lat, lon);
                            
                            updateMarker(latlng);
                            
                            // Close search
                            searchInput.value = ''; 
                            searchResults.style.display = 'none';
                        });
                        searchResults.appendChild(div);
                    });
                }
            } catch (err) {
                console.error('Search error:', err);
            }
        }, 300); // 300ms debounce
    });

    // Close search results when clicking outside
    document.addEventListener('click', (e) => {
        if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
            searchResults.style.display = 'none';
        }
    });
    
    // Initial geocode for the default center
    reverseGeocode(lahoreCenter[0], lahoreCenter[1]);
}