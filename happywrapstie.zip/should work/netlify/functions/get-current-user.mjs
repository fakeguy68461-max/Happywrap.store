import { getStore } from '@netlify/blobs';
import { getCookie } from './lib/auth.mjs';

export default async (req, context) => {
  const sessionToken = getCookie(req, 'session');

  if (!sessionToken) {
    return new Response(JSON.stringify({ authenticated: false }), {
      status: 200, // Not an error, just no session
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const sessionStore = getStore('sessions');
    const sessionDataStr = await sessionStore.get(sessionToken);

    if (!sessionDataStr) {
      return new Response(JSON.stringify({ authenticated: false }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const session = JSON.parse(sessionDataStr);
    
    // Check if session is too old (e.g., 30 days)
    const sessionDate = new Date(session.createdAt);
    const now = new Date();
    const ageInDays = (now - sessionDate) / (1000 * 60 * 60 * 24);
    
    if (ageInDays > 30) {
       await sessionStore.delete(sessionToken);
       return new Response(JSON.stringify({ authenticated: false }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Get user details
    const accountsStore = getStore('user-accounts');
    
    if (!session.email) {
        return new Response(JSON.stringify({ authenticated: false, reason: 'invalid_session_structure' }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' }
        });
    }

    const accountDataStr = await accountsStore.get(session.email);
    if (!accountDataStr) {
        return new Response(JSON.stringify({ authenticated: false, reason: 'user_not_found' }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' }
        });
    }

    const accountData = JSON.parse(accountDataStr);
    
    // Check if password is needed (for google users)
    const passwordStore = getStore('user-passwords');
    const passwordDataStr = await passwordStore.get(accountData.userId);
    let hasPassword = false;
    if (passwordDataStr) {
        const pd = JSON.parse(passwordDataStr);
        hasPassword = pd.hasPassword;
    }

    return new Response(JSON.stringify({
      authenticated: true,
      user: {
        id: accountData.userId,
        userId: accountData.userId,
        email: accountData.email,
        firstName: accountData.firstName,
        lastName: accountData.lastName,
        provider: accountData.provider,
        isGoogleAuth: accountData.provider === 'google',
        hasPassword: hasPassword,
        isAdmin: accountData.isAdmin || false,
        roles: accountData.roles || []
      }
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error getting current user:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

export const config = {
  path: '/api/get-current-user'
};
