import { getStore } from '@netlify/blobs';
import { normalizePhoneNumber, generateRandomOTP, hashOTP } from './lib/otp-utils.mjs';

export default async (req, context) => {
  // Only allow POST requests
  if (req.method !== 'POST') {
    return new Response('Method Not Allowed', { status: 405 });
  }

  try {
    const body = await req.json();
    const { phone, orderId } = body;

    if (!phone || !orderId) {
      return new Response(JSON.stringify({ error: 'Phone number and Order ID are required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // 1. Normalize phone number
    let normalizedPhone;
    try {
      normalizedPhone = normalizePhoneNumber(phone);
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // 2. Generate a 6-digit OTP
    const otp = generateRandomOTP();

    // 3. Prepare storage object
    const now = Date.now();
    const expiresAt = now + 10 * 60 * 1000; // 10 minutes from now
    const otpHash = hashOTP(otp);

    const otpData = {
      phone: normalizedPhone,
      orderId: orderId,
      otpHash,
      plainOtp: otp, // DEV ONLY
      expiresAt,
      attempts: 0,
      verified: false,
    };

    // 4. Store in Netlify Blobs 'otp_codes'
    // Key by Order ID to ensure one OTP per order and easy invalidation of previous ones
    const store = getStore('otp_codes');
    const key = `otp:${orderId}`;

    await store.setJSON(key, otpData);

    // 5. Return success
    console.log(`OTP generated for Order ${orderId} (${normalizedPhone}): ${otp}`);

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { 
        'Content-Type': 'application/json',
        'Cache-Control': 'no-store'
      },
    });

  } catch (error) {
    console.error('Error generating OTP:', error);
    return new Response(JSON.stringify({ error: 'Internal Server Error' }), {
      status: 500,
      headers: { 
        'Content-Type': 'application/json',
        'Cache-Control': 'no-store'
      },
    });
  }
};

export const config = {
  path: '/api/generate-otp'
};
