import { getStore } from '@netlify/blobs';
import { emailVerificationTemplate } from '../email-templates/index.js';
import { sendEmailSMTP } from './lib/smtp-mailer.mjs';
import { getSiteUrl } from './lib/getUrl.mjs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { userId, email, name } = await req.json();

    if (!userId || !email) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const verificationToken = generateToken();
    const store = getStore('email-verifications');
    
    await store.set(verificationToken, JSON.stringify({
      userId,
      email,
      name,
      createdAt: new Date().toISOString(),
      verified: false
    }), {
      metadata: { userId, email }
    });

    // ✅ FIXED: Use dynamic URL instead of hardcoded
    const siteUrl = getSiteUrl();
    const verificationLink = `${siteUrl}/verify-email.html?token=${verificationToken}`;

    console.log('Generated verification link:', verificationLink);
    console.log('Site URL being used:', siteUrl);

    const emailSubject = 'Verify Your Email - HappyWrap';
    const emailBody = emailVerificationTemplate({
      USER_NAME: name || email.split('@')[0],
      USER_EMAIL: email,
      VERIFICATION_LINK: verificationLink,
      EXPIRATION_TIME: '24 hours'
    });

    console.log('Attempting to send verification email to:', email);
    const emailSent = await sendEmailSMTP(email, emailSubject, emailBody);
    
    if (!emailSent) {
      console.error('❌ Failed to send verification email to:', email);
      console.error('Please check SMTP credentials and configuration');
      return new Response(JSON.stringify({ 
        error: 'Failed to send verification email. Please check your email address or contact support.',
        details: 'Email service configuration error'
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }
    
    console.log('✅ Verification email sent successfully to:', email);
    console.log('Verification token:', verificationToken);

    return new Response(JSON.stringify({ 
      success: true, 
      message: 'Verification email sent. Please check your inbox and spam folder. Emails may take a few minutes to arrive.',
      token: verificationToken
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('❌ Error sending verification email:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to send verification email',
      details: error.message 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

function generateToken() {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}`;
}

export const config = {
  path: '/api/send-verification-email'
};