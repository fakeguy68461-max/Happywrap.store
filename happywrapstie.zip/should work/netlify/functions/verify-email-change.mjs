import { getStore } from '@netlify/blobs';

export default async (req, context) => {
  if (req.method !== 'GET') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const url = new URL(req.url);
    const token = url.searchParams.get('token');

    if (!token) {
      return new Response(generateErrorPage('Invalid verification link'), {
        status: 400,
        headers: { 'Content-Type': 'text/html' }
      });
    }

    const emailChangeStore = getStore('email-changes');
    const changeRequest = await emailChangeStore.get(token, { type: 'json' });

    if (!changeRequest) {
      return new Response(generateErrorPage('Verification link is invalid or has already been used'), {
        status: 400,
        headers: { 'Content-Type': 'text/html' }
      });
    }

    if (Date.now() > changeRequest.expiresAt) {
      await emailChangeStore.delete(token);
      return new Response(generateErrorPage('Verification link has expired. Please request a new email change.'), {
        status: 400,
        headers: { 'Content-Type': 'text/html' }
      });
    }

    console.log('Email change verified for user:', changeRequest.userId);
    console.log('Old email:', changeRequest.oldEmail);
    console.log('New email:', changeRequest.newEmail);

    // Update the user-accounts store with the new email
    const accountsStore = getStore('user-accounts');
    const oldAccountDataStr = await accountsStore.get(changeRequest.oldEmail);

    if (!oldAccountDataStr) {
      return new Response(generateErrorPage('Account not found. Please contact support.'), {
        status: 404,
        headers: { 'Content-Type': 'text/html' }
      });
    }

    const accountData = JSON.parse(oldAccountDataStr);

    // Check that account is verified before allowing email change
    if (!accountData.verified) {
      return new Response(generateErrorPage('Your account must be verified before changing email. Please verify your original email first.'), {
        status: 400,
        headers: { 'Content-Type': 'text/html' }
      });
    }

    // Check if the new email is already in use
    const existingNewAccount = await accountsStore.get(changeRequest.newEmail);
    if (existingNewAccount) {
      await emailChangeStore.delete(token);
      return new Response(generateErrorPage('The new email address is already in use by another account.'), {
        status: 409,
        headers: { 'Content-Type': 'text/html' }
      });
    }

    // Update account with new email
    accountData.email = changeRequest.newEmail;
    accountData.emailChangedAt = new Date().toISOString();
    accountData.previousEmail = changeRequest.oldEmail;

    // Save account under the new email key
    await accountsStore.set(changeRequest.newEmail, JSON.stringify(accountData), {
      metadata: {
        userId: accountData.userId,
        email: changeRequest.newEmail,
        verified: accountData.verified ? 'true' : 'false'
      }
    });

    // Delete the old email entry
    await accountsStore.delete(changeRequest.oldEmail);

    // Update verified-emails store if it exists
    try {
      const verifiedStore = getStore('verified-emails');
      const verifiedDataStr = await verifiedStore.get(changeRequest.oldEmail);
      if (verifiedDataStr) {
        const verifiedData = JSON.parse(verifiedDataStr);
        verifiedData.email = changeRequest.newEmail;
        await verifiedStore.set(changeRequest.newEmail, JSON.stringify(verifiedData));
        await verifiedStore.delete(changeRequest.oldEmail);
      }
    } catch (verifiedStoreError) {
      console.error('Error updating verified-emails store:', verifiedStoreError);
    }

    // Update users store if it exists
    try {
      const usersStore = getStore('users');
      const userDataStr = await usersStore.get(accountData.userId);
      if (userDataStr) {
        const userData = JSON.parse(userDataStr);
        userData.email = changeRequest.newEmail;
        userData.emailChangedAt = accountData.emailChangedAt;
        await usersStore.set(accountData.userId, JSON.stringify(userData), {
          metadata: {
            email: changeRequest.newEmail,
            emailVerified: true
          }
        });
      }
    } catch (usersStoreError) {
      console.error('Error updating users store:', usersStoreError);
    }

    console.log(`✅ Email successfully changed from ${changeRequest.oldEmail} to ${changeRequest.newEmail}`);

    await emailChangeStore.delete(token);

    return new Response(generateSuccessPage(changeRequest.newEmail), {
      status: 200,
      headers: { 'Content-Type': 'text/html' }
    });

  } catch (error) {
    console.error('Error verifying email change:', error);
    return new Response(generateErrorPage('An error occurred while verifying your email change'), {
      status: 500,
      headers: { 'Content-Type': 'text/html' }
    });
  }
};

function generateSuccessPage(newEmail) {
  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Email Change Verified - HappyWrap</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .container {
      background: white;
      border-radius: 16px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      max-width: 500px;
      width: 100%;
      padding: 48px;
      text-align: center;
    }
    .icon {
      font-size: 64px;
      margin-bottom: 24px;
      animation: bounce 1s ease;
    }
    @keyframes bounce {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-20px); }
    }
    h1 {
      color: #10b981;
      font-size: 28px;
      margin-bottom: 16px;
    }
    p {
      color: #6b7280;
      font-size: 16px;
      line-height: 1.6;
      margin-bottom: 32px;
    }
    .email {
      background: #f0fdf4;
      color: #065f46;
      padding: 12px 20px;
      border-radius: 8px;
      font-weight: 600;
      margin-bottom: 32px;
      word-break: break-all;
    }
    .btn {
      display: inline-block;
      background: #10b981;
      color: white;
      padding: 14px 32px;
      border-radius: 8px;
      text-decoration: none;
      font-weight: 600;
      transition: background 0.3s;
    }
    .btn:hover {
      background: #059669;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="icon">✅</div>
    <h1>Email Change Verified!</h1>
    <p>Your email address has been successfully updated.</p>
    <div class="email">${newEmail}</div>
    <p>You can now use this email address to log in to your HappyWrap account.</p>
    <a href="/account.html" class="btn">Go to Account</a>
  </div>
</body>
</html>
  `;
}

function generateErrorPage(message) {
  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Verification Error - HappyWrap</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
      background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .container {
      background: white;
      border-radius: 16px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      max-width: 500px;
      width: 100%;
      padding: 48px;
      text-align: center;
    }
    .icon {
      font-size: 64px;
      margin-bottom: 24px;
    }
    h1 {
      color: #ef4444;
      font-size: 28px;
      margin-bottom: 16px;
    }
    p {
      color: #6b7280;
      font-size: 16px;
      line-height: 1.6;
      margin-bottom: 32px;
    }
    .btn {
      display: inline-block;
      background: #2563eb;
      color: white;
      padding: 14px 32px;
      border-radius: 8px;
      text-decoration: none;
      font-weight: 600;
      transition: background 0.3s;
      margin: 0 8px;
    }
    .btn:hover {
      background: #1d4ed8;
    }
    .btn-secondary {
      background: #6b7280;
    }
    .btn-secondary:hover {
      background: #4b5563;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="icon">❌</div>
    <h1>Verification Failed</h1>
    <p>${message}</p>
    <div>
      <a href="/account.html" class="btn">Go to Account</a>
      <a href="/login.html" class="btn btn-secondary">Login</a>
    </div>
  </div>
</body>
</html>
  `;
}

export const config = {
  path: '/api/verify-email-change'
};
