import { getStore } from '@netlify/blobs';
import { normalizeEmail, hashOTP } from './lib/otp-utils.mjs';

export default async (req, context) => {
  // Only allow POST requests
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method Not Allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  const headers = {
    'Content-Type': 'application/json',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Cache-Control': 'no-store'
  };

  try {
    const body = await req.json();
    const { email, otp, orderId } = body;

    if (!email || !otp) {
      return new Response(JSON.stringify({ error: 'Email and OTP are required' }), {
        status: 400,
        headers,
      });
    }

    // 1. Normalize email
    let normalizedEmail;
    try {
      normalizedEmail = normalizeEmail(email);
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), {
        status: 400,
        headers,
      });
    }

    // 2. Fetch OTP blob
    const store = getStore('otp_codes');
    const key = `otp:email:${normalizedEmail}`;
    let otpData = null;

    try {
        const rawData = await store.get(key);
        if (rawData) {
            otpData = JSON.parse(rawData);
        }
    } catch (e) {
        console.error('Error accessing OTP store:', e);
    }

    // If not found
    if (!otpData) {
      return new Response(JSON.stringify({ error: 'OTP not found or expired. Please request a new code.' }), {
        status: 400,
        headers,
      });
    }

    const now = Date.now();

    // 3. Check Expiry
    if (otpData.expiresAt && now > otpData.expiresAt) {
      try { await store.delete(key); } catch(e) {}
      return new Response(JSON.stringify({ error: 'OTP expired. Please request a new code.' }), {
        status: 400,
        headers,
      });
    }

    // 4. Check Attempts
    if (otpData.attempts && otpData.attempts >= 5) {
      try { await store.delete(key); } catch(e) {}
      return new Response(JSON.stringify({ error: 'Too many failed attempts. Please request a new code.' }), {
        status: 400,
        headers,
      });
    }

    // 5. Verify OTP
    const inputOtp = String(otp).trim();
    let isMatch = false;

    if (otpData.otpHash) {
      if (hashOTP(inputOtp) === otpData.otpHash) {
        isMatch = true;
      }
    } else if (otpData.plainOtp && inputOtp === String(otpData.plainOtp)) {
        // Fallback/Dev
        isMatch = true;
    }

    if (isMatch) {
        // Delete OTP blob immediately
        try { await store.delete(key); } catch(e) {}

        let userData = null;

        // 6. Confirm Order
        if (orderId) {
            try {
                const verificationStore = getStore('email-order-verifications');
                const orderRecordStr = await verificationStore.get(orderId);

                if (orderRecordStr) {
                    const orderRecord = JSON.parse(orderRecordStr);
                    
                    orderRecord.verified = true;
                    orderRecord.verifiedAt = new Date().toISOString();
                    
                    // Set status based on payment method
                    const paymentMethod = orderRecord.orderData?.paymentMethod;
                    if (paymentMethod === 'jazzcash') {
                        orderRecord.status = 'Waiting for payment';
                    } else {
                        orderRecord.status = 'Initializing';
                    }

                    // Save to confirmed-orders
                    const confirmedOrdersStore = getStore('confirmed-orders');
                    
                    const finalOrderRecord = {
                        ...orderRecord,
                        email: normalizedEmail, // Ensure normalized email is used
                        name: orderRecord.name || orderRecord.orderData?.shippingInfo?.name
                    };

                    await confirmedOrdersStore.setJSON(orderId, finalOrderRecord, {
                        metadata: {
                            email: finalOrderRecord.email,
                            confirmedAt: finalOrderRecord.verifiedAt
                        }
                    });

                    // Prepare User Data for Auto-Login
                    try {
                        const accountsStore = getStore('user-accounts');
                        const existingUser = await accountsStore.get(normalizedEmail);
                        
                        if (existingUser) {
                            // Registered User
                            userData = {
                                id: existingUser.id || existingUser.userId,
                                userId: existingUser.userId || existingUser.id,
                                email: existingUser.email,
                                firstName: existingUser.firstName,
                                lastName: existingUser.lastName,
                                provider: 'local' // or 'netlify-identity'
                            };
                        } else {
                            // Guest User
                            const fullName = finalOrderRecord.name || 'Guest';
                            const nameParts = fullName.split(' ');
                            userData = {
                                id: normalizedEmail,
                                userId: normalizedEmail,
                                email: normalizedEmail,
                                firstName: nameParts[0],
                                lastName: nameParts.slice(1).join(' ') || '',
                                provider: 'guest'
                            };
                        }
                    } catch (userErr) {
                        console.error('Error fetching user for auto-login:', userErr);
                    }
                }
            } catch (orderError) {
                console.error('Error confirming order:', orderError);
                // We still return success because the OTP was valid.
            }
        }

        return new Response(JSON.stringify({ 
            verified: true, 
            success: true,
            user: userData
        }), {
            status: 200,
            headers,
        });

    } else {
        // Invalid OTP
        otpData.attempts = (otpData.attempts || 0) + 1;
        try { await store.setJSON(key, otpData); } catch(e) {}

        return new Response(JSON.stringify({ verified: false, error: 'Invalid OTP code' }), {
            status: 200,
            headers,
        });
    }

  } catch (error) {
    console.error('Critical Error in verify-email-otp:', error);
    return new Response(JSON.stringify({ error: 'System busy, please try again later' }), {
      status: 500,
      headers,
    });
  }
};

export const config = {
  path: '/api/verify-email-otp'
};
