import { getStore } from '@netlify/blobs';
import { getSiteUrl } from './lib/getUrl.mjs';
import { verifyAuth } from './lib/auth.mjs';

export default async (req, context) => {
  if (req.method !== 'GET') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    // Authenticate (throws if invalid or not admin)
    await verifyAuth(req);

    // Fetch users from Blobs instead of Identity API
    const accountsStore = getStore('user-accounts');
    const { blobs } = await accountsStore.list();
    
    const userPromises = blobs.map(async (blob) => {
      try {
        const userDataStr = await accountsStore.get(blob.key);
        if (!userDataStr) return null;
        
        let userData;
        try {
            userData = JSON.parse(userDataStr);
        } catch (e) {
            console.error(`Invalid JSON for user ${blob.key}`);
            return null;
        }
        
        // Map Blob data to the format expected by admin-functions.js
        return {
          id: userData.email, // Use email as ID for easier lookup in admin table
          email: userData.email,
          isAdmin: userData.isAdmin, // Pass explicit isAdmin flag
          user_metadata: {
            full_name: `${userData.firstName || ''} ${userData.lastName || ''}`.trim() || userData.name || userData.email
          },
          app_metadata: {
            roles: userData.roles || (userData.isAdmin ? ['admin'] : []), 
            banned: userData.banned || false,
            provider: userData.provider || 'local'
          },
          last_sign_in_at: userData.lastLogin || userData.createdAt || new Date().toISOString(),
          created_at: userData.createdAt || new Date().toISOString()
        };
      } catch (e) {
        console.error(`Error processing user ${blob.key}:`, e);
        return null;
      }
    });

    const users = (await Promise.all(userPromises)).filter(u => u !== null);

    return new Response(JSON.stringify({ 
      success: true,
      users: users
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error fetching users:', error);
    const status = error.message.includes('Unauthorized') || error.message.includes('Forbidden') ? 401 : 500;
    return new Response(JSON.stringify({ 
      error: error.message || 'Failed to fetch users'
    }), {
      status: status,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};


export const config = {
  path: '/api/admin/get-users'
};
