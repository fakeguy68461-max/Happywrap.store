import { getStore } from '@netlify/blobs';
import { verifyAuth } from './lib/auth.mjs';

export default async (req, context) => {
  if (req.method !== 'GET') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    await verifyAuth(req);

    const store = getStore('confirmed-orders');
    const { blobs } = await store.list();
    
    const orders = [];
    for (const blob of blobs) {
      try {
        const orderDataString = await store.get(blob.key);
        if (orderDataString) {
          const orderData = JSON.parse(orderDataString);
          orders.push(orderData);
        }
      } catch (err) {
        console.error(`Error parsing order ${blob.key}:`, err);
      }
    }

    orders.sort((a, b) => {
      const dateA = new Date(a.confirmedAt || a.createdAt || 0);
      const dateB = new Date(b.confirmedAt || b.createdAt || 0);
      return dateB - dateA;
    });

    return new Response(JSON.stringify({ 
      success: true,
      orders: orders,
      count: orders.length
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error fetching orders:', error);
    const status = error.message.includes('Unauthorized') || error.message.includes('Forbidden') ? 401 : 500;
    return new Response(JSON.stringify({ 
      error: error.message || 'Failed to fetch orders' 
    }), {
      status: status,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

export const config = {
  path: '/api/admin/get-orders'
};