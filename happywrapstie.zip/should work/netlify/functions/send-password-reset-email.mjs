import { getStore } from '@netlify/blobs';
import { passwordResetTemplate, passwordResetPlainText } from '../email-templates/index.js';
import { sendEmailSMTP } from './lib/smtp-mailer.mjs';
import { getSiteUrl } from './lib/getUrl.mjs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { userId, email, userName } = await req.json();

    if (!userId || !email) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const resetToken = generateToken();
    const expiresAt = Date.now() + (60 * 60 * 1000);

    const passwordResetStore = getStore('password-resets');
    await passwordResetStore.setJSON(resetToken, {
      userId,
      email,
      expiresAt,
      createdAt: Date.now(),
      used: false
    });

    // ✅ FIXED: Use dynamic URL instead of hardcoded
    const siteUrl = getSiteUrl();
    const resetLink = `${siteUrl}/reset-password.html?token=${resetToken}`;

    console.log('Generated password reset link:', resetLink);
    console.log('Site URL being used:', siteUrl);

    const emailParams = {
      USER_NAME: userName || email.split('@')[0],
      RESET_LINK: resetLink,
      EXPIRATION_TIME: '1 hour'
    };

    const emailSubject = 'HappyWrap - Password Reset Request';
    const emailBody = passwordResetTemplate(emailParams);
    const emailPlainText = passwordResetPlainText(emailParams);

    console.log('Attempting to send password reset email to:', email);
    const emailSent = await sendEmailSMTP(email, emailSubject, emailBody, emailPlainText);

    if (!emailSent) {
      console.error('❌ Failed to send password reset email to:', email);
      console.error('Please check SMTP credentials and configuration');
      return new Response(JSON.stringify({
        error: 'Failed to send password reset email. Please try again or contact support.',
        details: 'Email service configuration error'
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    console.log('✅ Password reset email sent successfully to:', email);
    console.log('Reset token:', resetToken);

    return new Response(JSON.stringify({
      success: true,
      message: 'Password reset email sent successfully. Please check your inbox (and spam folder).'
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('❌ Error sending password reset email:', error);
    return new Response(JSON.stringify({
      error: 'Failed to send password reset email',
      details: error.message
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

function generateToken() {
  return Array.from({ length: 32 }, () =>
    Math.floor(Math.random() * 16).toString(16)
  ).join('');
}

export const config = {
  path: '/api/send-password-reset-email'
};