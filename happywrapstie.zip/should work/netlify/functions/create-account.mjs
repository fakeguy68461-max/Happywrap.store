import { getStore } from '@netlify/blobs';
import bcrypt from 'bcryptjs';
import { sendEmailSMTP } from './lib/smtp-mailer.mjs';
import { emailVerificationTemplate } from '../email-templates/index.js';
import { getSiteUrl } from './lib/getUrl.mjs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { firstName, lastName, email, dateOfBirth, password } = await req.json();

    if (!firstName || !lastName || !email || !dateOfBirth || !password) {
      return new Response(JSON.stringify({ error: 'All fields are required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return new Response(JSON.stringify({ error: 'Invalid email address' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const birthDate = new Date(dateOfBirth);
    const age = Math.floor((new Date() - birthDate) / (365.25 * 24 * 60 * 60 * 1000));
    if (age < 13) {
      return new Response(JSON.stringify({ error: 'You must be at least 13 years old to create an account' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    if (password.length < 6) {
      return new Response(JSON.stringify({ error: 'Password must be at least 6 characters long' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const accountsStore = getStore('user-accounts');
    const existingAccountStr = await accountsStore.get(email);
    let existingAccount = null;

    if (existingAccountStr) {
      existingAccount = JSON.parse(existingAccountStr);
      // If the account has a password, it's a full account - block duplicate signup
      if (existingAccount.hashedPassword) {
        return new Response(JSON.stringify({ error: 'An account with this email already exists' }), {
          status: 409,
          headers: { 'Content-Type': 'application/json' }
        });
      }
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const verificationToken = generateToken();
    const userId = existingAccount?.userId || generateUserId(); // Keep existing userId if stub

    // Merge new data with existing loyalty data if any
    const accountData = {
      ...existingAccount, // Preserves loyalty fields (total_completed_orders, etc.)
      userId,
      firstName,
      lastName,
      email,
      dateOfBirth,
      hashedPassword,
      verified: false,
      verificationToken,
      createdAt: existingAccount?.createdAt || new Date().toISOString()
    };

    await accountsStore.set(email, JSON.stringify(accountData), {
      metadata: { userId, email, verified: 'false' }
    });

    const siteUrl = getSiteUrl();
    const verificationLink = `${siteUrl}/verify-account.html?token=${verificationToken}&email=${encodeURIComponent(email)}`;

    const emailSubject = 'Welcome to HappyWrap - Please Verify Your Email Address';
    const emailBody = emailVerificationTemplate({
      USER_NAME: `${firstName} ${lastName}`,
      USER_EMAIL: email,
      VERIFICATION_LINK: verificationLink
    });

    const emailSent = await sendEmailSMTP(email, emailSubject, emailBody);

    if (!emailSent) {
      console.error('Failed to send verification email to:', email);
      return new Response(JSON.stringify({
        error: 'Failed to send verification email. Please check your email address or try again later.',
        accountCreated: true,
        userId
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    console.log('Account created for:', email);
    console.log('Verification token:', verificationToken);

    return new Response(JSON.stringify({ 
      success: true, 
      message: 'Account created successfully. Please check your email to verify your account.',
      userId
    }), {
      status: 201,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error creating account:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to create account',
      details: error.message 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

function generateToken() {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}`;
}

function generateUserId() {
  return `user_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
}

export const config = {
  path: '/api/create-account'
};
