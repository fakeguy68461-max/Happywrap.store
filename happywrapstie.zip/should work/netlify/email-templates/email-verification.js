export const emailVerificationTemplate = ({
  USER_NAME,
  USER_EMAIL,
  VERIFICATION_LINK,
  EXPIRATION_TIME = '24 hours'
}) => `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Verify Your Email</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f5f5f5;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5;">
    <tr>
      <td align="center" style="padding: 40px 20px;">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          
          <tr>
            <td style="padding: 40px 40px 30px; text-align: center; background: linear-gradient(135deg, #10b981 0%, #059669 100%); border-radius: 8px 8px 0 0;">
              <div style="margin-bottom: 15px; font-size: 50px;">✉️</div>
              <h1 style="margin: 0; color: #ffffff; font-size: 28px; font-weight: bold;">Verify Your Email</h1>
              <p style="margin: 10px 0 0; color: #d1fae5; font-size: 16px;">One last step to secure your account</p>
            </td>
          </tr>
          
          <tr>
            <td style="padding: 40px;">
              <h2 style="margin: 0 0 20px; color: #1f2937; font-size: 24px;">Hi ${USER_NAME}!</h2>
              
              <p style="margin: 0 0 20px; color: #4b5563; font-size: 16px; line-height: 1.6;">
                Thank you for being part of HappyWrap! To ensure the security of your account and unlock all features, please verify your email address.
              </p>
              
              <div style="margin: 30px 0; padding: 25px; background-color: #ecfdf5; border-left: 4px solid #10b981; border-radius: 4px;">
                <p style="margin: 0; color: #065f46; font-size: 15px; line-height: 1.6;">
                  <strong>Email to verify:</strong><br>
                  ${USER_EMAIL}
                </p>
              </div>
              
              <p style="margin: 0 0 30px; color: #4b5563; font-size: 16px; line-height: 1.6;">
                Click the button below to verify your email address:
              </p>
              
              <div style="margin: 30px 0; text-align: center;">
                <a href="${VERIFICATION_LINK}" 
                   style="display: inline-block; background-color: #10b981; color: #ffffff; padding: 16px 40px; text-decoration: none; border-radius: 6px; font-size: 16px; font-weight: bold;">
                  Verify Email Address
                </a>
              </div>
              
              <div style="margin: 30px 0; padding: 25px; background-color: #f0f9ff; border-radius: 8px;">
                <h3 style="margin: 0 0 15px; color: #1f2937; font-size: 18px;">🎯 Why verify your email?</h3>
                <ul style="margin: 0; padding-left: 20px; color: #4b5563; font-size: 14px; line-height: 1.8;">
                  <li>Secure your account from unauthorized access</li>
                  <li>Receive order confirmations and shipping updates</li>
                  <li>Get exclusive deals and promotions</li>
                  <li>Enable password recovery</li>
                  <li>Access all account features</li>
                </ul>
              </div>
              
              <div style="margin-top: 30px; padding: 20px; background-color: #f9fafb; border-radius: 6px;">
                <p style="margin: 0 0 10px; color: #1f2937; font-size: 14px; font-weight: 600;">
                  ⏱️ Link expires in ${EXPIRATION_TIME}
                </p>
                <p style="margin: 0; color: #6b7280; font-size: 13px; line-height: 1.6;">
                  This verification link will expire after ${EXPIRATION_TIME}. If it expires, you can request a new verification email from your account settings.
                </p>
              </div>
              
              <div style="margin-top: 30px; padding-top: 30px; border-top: 1px solid #e5e7eb;">
                <p style="margin: 0 0 10px; color: #6b7280; font-size: 13px; line-height: 1.6;">
                  Can't click the button? Copy and paste this link into your browser:
                </p>
                <p style="margin: 0; color: #2563eb; font-size: 12px; word-break: break-all;">
                  ${VERIFICATION_LINK}
                </p>
              </div>
              
              <div style="margin-top: 30px; padding: 20px; background-color: #fef2f2; border-radius: 6px; border-left: 4px solid #ef4444;">
                <p style="margin: 0 0 10px; color: #991b1b; font-size: 14px; font-weight: 600;">
                  ⚠️ Didn't create an account?
                </p>
                <p style="margin: 0; color: #7f1d1d; font-size: 13px; line-height: 1.6;">
                  If you didn't create a HappyWrap account, please ignore this email or contact support if you're concerned about the security of your information.
                </p>
              </div>
            </td>
          </tr>
          
          <tr>
            <td style="padding: 30px 40px; background-color: #f9fafb; border-radius: 0 0 8px 8px; text-align: center;">
              <p style="margin: 0 0 10px; color: #6b7280; font-size: 14px;">
                Need help? Contact us at <a href="mailto:support@happywrap.com" style="color: #2563eb; text-decoration: none;">support@happywrap.com</a>
              </p>
              <p style="margin: 0; color: #9ca3af; font-size: 12px;">
                © 2025 HappyWrap. All rights reserved.
              </p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
`;
