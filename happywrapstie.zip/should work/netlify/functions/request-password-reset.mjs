import { getStore } from '@netlify/blobs';
import { passwordResetTemplate, passwordResetPlainText } from '../email-templates/index.js';
import { sendEmailSMTP } from './lib/smtp-mailer.mjs';
import { getSiteUrl } from './lib/getUrl.mjs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { email } = await req.json();

    if (!email) {
      return new Response(JSON.stringify({ error: 'Email is required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return new Response(JSON.stringify({ error: 'Invalid email address' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const accountsStore = getStore('user-accounts');
    const accountDataStr = await accountsStore.get(email);

    // For security, always return success even if account doesn't exist
    // This prevents email enumeration attacks
    if (!accountDataStr) {
      console.log('Password reset requested for non-existent account:', email);
      return new Response(JSON.stringify({
        success: true,
        message: 'If an account exists with this email, you will receive a password reset link.'
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const accountData = JSON.parse(accountDataStr);

    // Check if account is verified
    if (!accountData.verified) {
      console.log('Password reset requested for unverified account:', email);
      return new Response(JSON.stringify({
        error: 'This account has not been verified yet. Please verify your email first or request a new verification email.',
        needsVerification: true
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Generate password reset token
    const resetToken = generateToken();
    const expiresAt = Date.now() + (60 * 60 * 1000); // 1 hour expiration

    // Store the reset token
    const passwordResetStore = getStore('password-resets');
    await passwordResetStore.setJSON(resetToken, {
      userId: accountData.userId,
      email: email,
      expiresAt,
      createdAt: Date.now(),
      used: false
    });

    // Generate reset link
    const siteUrl = getSiteUrl();
    const resetLink = `${siteUrl}/reset-password.html?token=${resetToken}`;

    console.log('Generated password reset link:', resetLink);

    // Get user name for email
    const userName = accountData.firstName
      ? `${accountData.firstName} ${accountData.lastName || ''}`.trim()
      : email.split('@')[0];

    // Prepare email content
    const emailParams = {
      USER_NAME: userName,
      RESET_LINK: resetLink,
      EXPIRATION_TIME: '1 hour'
    };

    const emailSubject = 'HappyWrap - Password Reset Request';
    const emailBody = passwordResetTemplate(emailParams);
    const emailPlainText = passwordResetPlainText(emailParams);

    // Send email
    console.log('Sending password reset email to:', email);
    const emailSent = await sendEmailSMTP(email, emailSubject, emailBody, emailPlainText);

    if (!emailSent) {
      console.error('Failed to send password reset email to:', email);
      return new Response(JSON.stringify({
        error: 'Failed to send password reset email. Please try again later.',
        details: 'Email service configuration error'
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    console.log('Password reset email sent successfully to:', email);

    return new Response(JSON.stringify({
      success: true,
      message: 'Password reset email sent successfully. Please check your inbox.'
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error requesting password reset:', error);
    return new Response(JSON.stringify({
      error: 'Failed to process password reset request',
      details: error.message
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

function generateToken() {
  return Array.from({ length: 32 }, () =>
    Math.floor(Math.random() * 16).toString(16)
  ).join('');
}

export const config = {
  path: '/api/request-password-reset'
};
