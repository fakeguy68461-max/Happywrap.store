import { getStore } from '@netlify/blobs';
import { normalizePhoneNumber, hashOTP } from './lib/otp-utils.mjs';

export default async (req, context) => {
  // Only allow POST requests
  if (req.method !== 'POST') {
    return new Response('Method Not Allowed', { status: 405 });
  }

  const headers = {
    'Content-Type': 'application/json',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    'Cache-Control': 'no-store'
  };

  try {
    const body = await req.json();
    const { phone, otp, orderId } = body;

    console.log(`[verify-otp] Attempting verification for phone: ${phone}, orderId: ${orderId}`);

    if (!phone || !otp) {
      return new Response(JSON.stringify({ error: 'Phone number and OTP are required' }), {
        status: 400,
        headers,
      });
    }

    // 1. Normalize phone number
    let normalizedPhone;
    try {
      normalizedPhone = normalizePhoneNumber(phone);
    } catch (e) {
      console.error('[verify-otp] Phone normalization error:', e.message);
      return new Response(JSON.stringify({ error: e.message }), {
        status: 400,
        headers,
      });
    }

    // 2. Fetch OTP record from 'otp_codes' store
    const store = getStore('otp_codes');
    // Key by Order ID now
    const key = `otp:${orderId}`; 
    console.log('[OTP_DEBUG] Looking up OTP at key:', key);
    let otpData = null;
    
    try {
        // Use get() instead of getJSON() to safely handle missing keys (returns null)
        // and avoid throwing errors for non-existent blobs
        const rawData = await store.get(key);
        if (rawData) {
            try {
                otpData = JSON.parse(rawData);
            } catch (parseErr) {
                console.error('[verify-otp] Error parsing OTP JSON:', parseErr);
                // If data is corrupt, treat as not found/expired
                otpData = null;
            }
        }
    } catch (e) {
        console.error('[verify-otp] Error accessing OTP store:', e);
        // Continue with otpData = null
    }

    // If not found
    if (!otpData) {
      console.log(`[verify-otp] OTP not found for key: ${key}`);
      return new Response(JSON.stringify({ error: 'OTP not found or expired. Please request a new code.' }), {
        status: 400,
        headers,
      });
    }

    // Security Check: Ensure phone matches
    if (otpData.phone !== normalizedPhone) {
        console.warn(`[verify-otp] Phone mismatch for order ${orderId}. Expected ${otpData.phone}, got ${normalizedPhone}`);
        return new Response(JSON.stringify({ error: 'Phone number does not match the order request.' }), {
            status: 400,
            headers,
        });
    }

    const now = Date.now();

    // 3. Check Expiry
    if (otpData.expiresAt && now > otpData.expiresAt) {
      console.log(`[verify-otp] OTP expired for key: ${key}`);
      try {
        await store.delete(key);
      } catch(e) { console.error('[verify-otp] Failed to delete expired OTP:', e); }

      return new Response(JSON.stringify({ error: 'OTP expired. Please request a new code.' }), {
        status: 400,
        headers,
      });
    }

    // 4. Check Attempts
    if (otpData.attempts && otpData.attempts >= 5) {
      console.log(`[verify-otp] Too many attempts for key: ${key}`);
      try {
        await store.delete(key);
      } catch(e) { console.error('[verify-otp] Failed to delete max-attempt OTP:', e); }

      return new Response(JSON.stringify({ error: 'Too many failed attempts. Please request a new code.' }), {
        status: 400,
        headers,
      });
    }

    // 5. Verify OTP
    const inputOtp = String(otp).trim();
    let isMatch = false;

    // Check against hashed OTP (Primary method)
    if (otpData.otpHash) {
      const inputHash = hashOTP(inputOtp);
      if (inputHash === otpData.otpHash) {
        isMatch = true;
      }
    } 
    // Fallback: Check against plain OTP (Legacy/Dev) - ensuring we check exactly what is saved
    else if (otpData.plainOtp && inputOtp === String(otpData.plainOtp)) {
      isMatch = true;
    }
    // Fallback: Old format
    else if (otpData.otp && inputOtp === String(otpData.otp)) {
      isMatch = true;
    }

    if (isMatch) {
      console.log(`[verify-otp] OTP matched for key: ${key}`);
      
      // Delete OTP blob immediately to prevent replay
      try {
        await store.delete(key);
      } catch(e) { console.error('[verify-otp] Failed to delete verified OTP (non-critical):', e); }

      // 6. Confirm Order (if orderId provided)
      let userData = null;
      if (orderId) {
        try {
            console.log(`[verify-otp] Processing confirmation for orderId: ${orderId}`);
            const whatsappStore = getStore('whatsapp-verifications');
            const orderRecordStr = await whatsappStore.get(orderId);
            
            if (orderRecordStr) {
              let orderRecord;
              try {
                  orderRecord = JSON.parse(orderRecordStr);
              } catch (parseErr) {
                  console.error(`[verify-otp] Failed to parse order record for ${orderId}:`, parseErr);
                  throw new Error('Invalid order record format');
              }

              orderRecord.verified = true;
              orderRecord.verifiedAt = new Date().toISOString();
              
              // Set status based on payment method
              const paymentMethod = orderRecord.orderData?.paymentMethod;
              if (paymentMethod === 'jazzcash') {
                  orderRecord.status = 'payment_confirming';
              } else {
                  orderRecord.status = 'initializing';
              }
              
              // Update whatsapp verifications store
              await whatsappStore.set(orderId, JSON.stringify(orderRecord));
              
              // Save to confirmed-orders store for order history
              const confirmedOrdersStore = getStore('confirmed-orders');
              
              // Enrich order record with top-level fields required by get-user-orders
              const finalOrderRecord = {
                  ...orderRecord,
                  email: orderRecord.orderData?.shippingInfo?.email,
                  name: orderRecord.orderData?.shippingInfo?.name
              };

              // Ensure we are saving it correctly for get-user-orders to find it
              await confirmedOrdersStore.setJSON(orderId, finalOrderRecord, {
                  metadata: {
                      email: finalOrderRecord.email,
                      confirmedAt: finalOrderRecord.verifiedAt
                  }
              });
              
              // Prepare User Data for Auto-Login
              try {
                  const email = finalOrderRecord.email;
                  if (email) {
                      const accountsStore = getStore('user-accounts');
                      const existingUser = await accountsStore.get(email);
                      
                      if (existingUser) {
                          // Registered User
                          userData = {
                              id: existingUser.id || existingUser.userId,
                              userId: existingUser.userId || existingUser.id,
                              email: existingUser.email,
                              firstName: existingUser.firstName,
                              lastName: existingUser.lastName,
                              provider: 'local'
                          };
                      } else {
                          // Guest User
                          const fullName = finalOrderRecord.name || 'Guest';
                          const nameParts = fullName.split(' ');
                          userData = {
                              id: email,
                              userId: email,
                              email: email,
                              firstName: nameParts[0],
                              lastName: nameParts.slice(1).join(' ') || '',
                              provider: 'guest'
                          };
                      }
                  }
              } catch (userErr) {
                  console.error('[verify-otp] Error fetching user for auto-login:', userErr);
              }

              console.log(`[verify-otp] Order ${orderId} confirmed via OTP and saved to history`);
            } else {
                console.warn(`[verify-otp] Order record not found in 'whatsapp-verifications' for orderId: ${orderId}`);
                // Since user explicitly asked to direct to order confirmed page if OTP is correct,
                // we still return success here, but the order details might be missing on the confirmation page
                // if it relies on fetching this order.
            }
        } catch (orderError) {
            console.error('[verify-otp] Error confirming order:', orderError);
            // Don't fail the request if OTP was valid, but log the error.
            // Returning success will redirect user to confirmation page.
        }
      }

      return new Response(JSON.stringify({ 
          verified: true, 
          success: true,
          user: userData
      }), {
        status: 200,
        headers,
      });
    } else {
      // No match
      console.log(`[verify-otp] Invalid OTP for key: ${key}`);
      
      // Update attempts
      otpData.attempts = (otpData.attempts || 0) + 1;
      try {
        await store.setJSON(key, otpData);
      } catch(e) { console.error('[verify-otp] Failed to update attempts:', e); }

      return new Response(JSON.stringify({ verified: false, error: 'Invalid OTP code' }), {
        status: 200, 
        headers,
      });
    }

  } catch (error) {
    console.error('[verify-otp] Critical Error:', error);
    // Even in critical error, try to return JSON so frontend can display message
    return new Response(JSON.stringify({ error: 'System busy, please try again later' }), {
      status: 500,
      headers,
    });
  }
};

export const config = {
  path: '/api/verify-otp'
};
