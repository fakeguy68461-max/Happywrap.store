import { getStore } from '@netlify/blobs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { token } = await req.json();

    if (!token) {
      return new Response(JSON.stringify({
        valid: false,
        error: 'Token is required'
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const passwordResetStore = getStore('password-resets');
    const resetData = await passwordResetStore.get(token, { type: 'json' });

    if (!resetData) {
      return new Response(JSON.stringify({
        valid: false,
        error: 'Invalid or expired reset token'
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Check if token has expired (1 hour)
    if (Date.now() > resetData.expiresAt) {
      // Clean up expired token
      await passwordResetStore.delete(token);
      return new Response(JSON.stringify({
        valid: false,
        error: 'This password reset link has expired. Please request a new one.'
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Check if token has already been used
    if (resetData.used) {
      return new Response(JSON.stringify({
        valid: false,
        error: 'This password reset link has already been used.'
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    console.log('Reset token validated for email:', resetData.email);

    return new Response(JSON.stringify({
      valid: true,
      email: resetData.email
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error validating reset token:', error);
    return new Response(JSON.stringify({
      valid: false,
      error: 'Failed to validate reset token',
      details: error.message
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

export const config = {
  path: '/api/validate-reset-token'
};
