export const passwordResetTemplate = ({
  USER_NAME,
  RESET_LINK,
  EXPIRATION_TIME = '1 hour'
}) => `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HappyWrap - Password Reset Request</title>
</head>
<body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background-color: #f5f7fa;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f7fa;">
    <tr>
      <td align="center" style="padding: 40px 20px;">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.07);">

          <!-- Header with Branding -->
          <tr>
            <td style="padding: 45px 40px 35px; text-align: center; background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%); border-radius: 12px 12px 0 0;">
              <h1 style="margin: 0; color: #ffffff; font-size: 32px; font-weight: 700; letter-spacing: -0.5px;">HappyWrap</h1>
              <p style="margin: 8px 0 0; color: #dbeafe; font-size: 14px; font-weight: 500;">Your Trusted Shopping Platform</p>
            </td>
          </tr>

          <!-- Main Content -->
          <tr>
            <td style="padding: 45px 40px;">

              <!-- Security Icon -->
              <div style="text-align: center; margin-bottom: 32px;">
                <div style="display: inline-block; width: 90px; height: 90px; background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); border-radius: 50%; line-height: 90px; box-shadow: 0 2px 8px rgba(251, 191, 36, 0.3);">
                  <span style="font-size: 45px;">🔐</span>
                </div>
              </div>

              <!-- Greeting -->
              <h2 style="margin: 0 0 24px; color: #111827; font-size: 26px; font-weight: 600; text-align: center; letter-spacing: -0.3px;">Password Reset Request</h2>

              <p style="margin: 0 0 18px; color: #374151; font-size: 16px; line-height: 1.7;">
                Hello <strong>${USER_NAME}</strong>,
              </p>

              <p style="margin: 0 0 18px; color: #4b5563; font-size: 16px; line-height: 1.7;">
                We received a request to reset the password for your HappyWrap account. This is a routine security procedure to help you regain access to your account safely and securely.
              </p>

              <p style="margin: 0 0 18px; color: #4b5563; font-size: 16px; line-height: 1.7;">
                To proceed with resetting your password, please click the button below. You'll be taken to a secure page where you can create a new password for your account.
              </p>

              <!-- CTA Button -->
              <div style="margin: 40px 0; text-align: center;">
                <a href="${RESET_LINK}"
                   style="display: inline-block; background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%); color: #ffffff; padding: 18px 48px; text-decoration: none; border-radius: 8px; font-size: 17px; font-weight: 600; box-shadow: 0 4px 12px rgba(37, 99, 235, 0.25); transition: all 0.3s ease;">
                  Reset Your Password Securely
                </a>
              </div>

              <!-- Alternative Link -->
              <p style="margin: 24px 0; color: #6b7280; font-size: 14px; line-height: 1.7; padding: 18px; background-color: #f9fafb; border-radius: 6px; border: 1px solid #e5e7eb;">
                <strong>Button not working?</strong> Copy and paste this secure link into your web browser:<br><br>
                <span style="word-break: break-all; color: #2563eb; font-size: 13px;">${RESET_LINK}</span>
              </p>

              <!-- Security Warning -->
              <div style="margin-top: 35px; padding: 24px; background-color: #fef2f2; border-left: 5px solid #ef4444; border-radius: 6px;">
                <p style="margin: 0 0 14px; color: #991b1b; font-size: 15px; font-weight: 700;">
                  🛡️ Important Security Information
                </p>
                <ul style="margin: 0; padding-left: 24px; color: #7f1d1d; font-size: 14px; line-height: 1.9;">
                  <li style="margin-bottom: 8px;">This password reset link will <strong>expire in ${EXPIRATION_TIME}</strong> for your security</li>
                  <li style="margin-bottom: 8px;">If you did not request a password reset, you can safely ignore this email – your account remains secure</li>
                  <li style="margin-bottom: 8px;">Your current password will remain active until you complete the reset process</li>
                  <li style="margin-bottom: 8px;">Never share this link with anyone, including FrostLine support staff</li>
                  <li>If you're concerned about unauthorized access, please contact our security team immediately</li>
                </ul>
              </div>

              <!-- Account Security Tips -->
              <div style="margin-top: 40px; padding-top: 32px; border-top: 2px solid #e5e7eb;">
                <h3 style="margin: 0 0 18px; color: #111827; font-size: 19px; font-weight: 600;">Creating a Strong Password</h3>
                <p style="margin: 0 0 16px; color: #4b5563; font-size: 15px; line-height: 1.7;">
                  When choosing your new password, keep these best practices in mind to keep your HappyWrap account secure:
                </p>
                <ul style="margin: 0; padding-left: 24px; color: #4b5563; font-size: 14px; line-height: 2;">
                  <li style="margin-bottom: 8px;">Use at least 12 characters (longer is better)</li>
                  <li style="margin-bottom: 8px;">Combine uppercase and lowercase letters, numbers, and special symbols</li>
                  <li style="margin-bottom: 8px;">Avoid using easily guessable information like birthdays, names, or common words</li>
                  <li style="margin-bottom: 8px;">Don't reuse passwords from other accounts or websites</li>
                  <li>Consider using a reputable password manager to generate and store secure passwords</li>
                </ul>
              </div>

              <!-- Additional Help -->
              <div style="margin-top: 35px; padding: 24px; background-color: #f0f9ff; border-radius: 8px; border: 1px solid #bfdbfe;">
                <p style="margin: 0; color: #1e40af; font-size: 14px; line-height: 1.8; text-align: center;">
                  <strong>Need assistance?</strong> Our support team is here to help you 24/7. If you're experiencing issues with the password reset process or have questions about your account security, please don't hesitate to reach out.
                </p>
              </div>

              <!-- Reason for Email -->
              <div style="margin-top: 35px; padding-top: 28px; border-top: 1px solid #e5e7eb;">
                <p style="margin: 0; color: #6b7280; font-size: 13px; line-height: 1.7; text-align: center;">
                  <em>You're receiving this email because a password reset was requested for the HappyWrap account associated with this email address. This is an automated security message from our system.</em>
                </p>
              </div>

            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="padding: 35px 40px; background-color: #f9fafb; border-radius: 0 0 12px 12px; text-align: center; border-top: 1px solid #e5e7eb;">
              <p style="margin: 0 0 12px; color: #6b7280; font-size: 15px; font-weight: 500;">
                Questions or concerns? We're here to help!
              </p>
              <p style="margin: 0 0 18px; color: #6b7280; font-size: 14px;">
                Contact our support team at <a href="mailto:support@happywrap.com" style="color: #2563eb; text-decoration: none; font-weight: 600;">support@happywrap.com</a>
              </p>
              <p style="margin: 0 0 8px; color: #9ca3af; font-size: 12px;">
                HappyWrap – Secure Shopping You Can Trust
              </p>
              <p style="margin: 0; color: #9ca3af; font-size: 12px;">
                © 2025 HappyWrap. All rights reserved.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>
`;

// Plain-text version of the password reset email
export const passwordResetPlainText = ({
  USER_NAME,
  RESET_LINK,
  EXPIRATION_TIME = '1 hour'
}) => `
HappyWrap - Password Reset Request
==========================================

Hello ${USER_NAME},

We received a request to reset the password for your HappyWrap account. This is a routine security procedure to help you regain access to your account safely and securely.

To proceed with resetting your password, please use the following secure link. You'll be taken to a page where you can create a new password for your account.

Reset Your Password:
${RESET_LINK}

IMPORTANT SECURITY INFORMATION:
⚠️ This password reset link will expire in ${EXPIRATION_TIME} for your security
⚠️ If you did not request a password reset, you can safely ignore this email – your account remains secure
⚠️ Your current password will remain active until you complete the reset process
⚠️ Never share this link with anyone, including HappyWrap support staff
⚠️ If you're concerned about unauthorized access, please contact our security team immediately

Creating a Strong Password
--------------------------
When choosing your new password, keep these best practices in mind to keep your HappyWrap account secure:

• Use at least 12 characters (longer is better)
• Combine uppercase and lowercase letters, numbers, and special symbols
• Avoid using easily guessable information like birthdays, names, or common words
• Don't reuse passwords from other accounts or websites
• Consider using a reputable password manager to generate and store secure passwords

Need Assistance?
Our support team is here to help you 24/7. If you're experiencing issues with the password reset process or have questions about your account security, please don't hesitate to reach out.

Contact our support team at: support@happywrap.com

---
You're receiving this email because a password reset was requested for the HappyWrap account associated with this email address. This is an automated security message from our system.

HappyWrap – Secure Shopping You Can Trust
© 2025 HappyWrap. All rights reserved.
`;
