export { orderConfirmationTemplate, formatOrderItems } from './order-confirmation.js';
export { passwordResetTemplate } from './password-reset.js';
export { signupWelcomeTemplate } from './signup-welcome.js';
export { emailChangeVerificationTemplate } from './email-change-verification.js';
export { emailVerificationTemplate } from './email-verification.js';

export const renderTemplate = (templateFunction, variables) => {
  try {
    return templateFunction(variables);
  } catch (error) {
    console.error('Error rendering email template:', error);
    throw new Error(`Failed to render email template: ${error.message}`);
  }
};

export const createEmailPayload = (to, subject, htmlBody, fromEmail = 'noreply@happywrap.com', fromName = 'HappyWrap') => {
  return {
    to,
    from: { email: fromEmail, name: fromName },
    subject,
    htmlBody
  };
};

export const postConfirmationTemplate = ({
  CUSTOMER_NAME,
  ORDER_NUMBER,
  ORDER_DATE,
  ORDER_ITEMS,
  TOTAL,
  SHIPPING_ADDRESS,
  ESTIMATED_DELIVERY,
  TRACKING_LINK
}) => `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Confirmed</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f5f5f5;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5;">
    <tr>
      <td align="center" style="padding: 40px 20px;">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          
          <tr>
            <td style="padding: 40px 40px 30px; text-align: center; background-color: #10b981; border-radius: 8px 8px 0 0;">
              <div style="margin-bottom: 15px; font-size: 50px;">✓</div>
              <h1 style="margin: 0; color: #ffffff; font-size: 28px; font-weight: bold;">Order Confirmed!</h1>
              <p style="margin: 10px 0 0; color: #d1fae5; font-size: 16px;">Thank you for your purchase</p>
            </td>
          </tr>
          
          <tr>
            <td style="padding: 40px;">
              <h2 style="margin: 0 0 20px; color: #1f2937; font-size: 24px;">Hi ${CUSTOMER_NAME},</h2>
              
              <p style="margin: 0 0 20px; color: #4b5563; font-size: 16px; line-height: 1.6;">
                Great news! Your order has been confirmed and is now being processed. We'll send you another email with tracking information once your order ships.
              </p>
              
              <div style="margin: 30px 0; padding: 25px; background-color: #ecfdf5; border-left: 4px solid #10b981; border-radius: 4px;">
                <p style="margin: 0; color: #065f46; font-size: 15px; line-height: 1.6;">
                  <strong>Order #${ORDER_NUMBER}</strong> is confirmed!<br>
                  Expected delivery: <strong>${ESTIMATED_DELIVERY || '3-5 business days'}</strong>
                </p>
              </div>
              
              <div style="margin-top: 40px;">
                <h3 style="margin: 0 0 20px; color: #1f2937; font-size: 20px;">Order Summary</h3>
                
                <div style="margin: 20px 0;">
                  ${ORDER_ITEMS}
                </div>
                
                <div style="margin-top: 25px; padding-top: 20px; border-top: 2px solid #e5e7eb; text-align: right;">
                  <p style="margin: 0; color: #1f2937; font-size: 20px; font-weight: bold;">
                    Total: <span style="color: #10b981;">$${TOTAL}</span>
                  </p>
                </div>
              </div>
              
              <div style="margin-top: 30px; padding: 20px; background-color: #f9fafb; border-radius: 6px;">
                <h4 style="margin: 0 0 10px; color: #1f2937; font-size: 16px;">Shipping To:</h4>
                <p style="margin: 0; color: #4b5563; font-size: 14px; line-height: 1.6; white-space: pre-line;">${SHIPPING_ADDRESS}</p>
              </div>
              
              ${TRACKING_LINK ? `
              <div style="margin: 30px 0; text-align: center;">
                <a href="${TRACKING_LINK}" 
                   style="display: inline-block; background-color: #2563eb; color: #ffffff; padding: 16px 40px; text-decoration: none; border-radius: 6px; font-size: 16px; font-weight: bold;">
                  Track Your Order
                </a>
              </div>
              ` : ''}
              
              <div style="margin-top: 40px; padding-top: 30px; border-top: 1px solid #e5e7eb;">
                <h3 style="margin: 0 0 15px; color: #1f2937; font-size: 18px;">What Happens Next?</h3>
                <ol style="margin: 0; padding-left: 20px; color: #4b5563; font-size: 14px; line-height: 1.8;">
                  <li>We're preparing your order for shipment</li>
                  <li>You'll receive a shipping confirmation email with tracking details</li>
                  <li>Track your package as it makes its way to you</li>
                  <li>Your order will arrive within ${ESTIMATED_DELIVERY || '3-5 business days'}</li>
                </ol>
              </div>
              
              <div style="margin-top: 30px; padding: 20px; background-color: #f0f9ff; border-radius: 6px; text-align: center;">
                <p style="margin: 0 0 10px; color: #1e40af; font-size: 14px; font-weight: 600;">
                  Questions about your order?
                </p>
                <p style="margin: 0; color: #3b82f6; font-size: 13px;">
                  Visit your <a href="account.html" style="color: #2563eb; text-decoration: underline;">account page</a> to view order details or contact support.
                </p>
              </div>
            </td>
          </tr>
          
          <tr>
            <td style="padding: 30px 40px; background-color: #f9fafb; border-radius: 0 0 8px 8px; text-align: center;">
              <p style="margin: 0 0 10px; color: #6b7280; font-size: 14px;">
                Need help? Contact us at <a href="mailto:support@happywrap.com" style="color: #2563eb; text-decoration: none;">support@happywrap.com</a>
              </p>
              <p style="margin: 0; color: #9ca3af; font-size: 12px;">
                © 2025 HappyWrap. All rights reserved.
              </p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
`;
