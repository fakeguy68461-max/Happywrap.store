# Email Service Setup Guide

To enable email sending for order confirmations and user verifications, you need to configure an email service provider.

## Option 1: SendGrid (Recommended)

1. Sign up for a SendGrid account at https://sendgrid.com
2. Create an API key from the SendGrid dashboard
3. Add the following environment variables in Netlify:
   - `SENDGRID_API_KEY`: Your SendGrid API key
   - `FROM_EMAIL`: The email address to send from (must be verified in SendGrid)

### Setting Environment Variables in Netlify:

1. Go to your Netlify site dashboard
2. Navigate to Site settings > Environment variables
3. Add the variables listed above

## Option 2: AWS SES

1. Set up AWS SES and verify your domain
2. Add the following environment variables:
   - `AWS_SES_REGION`: Your AWS region (e.g., us-east-1)
   - `AWS_ACCESS_KEY_ID`: Your AWS access key
   - `AWS_SECRET_ACCESS_KEY`: Your AWS secret key
   - `FROM_EMAIL`: The verified sender email address

## Testing

Without configuring an email service, the system will still work but emails won't actually be sent. The confirmation links will be logged to the console for testing purposes.

## Email Types Supported

- Order confirmation emails
- Email change verification
- Password reset emails (via Netlify Identity)
- Login confirmation emails (via Netlify Identity)
- User signup verification (via Netlify Identity)
