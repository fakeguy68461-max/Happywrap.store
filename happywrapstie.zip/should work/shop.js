// Shop Page JavaScript (Premium Version)

let allProducts = [];

// Load products from JSON
async function loadProducts() {
    try {
        const response = await fetch('products.json');
        const data = await response.json();
        allProducts = data.products;
        // No displayProducts call needed for premium static layout
        // But we need allProducts for addToCart logic
    } catch (error) {
        console.error('Error loading products:', error);
    }
}

// Add to cart from shop page
window.addToCartFromShop = function(productId) {
    // Ensure cart exists (from main.js)
    if (typeof cart === 'undefined') {
        console.error('Cart system not loaded');
        return;
    }

    const product = allProducts.find(p => p.id === productId);
    if (product) {
        cart.addItem(product);
        
        // Visual feedback
        const btn = event.target;
        // Check if button is the target (might be icon inside, though here it's text)
        if (btn.tagName === 'BUTTON') {
            const originalText = btn.textContent;
            
            // Lock width to prevent layout shift
            const width = btn.getBoundingClientRect().width;
            btn.style.width = `${width}px`;
            
            btn.textContent = '✓ Added!';
            btn.style.backgroundColor = '#10b981'; // Green
            btn.style.borderColor = '#10b981';
            btn.style.color = '#fff';
            
            setTimeout(() => {
                btn.textContent = originalText;
                btn.style.backgroundColor = '';
                btn.style.borderColor = '';
                btn.style.color = '';
                btn.style.width = '';
            }, 1500);
        }
    } else {
        console.error('Product not found:', productId);
        // Fallback for immediate feedback if product ID in HTML doesn't match JSON yet
        alert('Product ID not found in catalog: ' + productId);
    }
};

// Initialize shop page
document.addEventListener('DOMContentLoaded', () => {
    loadProducts();
});


// --- Lamp Light Special Logic ---
const lampColors = [
    { name: 'Red', hex: '#FF4D4D' },
    { name: 'Pink', hex: '#FFC0CB' },
    { name: 'Green', hex: '#4CAF50' },
    { name: 'Blue', hex: '#2196F3' },
    { name: 'Purple', hex: '#9C27B0' },
    { name: 'Yellow', hex: '#FFEB3B' }
];

let currentLampPack = 0;
let currentLampSelections = [];
let currentProductType = 'lamp'; // 'lamp' or 'heart'

window.openLampSelection = function(packSize, type = 'lamp') {
    currentLampPack = packSize;
    currentLampSelections = [];
    currentProductType = type;
    
    const modal = document.getElementById('lamp-modal');
    modal.style.display = 'flex';
    // Trigger reflow for transition
    modal.offsetHeight;
    modal.style.opacity = '1';
    modal.querySelector('.modal-content').style.transform = 'scale(1)';
    
    renderLampStep();
}

window.closeLampModal = function() {
    const modal = document.getElementById('lamp-modal');
    modal.style.opacity = '0';
    modal.querySelector('.modal-content').style.transform = 'scale(0.9)';
    
    setTimeout(() => {
        modal.style.display = 'none';
    }, 300);
}

function renderLampStep() {
    const title = document.getElementById('lamp-modal-title');
    const container = document.getElementById('lamp-color-container');
    
    // Determine which light we are selecting for
    const currentStep = currentLampSelections.length + 1;
    
    const productName = currentProductType === 'heart' ? 'Heart Light' : 'Light';
    
    if (currentLampPack === 1) {
        title.textContent = `Select ${productName} Color`;
    } else {
        title.textContent = `Select Color for ${productName} ${currentStep}`;
    }
    
    container.innerHTML = lampColors.map(color => `
        <div onclick="selectLampColor('${color.name}')" 
             style="cursor: pointer; display: flex; flex-direction: column; align-items: center; gap: 8px; transition: transform 0.2s;"
             onmouseover="this.style.transform='scale(1.1)'"
             onmouseout="this.style.transform='scale(1)'">
            <div style="width: 50px; height: 50px; border-radius: 50%; background-color: ${color.hex}; border: 3px solid #f0f0f0; box-shadow: 0 2px 5px rgba(0,0,0,0.1);"></div>
            <span style="font-size: 0.9rem; color: #555; font-weight: 500;">${color.name}</span>
        </div>
    `).join('');
}

window.selectLampColor = function(colorName) {
    currentLampSelections.push(colorName);
    
    if (currentLampSelections.length < currentLampPack) {
        // Next step
        const container = document.getElementById('lamp-color-container');
        // Simple fade out/in effect
        container.style.opacity = '0';
        setTimeout(() => {
            renderLampStep();
            container.style.opacity = '1';
        }, 200);
    } else {
        // Done
        finishLampOrder();
    }
}

function finishLampOrder() {
    closeLampModal();
    
    let product;
    
    if (currentProductType === 'heart') {
        if (currentLampPack === 1) {
            product = {
                id: 'prem-heart-001',
                name: 'Heart Shaped Light',
                price: 600,
                image: 'images/heart_shape.jpg',
                category: 'home-kitchen'
            };
        } else {
            product = {
                id: 'prem-heart-001-set3',
                name: 'Heart Shaped Lights (Set of 3)',
                price: 1500,
                image: 'images/heart_shape.jpg',
                category: 'home-kitchen'
            };
        }
    } else {
        // Default to Lamp
        if (currentLampPack === 1) {
            product = {
                id: 'prem-001',
                name: 'Designer Lamp Light',
                price: 600,
                image: 'images/card_lamplights.jpg',
                category: 'home-kitchen'
            };
        } else {
            product = {
                id: 'prem-001-set3',
                name: 'Designer Lamp Lights (Set of 3)',
                price: 1500,
                image: 'images/card_lamplights.jpg',
                category: 'home-kitchen'
            };
        }
    }
    
    if (typeof cart !== 'undefined') {
        // Store the color information in order details
        const options = {
            colors: currentLampSelections,
            description: `Colors: ${currentLampSelections.join(', ')}`
        };
        
        cart.addItem(product, 1, options);
        
        showToast(`Added to cart! Colors: ${currentLampSelections.join(', ')}`);
    } else {
        console.error('Cart system not ready');
    }
}

function showToast(message) {
    const toast = document.createElement('div');
    toast.textContent = message;
    toast.style.cssText = `
        position: fixed; bottom: 30px; left: 50%; transform: translateX(-50%);
        background: #333; color: white; padding: 12px 24px; border-radius: 50px;
        z-index: 3000; box-shadow: 0 4px 15px rgba(0,0,0,0.3); font-weight: 500;
        animation: fadeIn 0.3s ease-out;
    `;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 0.5s ease';
        setTimeout(() => toast.remove(), 500);
    }, 3000);
}


// --- Custom Mug Logic ---
const mugImages = [
    'images/mug_printing_1.jpg',
    'images/mug_printing_2.jpg'
];
let currentMugIndex = 0;

window.changeMugImage = function(direction) {
    currentMugIndex += direction;
    
    // Wrap around
    if (currentMugIndex >= mugImages.length) {
        currentMugIndex = 0;
    } else if (currentMugIndex < 0) {
        currentMugIndex = mugImages.length - 1;
    }
    
    const imgElement = document.getElementById('mug-display-img');
    if (imgElement) {
        // Simple fade effect
        imgElement.style.opacity = '0.5';
        setTimeout(() => {
            imgElement.src = mugImages[currentMugIndex];
            imgElement.style.opacity = '1';
        }, 150);
    }
}

window.openMugSelection = function() {
    const modal = document.getElementById('mug-modal');
    modal.style.display = 'flex';
    // Trigger reflow
    modal.offsetHeight;
    modal.style.opacity = '1';
    modal.querySelector('.modal-content').style.transform = 'scale(1)';
    
    // Clear input
    document.getElementById('mug-text').value = '';
    document.getElementById('mug-text').focus();
}

window.closeMugModal = function() {
    const modal = document.getElementById('mug-modal');
    modal.style.opacity = '0';
    modal.querySelector('.modal-content').style.transform = 'scale(0.9)';
    
    setTimeout(() => {
        modal.style.display = 'none';
    }, 300);
}

window.finishMugOrder = function() {
    const nameInput = document.getElementById('mug-text');
    const name = nameInput.value.trim();
    
    if (!name) {
        alert('Please enter a name or text to print on the mug.');
        nameInput.focus();
        return;
    }
    
    const product = {
        id: 'prem-mug-001',
        name: 'Custom Printed Mug',
        price: 600,
        image: 'images/mug_printing_1.jpg',
        category: 'home-kitchen'
    };
    
    if (typeof cart !== 'undefined') {
        const options = {
            customName: name,
            description: `Name on Mug: ${name}`
        };
        
        cart.addItem(product, 1, options);
        
        closeMugModal();
        showToast(`Added to cart! Name: ${name}`);
    } else {
        console.error('Cart system not ready');
        alert('Error: Cart system not ready. Please refresh the page.');
    }
}
