// Authentication JavaScript

// ==========================================
// GLOBAL AUTH STATE MANAGEMENT
// ==========================================
// Auth status: "loading" | "authenticated" | "unauthenticated"
// This prevents race conditions between OAuth redirect, auth state hydration, and route protection
window.authStatus = "loading";
window.authInitialized = false;
window.authInitPromise = null;

// Set auth status and dispatch event for listeners
function setAuthStatus(status) {
    console.log('[Auth] Status changed:', window.authStatus, '->', status);
    window.authStatus = status;
    window.dispatchEvent(new CustomEvent('authStatusChanged', { detail: { status } }));
}

// Wait for auth to be resolved (not loading)
function waitForAuthResolution() {
    return new Promise((resolve) => {
        if (window.authStatus !== "loading") {
            resolve(window.authStatus);
            return;
        }

        const handler = (e) => {
            if (e.detail.status !== "loading") {
                window.removeEventListener('authStatusChanged', handler);
                resolve(e.detail.status);
            }
        };
        window.removeEventListener('authStatusChanged', handler);
        window.addEventListener('authStatusChanged', handler);

        // Safety timeout - if auth doesn't resolve in 5 seconds, check current state
        setTimeout(() => {
            window.removeEventListener('authStatusChanged', handler);
            const currentAuth = checkCurrentAuthState();
            resolve(currentAuth ? "authenticated" : "unauthenticated");
        }, 5000);
    });
}

// Check current auth state synchronously
function checkCurrentAuthState() {
    const customUserData = localStorage.getItem('custom_user_data');
    const netlifyUser = (typeof netlifyIdentity !== 'undefined') ? netlifyIdentity.currentUser() : null;
    return customUserData || netlifyUser;
}

// Initialize auth state from storage and Netlify Identity
async function initializeAuthState() {
    if (window.authInitialized) {
        return window.authStatus;
    }

    console.log('[Auth] Initializing auth state...');
    setAuthStatus("loading");

    // Check localStorage first (instant)
    const customUserData = localStorage.getItem('custom_user_data');
    if (customUserData) {
        console.log('[Auth] Found custom user data in localStorage');
        window.authInitialized = true;
        setAuthStatus("authenticated");
        return "authenticated";
    }

    // Wait for Netlify Identity to initialize
    if (typeof netlifyIdentity !== 'undefined') {
        // Check if already initialized
        const netlifyUser = netlifyIdentity.currentUser();
        if (netlifyUser) {
            console.log('[Auth] Found existing Netlify Identity user');
            // Sync to localStorage to prevent future race conditions
            syncNetlifyUserToLocalStorage(netlifyUser);
            window.authInitialized = true;
            setAuthStatus("authenticated");
            return "authenticated";
        }

        // Wait a bit for Netlify Identity to fully initialize
        await new Promise(resolve => setTimeout(resolve, 100));

        const netlifyUserAfterWait = netlifyIdentity.currentUser();
        if (netlifyUserAfterWait) {
            console.log('[Auth] Found Netlify Identity user after wait');
            syncNetlifyUserToLocalStorage(netlifyUserAfterWait);
            window.authInitialized = true;
            setAuthStatus("authenticated");
            return "authenticated";
        }
    }

    // Try to get user from session cookie (backend session)
    const customUser = await checkCustomOAuthSession();
    if (customUser) {
        window.authInitialized = true;
        setAuthStatus("authenticated");
        return "authenticated";
    }

    console.log('[Auth] No authenticated user found');
    window.authInitialized = true;
    setAuthStatus("unauthenticated");
    return "unauthenticated";
}

// Sync Netlify Identity user to localStorage
function syncNetlifyUserToLocalStorage(user) {
    const isGoogleAuth = user.app_metadata?.provider === 'google';
    const userName = user.user_metadata?.full_name || user.email.split('@')[0];

    const userDataForStorage = {
        id: user.id,
        userId: user.id,
        email: user.email,
        firstName: userName.split(' ')[0] || userName,
        lastName: userName.split(' ').slice(1).join(' ') || '',
        provider: user.app_metadata?.provider || 'netlify-identity',
        isGoogleAuth: isGoogleAuth,
        isNetlifyIdentity: true
    };
    localStorage.setItem('custom_user_data', JSON.stringify(userDataForStorage));
    localStorage.setItem('user_name', userName);
    console.log('[Auth] Synced Netlify user to localStorage');
}

// Initialize Netlify Identity on page load
document.addEventListener('DOMContentLoaded', () => {
    if (typeof netlifyIdentity !== 'undefined') {
        netlifyIdentity.init();

        netlifyIdentity.on('error', err => {
            console.error('Netlify Identity error:', err);
        });

        // Handle init event - fires when Netlify Identity is ready
        netlifyIdentity.on('init', user => {
            console.log('[Auth] Netlify Identity initialized, user:', user ? user.email : 'none');
            if (user && window.authStatus === "loading") {
                syncNetlifyUserToLocalStorage(user);
                window.authInitialized = true;
                setAuthStatus("authenticated");
            } else if (!user && !localStorage.getItem('custom_user_data') && window.authStatus === "loading") {
                window.authInitialized = true;
                setAuthStatus("unauthenticated");
            }
        });

        netlifyIdentity.on('login', async user => {
            console.log('[Auth] User logged in via Netlify Identity:', user.email);

            // CRITICAL: Set auth status to loading during login process
            setAuthStatus("loading");

            const isGoogleAuth = user.app_metadata?.provider === 'google';
            const userName = user.user_metadata?.full_name || user.email.split('@')[0];

            // Store user data FIRST before any async operations
            const userDataForStorage = {
                id: user.id,
                userId: user.id,
                email: user.email,
                firstName: userName.split(' ')[0] || userName,
                lastName: userName.split(' ').slice(1).join(' ') || '',
                provider: user.app_metadata?.provider || 'netlify-identity',
                isGoogleAuth: isGoogleAuth,
                isNetlifyIdentity: true
            };
            localStorage.setItem('custom_user_data', JSON.stringify(userDataForStorage));
            localStorage.setItem('user_name', userName);

            // Mark as authenticated IMMEDIATELY after storing data
            window.authInitialized = true;
            setAuthStatus("authenticated");

            console.log('[Auth] User data stored, auth status set to authenticated');

            // Non-blocking: Store user email on server
            fetch('/api/store-user-email', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    email: user.email,
                    name: user.user_metadata?.full_name || '',
                    fullName: userName,
                    userId: user.id,
                    provider: user.app_metadata?.provider || 'netlify-identity',
                    timestamp: new Date().toISOString()
                })
            }).catch(err => console.error('Error storing user email:', err));

            // Non-blocking: Check password status for Google users
            if (isGoogleAuth) {
                fetch('/api/check-password-status', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ userId: user.id })
                })
                .then(res => res.json())
                .then(passwordData => {
                    if (!passwordData.hasPassword) {
                        localStorage.setItem('google_needs_password', 'true');
                    }
                })
                .catch(err => console.error('Error checking password status:', err));
            }

            netlifyIdentity.close();

            console.log('[Auth] Redirecting to account page');
            window.location.href = '/account.html';
        });

        netlifyIdentity.on('signup', async user => {
            console.log('[Auth] User signed up via Netlify Identity:', user.email);

            // CRITICAL: Set auth status to loading during signup process
            setAuthStatus("loading");

            const isGoogleAuth = user.app_metadata?.provider === 'google';
            const userName = user.user_metadata?.full_name || user.email.split('@')[0];

            // Store user data FIRST
            const userDataForStorage = {
                id: user.id,
                userId: user.id,
                email: user.email,
                firstName: userName.split(' ')[0] || userName,
                lastName: userName.split(' ').slice(1).join(' ') || '',
                provider: user.app_metadata?.provider || 'netlify-identity',
                isGoogleAuth: isGoogleAuth,
                isNetlifyIdentity: true
            };
            localStorage.setItem('custom_user_data', JSON.stringify(userDataForStorage));
            localStorage.setItem('user_name', userName);

            // Mark as authenticated IMMEDIATELY
            window.authInitialized = true;
            setAuthStatus("authenticated");

            if (isGoogleAuth) {
                localStorage.setItem('google_needs_password', 'true');
            }

            netlifyIdentity.close();

            console.log('[Auth] Redirecting to account page');
            window.location.href = '/account.html';
        });

        netlifyIdentity.on('logout', () => {
            console.log('[Auth] User logged out via Netlify Identity');
            // SAFE LOGOUT: Only remove auth-specific data, not everything
            localStorage.removeItem('custom_user_data');
            localStorage.removeItem('user_name');
            localStorage.removeItem('google_needs_password');
            // Note: We preserve user_profile_color as a user preference

            window.authInitialized = true;
            setAuthStatus("unauthenticated");
        });
    } else {
        console.warn('Netlify Identity widget not loaded');
        // Still initialize auth state from localStorage
        initializeAuthState();
    }

    // Start auth initialization
    window.authInitPromise = initializeAuthState();

    if (window.location.pathname.includes('login.html')) {
        setupLoginPage();
    }

    if (window.location.pathname.includes('account.html')) {
        setupAccountPage();
    }
});

// Setup login page - MUST wait for auth resolution before redirecting
async function setupLoginPage() {
    console.log('[Auth] Setting up login page, waiting for auth resolution...');

    // Wait for auth state to be determined (not loading)
    const authStatus = await waitForAuthResolution();

    console.log('[Auth] Login page auth status resolved:', authStatus);

    // Only redirect if actually authenticated
    if (authStatus === "authenticated") {
        console.log('[Auth] User is authenticated, redirecting to account');
        window.location.href = '/account.html';
        return;
    }

    console.log('[Auth] User is not authenticated, staying on login page');
}

// Setup account page - MUST wait for auth resolution before checking
async function setupAccountPage() {
    console.log('[Auth] Setting up account page, waiting for auth resolution...');

    // Security: Clear stale data from previous user
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('newSession') === 'true') {
        const authKeys = [
            'custom_user_data',
            'user_name',
            'google_needs_password'
        ];

        authKeys.forEach(key => localStorage.removeItem(key));
        sessionStorage.removeItem('authStatus');

        window.history.replaceState({}, '', '/account.html');
        console.log('[Auth] Cleared previous session data');
    }

    // Show loading state while auth is resolving
    const accountSection = document.querySelector('.account-section');
    const accountHeader = document.querySelector('.account-header');
    
    // Add a visible loader if not present
    let loader = document.getElementById('auth-loader');
    if (!loader) {
        loader = document.createElement('div');
        loader.id = 'auth-loader';
        loader.innerHTML = '<div style="display: flex; justify-content: center; padding: 50px;"><div style="width: 40px; height: 40px; border: 4px solid #f3f3f3; border-top: 4px solid var(--primary-color); border-radius: 50%; animation: spin 1s linear infinite;"></div></div>';
        loader.innerHTML += '<style>@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }</style>';
        const main = document.querySelector('main') || document.body;
        if (accountHeader) {
            accountHeader.before(loader);
        } else {
            main.prepend(loader);
        }
    }

    // Wait for auth state to be determined (not loading)
    const authStatus = await waitForAuthResolution();

    console.log('[Auth] Account page auth status resolved:', authStatus);

    // Only redirect if definitely not authenticated
    if (authStatus === "unauthenticated") {
        console.log('[Auth] No user authenticated, redirecting to login');
        window.location.href = '/login.html';
        return;
    }

    // Get user data - STRICTLY from verified source if possible
    const customUserData = localStorage.getItem('custom_user_data');
    const netlifyUser = (typeof netlifyIdentity !== 'undefined') ? netlifyIdentity.currentUser() : null;

    // Gate: Ensure we don't proceed with stale data if Netlify Identity is initializing
    if (typeof netlifyIdentity !== 'undefined' && !netlifyUser && !customUserData) {
         // Double check if identity is still processing
         await new Promise(resolve => setTimeout(resolve, 500));
    }

    // Sync Netlify user to localStorage if needed
    if (netlifyUser && !customUserData) {
        console.log('[Auth] Netlify user found but no custom data, syncing...');
        syncNetlifyUserToLocalStorage(netlifyUser);
    }

    // Re-fetch customUserData after potential sync
    const refreshedCustomUserData = localStorage.getItem('custom_user_data');

    // Security: Check Google password requirement BEFORE showing page
    try {
        const userData = JSON.parse(refreshedCustomUserData);

        if (userData.isGoogleAuth && localStorage.getItem('google_needs_password') === 'true') {
            console.log('[Auth] Google user needs password, redirecting...');
            window.location.href = 'set-password.html';
            return;
        }
    } catch (err) {
        console.error('Error checking Google auth status:', err);
    }

    // Remove loader and restore visibility AFTER password check passes
    if (loader) loader.remove();

    if (accountSection) accountSection.style.visibility = 'visible';
    if (accountHeader) accountHeader.style.visibility = 'visible';
    
    // Check if we need to resolve user from custom data
    let user = netlifyUser;

    if (!user && refreshedCustomUserData) {
        try {
            const parsedData = JSON.parse(refreshedCustomUserData);
            let fullName = parsedData.fullName;
            
            if (parsedData.firstName && parsedData.lastName) {
                fullName = `${parsedData.firstName} ${parsedData.lastName}`;
            } else if (!fullName && parsedData.email) {
                fullName = parsedData.email.split('@')[0];
            }

            user = {
                id: parsedData.userId || parsedData.id,
                email: parsedData.email,
                user_metadata: {
                    full_name: fullName
                },
                app_metadata: {
                    provider: parsedData.provider || 'local',
                    roles: parsedData.roles || []
                },
                isAdmin: parsedData.isAdmin || false, // Include admin status from localStorage
                token: {
                    access_token: null // No token for custom auth, or handle differently
                }
            };
        } catch (e) {
            console.error('Error parsing custom user data:', e);
        }
    }
    
    if (!user) {
        return;
    }

    // CRITICAL: Refresh admin status from backend to get latest promotions
    // This ensures users promoted to admin see the admin panel immediately
    try {
        const refreshResponse = await fetch('/api/get-current-user', {
            credentials: 'include',
            cache: 'no-store'
        });
        if (refreshResponse.ok) {
            const refreshData = await refreshResponse.json();
            if (refreshData.authenticated && refreshData.user) {
                // Update user object with fresh admin status from backend
                user.isAdmin = refreshData.user.isAdmin || false;
                if (user.app_metadata) {
                    user.app_metadata.roles = refreshData.user.roles || [];
                }
                // Also update localStorage to keep it in sync
                const storedData = localStorage.getItem('custom_user_data');
                if (storedData) {
                    const parsed = JSON.parse(storedData);
                    parsed.isAdmin = refreshData.user.isAdmin || false;
                    parsed.roles = refreshData.user.roles || [];
                    localStorage.setItem('custom_user_data', JSON.stringify(parsed));
                }
            }
        }
    } catch (refreshErr) {
        console.warn('[Auth] Could not refresh admin status:', refreshErr);
        // Continue with existing data if refresh fails
    }

    const pendingNotification = localStorage.getItem('pendingVerificationNotification');
    if (pendingNotification) {
        try {
            const notification = JSON.parse(pendingNotification);
            setTimeout(() => {
                showPersistentNotification(notification.title, notification.message, notification.type);
            }, 500);
            localStorage.removeItem('pendingVerificationNotification');
        } catch (err) {
            console.error('Error showing pending notification:', err);
        }
    }
    
    checkAdminRole(user);
    
    loadUserProfile(user);
    loadWishlist();
    
    // Sync orders from server - STRICTLY using the resolved user
    fetchAndSyncOrders(user).then(() => {
        loadOrderHistory();
    });
    
    setupAccountTabs();
    setupLoyaltyTab(user); // Initialize Loyalty Tab
    setupProfileEditor();
    setupEmailChangeForm();
    setupPasswordForm();
    
    // Check for hash in URL to switch tabs
    const hash = window.location.hash;
    if (hash) {
        const tabName = hash.substring(1); // remove #
        const tabBtn = document.querySelector(`.tab-btn[data-tab="${tabName}"]`);
        if (tabBtn) {
            setTimeout(() => tabBtn.click(), 100);
        }
    }
    
    const isGoogleAuth = user.app_metadata?.provider === 'google';
    const passwordSection = document.getElementById('passwordSettingsSection');
    
    // Hide password section by default for everyone
    if (passwordSection) {
        passwordSection.style.display = 'none';
    }
    
    if (isGoogleAuth) {
        // Double check just in case, though the redirect above should have caught it
        checkIfPasswordSet(user.id).then(passwordData => {
            if (!passwordData || !passwordData.hasPassword) {
                 localStorage.setItem('google_needs_password', 'true');
                 window.location.href = 'set-password.html';
            } else {
                localStorage.removeItem('google_needs_password');
                // If they have a password, we can optionally show the change password form or hide it.
                // Current logic was showing it only if they didn't have one.
                // Let's leave it hidden or show "Change Password" instead of "Set Password".
                // For now, simple fix: just ensure we don't nag them if they have it.
            }
        });
    }
}

// Global Logout Handler
document.addEventListener('DOMContentLoaded', () => {
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            if (confirm('Are you sure you want to logout?')) {
                console.log('[Auth] Logging out user...');

                // SAFE LOGOUT: Only remove auth-specific data
                // Do NOT use localStorage.clear() which would wipe everything
                localStorage.removeItem('custom_user_data');
                localStorage.removeItem('user_name');
                localStorage.removeItem('google_needs_password');
                // Note: We preserve user_profile_color as it's a UI preference

                // Update auth state BEFORE redirect
                window.authInitialized = true;
                setAuthStatus("unauthenticated");

                // Handle Netlify Identity logout (non-blocking)
                try {
                    if (typeof netlifyIdentity !== 'undefined' && netlifyIdentity.currentUser()) {
                        await netlifyIdentity.logout();
                    }

                    // Clear custom OAuth session
                    await fetch('/api/logout', {
                        method: 'POST',
                        credentials: 'include'
                    });
                } catch (err) {
                    console.error('[Auth] Error during logout:', err);
                }

                console.log('[Auth] Logout complete, redirecting to login');
                // Force redirect
                window.location.href = '/login.html';
            }
        });
    }
});

// Fetch and sync orders from server
async function fetchAndSyncOrders(user) {
    try {
        const customUserStr = localStorage.getItem('custom_user_data');
        let requestBody = {};
        
        // Determine auth method
        if (user.token?.access_token) {
            // Netlify Identity
            requestBody = { token: user.token.access_token };
        } else if (customUserStr) {
            // Custom Auth
            const userData = JSON.parse(customUserStr);
            requestBody = {
                email: userData.email,
                userId: userData.userId
            };
        } else {
            console.warn('No valid auth found for syncing orders');
            return;
        }

        const response = await fetch('/api/get-user-orders', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(requestBody)
        });

        if (!response.ok) {
            console.error('Failed to fetch orders from server');
            return;
        }

        const result = await response.json();
        
        if (result.success && result.orders && result.orders.length > 0) {
            // Map server orders to client structure
            const mappedOrders = result.orders.map(o => ({
                id: o.orderId,
                date: o.confirmedAt || o.createdAt,
                items: o.orderData.items,
                total: o.orderData.total,
                shippingInfo: o.orderData.shippingInfo,
                boxes: o.orderData.boxes || [], // Include box configurations
                status: o.status || 'Confirmed'
            }));
            
            // Update order history
            if (window.orderHistory) {
                window.orderHistory.orders = mappedOrders;
                window.orderHistory.saveOrders();
                console.log('Orders synced from server:', mappedOrders.length);
            }
        }
    } catch (error) {
        console.error('Error syncing orders:', error);
    }
}

// Load user profile
function loadUserProfile(user) {
    let userName = user.user_metadata?.full_name || 
                     localStorage.getItem('user_name') || 
                     (user.email ? user.email.split('@')[0] : 'User');
    
    if (!userName || userName === 'undefined' || userName === 'null') {
        userName = user.email ? user.email.split('@')[0] : 'User';
    }

    // Force pink adjacent color as per requirement
    const userColor = '#FF8FA3';
    
    const userNameEl = document.getElementById('userName');
    if (userNameEl) userNameEl.textContent = userName;
    
    const userEmailEl = document.getElementById('userEmail');
    if (userEmailEl) userEmailEl.textContent = user.email || '';
    
    // Set profile picture
    const profilePic = document.getElementById('userProfilePic');
    if (profilePic) profilePic.style.backgroundColor = userColor;
    
    const initials = userName.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
    const userInitials = document.getElementById('userInitials');
    if (userInitials) userInitials.textContent = initials;
}

// Setup account tabs
function setupAccountTabs() {
    const tabBtns = document.querySelectorAll('.tab-btn:not(.logout-btn)');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const tabName = btn.dataset.tab;
            
            // Remove active class from all
            tabBtns.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            
            // Add active class to clicked
            btn.classList.add('active');
            document.getElementById(`${tabName}Tab`).classList.add('active');
        });
    });
}

// Load wishlist
function loadWishlist() {
    const items = wishlist.getItems();
    const wishlistItems = document.getElementById('wishlistItems');
    const emptyWishlist = document.getElementById('emptyWishlist');
    
    if (items.length === 0) {
        wishlistItems.style.display = 'none';
        emptyWishlist.style.display = 'block';
        return;
    }
    
    wishlistItems.style.display = 'grid';
    emptyWishlist.style.display = 'none';
    
    wishlistItems.innerHTML = items.map(product => `
        <div class="product-card">
            <button class="wishlist-btn active" onclick="removeFromWishlist('${product.id}')">❤️</button>
            <img src="${product.image}" alt="${product.name}" class="product-image"
                 onerror="this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'250\' height=\'250\'%3E%3Crect width=\'250\' height=\'250\' fill=\'%23f3f4f6\'/%3E%3Ctext x=\'50%25\' y=\'50%25\' dominant-baseline=\'middle\' text-anchor=\'middle\' font-family=\'sans-serif\' font-size=\'18\' fill=\'%236b7280\'%3ENo Image%3C/text%3E%3C/svg%3E'">
            <div class="product-info">
                <p class="product-category">${getCategoryName(product.category)}</p>
                <h3 class="product-name">${product.name}</h3>
                <p class="product-price">${formatPrice(product.price)}</p>
                <div class="product-actions">
                    <button class="btn btn-primary" onclick="addToCartFromWishlist('${product.id}')">Add to Box</button>
                    <button class="btn btn-outline" onclick="viewProduct('${product.id}')">View</button>
                </div>
            </div>
        </div>
    `).join('');
}

// Remove from wishlist
window.removeFromWishlist = function(productId) {
    wishlist.removeItem(productId);
    loadWishlist();
    showNotification(
        'Removed',
        'Item removed from wishlist',
        'info'
    );
};

// Add to cart from wishlist
window.addToCartFromWishlist = function(productId) {
    const product = wishlist.getItems().find(p => p.id === productId);
    if (product) {
        cart.addItem(product);
        showNotification(
            'Added to Box',
            `${product.name} added to your box`,
            'success'
        );
    }
};

// View product
window.viewProduct = function(productId) {
    window.location.href = `product.html?id=${productId}`;
};

// Get category name
function getCategoryName(category) {
    const names = {
        'electronics': 'Electronics',
        'toys': 'Toys',
        'home-kitchen': 'Home & Kitchen',
        'sports-outdoors': 'Sports & Outdoors',
        'books-media': 'Books & Media'
    };
    return names[category] || category;
}

// Load order history
function loadOrderHistory() {
    const orders = orderHistory.getOrders();
    const orderHistoryDiv = document.getElementById('orderHistory');
    const emptyOrders = document.getElementById('emptyOrders');

    if (orders.length === 0) {
        orderHistoryDiv.style.display = 'none';
        emptyOrders.style.display = 'block';
        return;
    }

    orderHistoryDiv.style.display = 'block';
    emptyOrders.style.display = 'none';

    orderHistoryDiv.innerHTML = orders.map(order => `
        <div class="order-card" style="background: white; padding: 20px; border-radius: 12px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
            <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
                <div>
                    <h3 style="margin-bottom: 5px;">Order ${order.id}</h3>
                    <p style="color: var(--gray); font-size: 14px;">${new Date(order.date).toLocaleDateString()}</p>
                </div>
                <div style="text-align: right;">
                    <p style="font-size: 20px; font-weight: 700; color: var(--primary-color);">${formatPrice(order.total)}</p>
                    <span style="background: #10b981; color: white; padding: 4px 12px; border-radius: 20px; font-size: 12px;">${order.status}</span>
                </div>
            </div>
            <div style="border-top: 1px solid var(--border); padding-top: 15px; margin-bottom: 15px;">
                <p style="font-weight: 600; margin-bottom: 10px;">${order.items.length} item(s)</p>
                ${order.items.map(item => `
                    <p style="color: var(--gray); font-size: 14px;">- ${item.name} x ${item.quantity}</p>
                `).join('')}
                ${order.boxes && order.boxes.length > 0 ? `
                    <div style="margin-top: 10px; padding: 8px 12px; background: #fff0f5; border-radius: 6px; display: inline-block;">
                        <span style="color: #ec4899; font-size: 13px; font-weight: 500;">Gift Box: ${order.boxes.length} custom box${order.boxes.length > 1 ? 'es' : ''}</span>
                    </div>
                ` : ''}
            </div>
            <div style="display: flex; gap: 10px;">
                <button class="btn btn-outline" onclick="viewOrderDetails('${order.id}')">View Details</button>
                <button class="btn btn-primary" onclick="reorder('${order.id}')">Reorder</button>
            </div>
        </div>
    `).join('');
}

// View order details
window.viewOrderDetails = function(orderId) {
    const order = orderHistory.getOrderById(orderId);
    if (!order) {
        showNotification('Error', 'Order not found', 'error');
        return;
    }

    // Store the current order ID for the reorder button
    window.currentOrderId = orderId;

    // Generate box configuration HTML if boxes exist
    let boxesHtml = '';
    if (order.boxes && order.boxes.length > 0) {
        boxesHtml = `
            <div style="margin-bottom: 20px; background: #fff0f5; border: 1px solid #fbcfe8; border-radius: 8px; padding: 15px;">
                <h4 style="margin-bottom: 15px; color: #ec4899; display: flex; align-items: center; gap: 8px;">
                    <span style="font-size: 20px;">🎁</span> Gift Box Details
                </h4>
                ${order.boxes.map((box, idx) => `
                    <div style="margin-bottom: 15px; padding: 12px; background: white; border-radius: 8px; border: 1px solid #fbcfe8; ${idx < order.boxes.length - 1 ? 'margin-bottom: 15px;' : ''}">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                            <span style="font-weight: 600;">Box ${idx + 1}</span>
                            <span style="text-transform: capitalize; background: ${getBoxColorHex(box.boxColor)}; color: white; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 500;">${box.boxColor || 'Default'}</span>
                        </div>
                        <div style="font-size: 14px; color: #374151;">
                            <p style="margin-bottom: 5px;"><strong>Recipient:</strong> ${box.recipientName || 'Not specified'}</p>
                            ${box.message ? `<p style="margin-bottom: 5px;"><strong>Message/Quote:</strong> <em>"${box.message}"</em></p>` : ''}
                            ${box.items && box.items.length > 0 ? `
                                <div style="margin-top: 10px; padding-top: 10px; border-top: 1px dashed #fbcfe8;">
                                    <p style="font-weight: 600; margin-bottom: 5px;">Items in this box:</p>
                                    <ul style="margin: 0; padding-left: 20px; color: #6b7280;">
                                        ${box.items.map(item => `<li style="margin-bottom: 3px;">${item.name || item}</li>`).join('')}
                                    </ul>
                                </div>
                            ` : ''}
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    const content = document.getElementById('orderDetailContent');
    content.innerHTML = `
        <div style="margin-bottom: 20px;">
            <h3>Order ${order.id}</h3>
            <p style="color: var(--gray);">${new Date(order.date).toLocaleString()}</p>
        </div>
        ${boxesHtml}
        <div style="margin-bottom: 20px;">
            <h4>Items:</h4>
            ${order.items.map(item => `
                <div style="display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid var(--border);">
                    <div>
                        <span>${item.name} x ${item.quantity}</span>
                        ${item.options && item.options.colors ? `<div style="font-size: 0.9em; color: #666; margin-top: 4px;">Colors: ${item.options.colors.join(', ')}</div>` : ''}
                    </div>
                    <span>${formatPrice(item.price * item.quantity)}</span>
                </div>
            `).join('')}
        </div>
        <div style="margin-bottom: 20px;">
            <h4>Shipping Address:</h4>
            <p>${order.shippingInfo.name}</p>
            <p>${order.shippingInfo.address}</p>
            <p>${order.shippingInfo.city}, ${order.shippingInfo.country}</p>
            <p>${order.shippingInfo.postalCode}</p>
        </div>
        <div style="text-align: right; font-size: 20px; font-weight: 700; color: var(--primary-color);">
            Total: ${formatPrice(order.total)}
        </div>
    `;

    document.getElementById('orderDetailModal').style.display = 'flex';
};

// Helper function to get box color hex value
function getBoxColorHex(colorName) {
    const colorMap = {
        'Red': '#ef4444',
        'Green': '#10b981',
        'Black': '#1f2937',
        'Pink': '#ec4899',
        'Orange': '#f97316',
        'Purple': '#8b5cf6',
        'Gray': '#6b7280',
        'Navy': '#1e3a8a'
    };
    return colorMap[colorName] || '#6b7280';
}

// Close order modal and handle reorder button
document.addEventListener('DOMContentLoaded', () => {
    const closeBtn = document.getElementById('closeOrderModal');
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            document.getElementById('orderDetailModal').style.display = 'none';
        });
    }

    // Handle reorder button in modal
    const reorderBtn = document.getElementById('reorderBtn');
    if (reorderBtn) {
        reorderBtn.addEventListener('click', () => {
            // Use the stored order ID
            if (window.currentOrderId) {
                document.getElementById('orderDetailModal').style.display = 'none';
                window.reorder(window.currentOrderId);
            }
        });
    }

    // Close modal when clicking outside
    const orderModal = document.getElementById('orderDetailModal');
    if (orderModal) {
        orderModal.addEventListener('click', (e) => {
            if (e.target === orderModal) {
                orderModal.style.display = 'none';
            }
        });
    }
});

// Reorder
window.reorder = function(orderId) {
    const order = orderHistory.getOrderById(orderId);
    if (!order) return;
    
    order.items.forEach(item => {
        cart.addItem(item, item.quantity);
    });
    
    showNotification(
        'Items Added',
        'Order items have been added to your box',
        'success'
    );
    setTimeout(() => {
        window.location.href = 'box.html';
    }, 1500);
};

// Setup profile editor - handles both Netlify Identity and custom auth users
function setupProfileEditor() {
    let user = null;
    let userName = '';
    let userEmail = '';

    // Try Netlify Identity first
    if (typeof netlifyIdentity !== 'undefined') {
        user = netlifyIdentity.currentUser();
    }

    // Fallback to custom user data
    if (!user) {
        const customUserData = localStorage.getItem('custom_user_data');
        if (customUserData) {
            try {
                const parsedData = JSON.parse(customUserData);
                user = {
                    email: parsedData.email,
                    user_metadata: {
                        full_name: parsedData.fullName || `${parsedData.firstName || ''} ${parsedData.lastName || ''}`.trim()
                    }
                };
            } catch (e) {
                console.error('Error parsing custom user data:', e);
            }
        }
    }

    if (!user) {
        console.warn('[Auth] No user data found for profile editor');
        return;
    }

    userName = user.user_metadata?.full_name ||
               localStorage.getItem('user_name') ||
               (user.email ? user.email.split('@')[0] : 'User');
    userEmail = user.email || '';

    const nameInput = document.getElementById('profileName');
    const emailInput = document.getElementById('profileEmail');

    if (nameInput) nameInput.value = userName;
    if (emailInput) emailInput.value = userEmail;
    
    // Profile form submission
    const profileForm = document.getElementById('profileForm');
    if (profileForm) {
        profileForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const newName = document.getElementById('profileName').value;
            localStorage.setItem('user_name', newName);
            
            const userNameDisplay = document.getElementById('userName');
            if (userNameDisplay) userNameDisplay.textContent = newName;
            
            // Update initials
            const initials = newName.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
            const userInitials = document.getElementById('userInitials');
            if (userInitials) userInitials.textContent = initials;
            
            showNotification(
                'Profile Updated',
                'Your profile has been updated successfully',
                'success'
            );
        });
    }
}

function setupEmailChangeForm() {
    const changeEmailForm = document.getElementById('changeEmailForm');
    if (!changeEmailForm) return;

    changeEmailForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const user = netlifyIdentity.currentUser();
        // Fallback to custom auth user if Netlify Identity user is not present
        const customUserData = localStorage.getItem('custom_user_data');
        let userId = user ? user.id : null;
        let currentEmail = user ? user.email : null;
        
        if (!user && customUserData) {
            try {
                const parsed = JSON.parse(customUserData);
                userId = parsed.userId || parsed.id;
                currentEmail = parsed.email;
            } catch (err) {
                console.error('Error parsing custom user data:', err);
            }
        }

        if (!userId || !currentEmail) {
            showNotification('Error', 'You must be logged in to change your email', 'error');
            return;
        }

        const newEmail = document.getElementById('newEmail').value.trim();

        if (newEmail === currentEmail) {
            showNotification('Error', 'New email must be different from current email', 'error');
            return;
        }

        if (!validateEmail(newEmail)) {
            showNotification('Error', 'Please enter a valid email address', 'error');
            return;
        }

        const submitButton = changeEmailForm.querySelector('button[type="submit"]');
        const originalText = submitButton.textContent;
        submitButton.disabled = true;
        submitButton.textContent = 'Sending Code...';

        try {
            const response = await fetch('/api/generate-email-otp', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    type: 'email_change',
                    userId: userId,
                    email: newEmail, // Send code to NEW email
                    oldEmail: currentEmail
                })
            });

            const data = await response.json();

            if (response.ok) {
                // Redirect to verification page
                window.location.href = `verify-email-otp.html?type=email_change&email=${encodeURIComponent(newEmail)}`;
            } else {
                showNotification(
                    'Error',
                    data.error || 'Failed to send verification code',
                    'error'
                );
            }
        } catch (error) {
            console.error('Error requesting email change:', error);
            showNotification(
                'Error',
                'An error occurred. Please try again later.',
                'error'
            );
        } finally {
            submitButton.disabled = false;
            submitButton.textContent = originalText;
        }
    });
}

function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

async function checkIfPasswordSet(userId) {
    try {
        const response = await fetch('/api/check-password-status', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId })
        });
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error checking password status:', error);
        return null;
    }
}

function hidePasswordSection() {
    const setPasswordForm = document.getElementById('setPasswordForm');
    if (setPasswordForm) {
        const passwordSection = setPasswordForm.closest('div[style*="border-top"]');
        if (passwordSection) {
            passwordSection.style.display = 'none';
        }
    }
}

function setupPasswordForm() {
    const setPasswordForm = document.getElementById('setPasswordForm');
    if (!setPasswordForm) return;

    setPasswordForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const user = netlifyIdentity.currentUser();
        if (!user) {
            showNotification('Error', 'You must be logged in to set a password', 'error');
            return;
        }

        const newPassword = document.getElementById('newPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        if (newPassword !== confirmPassword) {
            showNotification('Error', 'Passwords do not match', 'error');
            return;
        }

        if (newPassword.length < 6) {
            showNotification('Error', 'Password must be at least 6 characters long', 'error');
            return;
        }

        const submitButton = setPasswordForm.querySelector('button[type="submit"]');
        const originalText = submitButton.textContent;
        submitButton.disabled = true;
        submitButton.textContent = 'Setting Password...';

        try {
            const response = await fetch('/api/set-password', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    userId: user.id,
                    email: user.email,
                    newPassword: newPassword
                })
            });

            const data = await response.json();

            if (response.ok) {
                showNotification(
                    'Password Set',
                    'Your password has been set successfully. You can now use it to log in.',
                    'success'
                );
                document.getElementById('newPassword').value = '';
                document.getElementById('confirmPassword').value = '';
                
                hidePasswordSection();
            } else {
                showNotification(
                    'Error',
                    data.error || 'Failed to set password',
                    'error'
                );
            }
        } catch (error) {
            console.error('Error setting password:', error);
            showNotification(
                'Error',
                'An error occurred. Please try again later.',
                'error'
            );
        } finally {
            submitButton.disabled = false;
            submitButton.textContent = originalText;
        }
    });
}

async function setupLoyaltyTab(user) {
    const loyaltyBadge = document.getElementById('loyaltyBadge');
    const loyaltySubtext = document.getElementById('loyaltySubtext');
    const vipProgressText = document.getElementById('vipProgressText');
    const vipProgressBar = document.getElementById('vipProgressBar');
    const totalOrdersCount = document.getElementById('totalOrdersCount');
    const nextRewardDesc = document.getElementById('nextRewardDesc');
    const nextRewardSub = document.getElementById('nextRewardSub');
    const milestonesList = document.getElementById('milestonesList');
    
    // VIP UI Elements
    const userProfilePic = document.getElementById('userProfilePic');
    const welcomeHeader = document.querySelector('.user-info h1');

    if (!loyaltyBadge) return; // Not on account page

    try {
        const response = await fetch(`/api/get-loyalty-profile?email=${encodeURIComponent(user.email)}`);
        const data = await response.json();

        if (data.success) {
            // 1. Basic Stats
            totalOrdersCount.textContent = data.total_completed_orders;
            loyaltyBadge.textContent = data.loyalty_tier;
            
            // 2. VIP Styling
            if (data.is_vip) {
                loyaltyBadge.classList.add('vip');
                loyaltyBadge.style.backgroundColor = '#8b5cf6'; // Purple
                loyaltyBadge.style.color = 'white';
                
                // Add purple ring to profile pic
                if (userProfilePic) {
                    userProfilePic.style.border = '4px solid #8b5cf6';
                    userProfilePic.classList.add('vip-ring');
                    
                    // Add badge icon overlay if not exists
                    if (!document.getElementById('vipProfileBadge')) {
                        const badge = document.createElement('div');
                        badge.id = 'vipProfileBadge';
                        badge.textContent = 'VIP';
                        badge.style.position = 'absolute';
                        badge.style.bottom = '-5px';
                        badge.style.right = '-5px';
                        badge.style.backgroundColor = '#8b5cf6';
                        badge.style.color = 'white';
                        badge.style.fontSize = '12px';
                        badge.style.padding = '2px 8px';
                        badge.style.borderRadius = '10px';
                        badge.style.border = '2px solid white';
                        userProfilePic.style.position = 'relative';
                        userProfilePic.appendChild(badge);
                    }
                }

                // Welcome Message
                if (welcomeHeader && !welcomeHeader.dataset.vip) {
                    const originalText = welcomeHeader.innerHTML; // "Welcome, <span...>User</span>!"
                    // We want to insert the VIP message above or change it
                     // Requirement: "Welcome back, VIP. Thank you for being one of our most valued customers."
                    const vipMsg = document.createElement('p');
                    vipMsg.textContent = "Welcome back, VIP. Thank you for being one of our most valued customers.";
                    vipMsg.style.color = '#8b5cf6';
                    vipMsg.style.fontWeight = '600';
                    vipMsg.style.marginTop = '5px';
                    welcomeHeader.parentElement.appendChild(vipMsg);
                    welcomeHeader.dataset.vip = 'true';
                }

                loyaltySubtext.textContent = "You have reached VIP Status! Enjoy 20% off forever.";
            }

            // 3. Progress
            vipProgressText.textContent = `${Math.round(data.vip_progress)}%`;
            vipProgressBar.style.width = `${data.vip_progress}%`;
            if (data.is_vip) {
                vipProgressBar.style.backgroundColor = '#8b5cf6';
            }

            // 4. Next Reward
            if (data.next_reward) {
                nextRewardDesc.textContent = data.next_reward.desc;
                nextRewardSub.textContent = `${data.next_reward.orders_needed} order(s) away`;
            } else if (data.is_vip) {
                nextRewardDesc.textContent = "VIP Status Unlocked";
                nextRewardSub.textContent = "Maximum Reward Reached";
            } else {
                nextRewardDesc.textContent = "Start Shopping";
                nextRewardSub.textContent = "Complete your first order!";
            }

            // 5. Milestones Render
            milestonesList.innerHTML = data.milestones.map(m => {
                const isUnlocked = m.status === 'unlocked';
                const isNext = data.next_reward && data.next_reward.milestone_num === m.orderNum;
                
                let icon = '🔒';
                let itemClass = 'milestone-item';
                
                if (isUnlocked) {
                    icon = '✅';
                    itemClass += ' unlocked';
                } else if (isNext) {
                    icon = '🎯';
                    itemClass += ' next';
                }

                return `
                    <div class="${itemClass}" style="display: flex; align-items: center; gap: 15px; padding: 15px; border: 1px solid var(--border); border-radius: 8px; margin-bottom: 10px; background: ${isUnlocked ? '#f0fdf4' : (isNext ? '#fffbeb' : 'white')};">
                        <div style="font-size: 24px;">${icon}</div>
                        <div>
                            <h4 style="margin-bottom: 4px; ${isUnlocked ? 'color: #15803d;' : ''}">Order ${m.orderNum}: ${m.desc}</h4>
                            <p style="font-size: 13px; color: var(--gray);">${isUnlocked ? 'Unlocked' : (isNext ? 'Up Next' : 'Locked')}</p>
                        </div>
                    </div>
                `;
            }).join('');

        }
    } catch (err) {
        console.error('Error loading loyalty data:', err);
        if (milestonesList) milestonesList.innerHTML = '<p>Failed to load loyalty data.</p>';
    }
}

// Check custom OAuth session with retries
async function checkCustomOAuthSession(retries = 3) {
    for (let i = 0; i < retries; i++) {
        try {
            const res = await fetch('/api/get-current-user', { 
                credentials: 'include',
                cache: 'no-store'
            });
            
            if (!res.ok) {
                if (i < retries - 1) {
                    console.log(`[Auth] Session check attempt ${i + 1} failed, retrying...`);
                    await new Promise(resolve => setTimeout(resolve, 300));
                    continue;
                }
                return null;
            }
            
            const response = await res.json();
            
            // Handle nested response structure
            if (!response.authenticated || !response.user) {
                if (i < retries - 1) {
                    console.log(`[Auth] No user data in response, retrying...`);
                    await new Promise(resolve => setTimeout(resolve, 300));
                    continue;
                }
                return null;
            }
            
            const userData = response.user;
            
            const normalized = {
                id: userData.userId,
                userId: userData.userId,
                email: userData.email,
                firstName: userData.firstName || '',
                lastName: userData.lastName || '',
                provider: userData.provider || 'google',
                isGoogleAuth: userData.isGoogleAuth || userData.provider === 'google',
                isNetlifyIdentity: false, // Custom auth
                isAdmin: userData.isAdmin || false, // Include admin status from backend
                roles: userData.roles || [] // Include roles from backend
            };

            localStorage.setItem('custom_user_data', JSON.stringify(normalized));
            localStorage.setItem('user_name', `${normalized.firstName} ${normalized.lastName}`.trim() || userData.email);
            
            // Handle password requirement for Google users
            if (normalized.isGoogleAuth && !userData.hasPassword) {
                 localStorage.setItem('google_needs_password', 'true');
            } else {
                 localStorage.removeItem('google_needs_password');
            }
            
            console.log('[Auth] Custom OAuth session synced on attempt', i + 1);
            return normalized;
            
        } catch (err) {
            if (i < retries - 1) {
                console.log(`[Auth] Session check attempt ${i + 1} error:`, err.message, '- retrying...');
                await new Promise(resolve => setTimeout(resolve, 300));
                continue;
            }
            console.error('[Auth] Session check failed after', retries, 'attempts:', err);
            return null;
        }
    }
    return null;
}

window.loadWishlist = loadWishlist;
window.loadOrderHistory = loadOrderHistory;
window.checkAdminRole = checkAdminRole;

// Export auth state functions globally
window.waitForAuthResolution = waitForAuthResolution;
window.initializeAuthState = initializeAuthState;
window.setAuthStatus = setAuthStatus;
window.checkCurrentAuthState = checkCurrentAuthState;
window.syncNetlifyUserToLocalStorage = syncNetlifyUserToLocalStorage;