import { getStore } from '@netlify/blobs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { email } = await req.json();

    if (!email) {
      return new Response(JSON.stringify({ error: 'Email is required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const verifiedStore = getStore('verified-emails');
    const verificationDataString = await verifiedStore.get(email);

    if (!verificationDataString) {
      return new Response(JSON.stringify({ 
        verified: false,
        message: 'Email not verified'
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const verificationData = JSON.parse(verificationDataString);

    return new Response(JSON.stringify({ 
      verified: true,
      verifiedAt: verificationData.verifiedAt || null
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error checking email verification:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to check email verification',
      details: error.message 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

export const config = {
  path: '/api/check-email-verification'
};
