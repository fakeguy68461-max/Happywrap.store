import { getStore } from '@netlify/blobs';
import { normalizeEmail, hashOTP } from './lib/otp-utils.mjs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method Not Allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  const headers = {
    'Content-Type': 'application/json',
    'Cache-Control': 'no-store'
  };

  try {
    const { email, otp } = await req.json();

    if (!email || !otp) {
      return new Response(JSON.stringify({ error: 'Email and OTP are required' }), {
        status: 400,
        headers,
      });
    }

    const normalizedEmail = normalizeEmail(email); // This is the NEW email
    const store = getStore('otp_codes');
    const key = `otp:email:${normalizedEmail}`;
    
    // 1. Verify OTP
    let otpData = null;
    try {
        const rawData = await store.get(key);
        if (rawData) otpData = JSON.parse(rawData);
    } catch (e) {
        console.error('Error accessing OTP store:', e);
    }

    if (!otpData) {
      return new Response(JSON.stringify({ error: 'OTP not found or expired' }), {
        status: 400,
        headers,
      });
    }

    if (Date.now() > otpData.expiresAt) {
      await store.delete(key);
      return new Response(JSON.stringify({ error: 'OTP expired' }), {
        status: 400,
        headers,
      });
    }

    if (otpData.type !== 'email_change') {
         return new Response(JSON.stringify({ error: 'Invalid OTP type' }), { status: 400, headers });
    }

    const inputOtp = String(otp).trim();
    if (otpData.otpHash && hashOTP(inputOtp) !== otpData.otpHash) {
        otpData.attempts = (otpData.attempts || 0) + 1;
        await store.setJSON(key, otpData);
        
        if (otpData.attempts >= 5) {
            await store.delete(key);
            return new Response(JSON.stringify({ error: 'Too many failed attempts' }), { status: 400, headers });
        }
        
        return new Response(JSON.stringify({ error: 'Invalid OTP code' }), { status: 200, headers });
    }

    // OTP Verified
    await store.delete(key);

    // 2. Perform Email Change
    const pendingStore = getStore('pending_email_changes');
    const pendingData = await pendingStore.get(normalizedEmail, { type: 'json' });

    if (!pendingData) {
        return new Response(JSON.stringify({ error: 'Email change session expired.' }), {
            status: 400,
            headers,
        });
    }

    const { oldEmail, userId } = pendingData;
    const accountsStore = getStore('user-accounts');
    
    // Double check new email is still free
    if (await accountsStore.get(normalizedEmail)) {
        return new Response(JSON.stringify({ error: 'Email is already in use' }), { status: 400, headers });
    }

    // Get old account data
    const oldAccountData = await accountsStore.get(oldEmail, { type: 'json' });
    if (!oldAccountData) {
        return new Response(JSON.stringify({ error: 'Original account not found' }), { status: 400, headers });
    }

    // Update data
    const newAccountData = {
        ...oldAccountData,
        email: normalizedEmail,
        emailChangedAt: new Date().toISOString()
    };

    // Save to new key
    await accountsStore.setJSON(normalizedEmail, newAccountData, {
        metadata: { userId, email: normalizedEmail, verified: 'true' }
    });

    // Delete old key
    await accountsStore.delete(oldEmail);

    // Cleanup pending
    await pendingStore.delete(normalizedEmail);

    return new Response(JSON.stringify({ 
        success: true, 
        message: 'Email changed successfully. Please login with your new email.' 
    }), {
        status: 200,
        headers,
    });

  } catch (error) {
    console.error('Error in verify-email-change-otp:', error);
    return new Response(JSON.stringify({ error: 'Internal Server Error' }), {
      status: 500,
      headers,
    });
  }
};

export const config = {
  path: '/api/verify-email-change-otp'
};
