import { getStore } from '@netlify/blobs';
import { MILESTONES, getLoyaltyDiscount } from './lib/loyalty.mjs';

export default async (req, context) => {
    // Allow GET or POST (GET with query param, POST with body)
    if (req.method !== 'GET' && req.method !== 'POST') {
        return new Response(JSON.stringify({ error: 'Method Not Allowed' }), { status: 405 });
    }

    let email;

    try {
        if (req.method === 'GET') {
            const url = new URL(req.url);
            email = url.searchParams.get('email');
        } else {
            const body = await req.json();
            email = body.email;
        }

        // Basic validation
        if (!email) {
            return new Response(JSON.stringify({ error: 'Email is required' }), { status: 400 });
        }

        const store = getStore('user-accounts');
        const userStr = await store.get(email);

        // Default empty profile
        let user = { 
            total_completed_orders: 0, 
            loyalty_tier: 'NORMAL',
            rewards_unlocked: []
        };

        if (userStr) {
            user = JSON.parse(userStr);
        }

        // Calculate Stats
        const totalOrders = user.total_completed_orders || 0;
        const isVip = user.loyalty_tier === 'VIP';
        
        // Milestones Processing
        const milestonesList = Object.keys(MILESTONES)
            .map(k => parseInt(k))
            .sort((a, b) => a - b)
            .map(num => {
                const m = MILESTONES[num];
                const isUnlocked = totalOrders >= num;
                return {
                    orderNum: num,
                    desc: m.desc,
                    status: isUnlocked ? 'unlocked' : 'locked'
                };
            });

        // Find Next Reward
        let nextReward = null;
        if (!isVip) {
            const nextM = milestonesList.find(m => m.status === 'locked');
            if (nextM) {
                nextReward = {
                    desc: nextM.desc,
                    orders_needed: nextM.orderNum - totalOrders,
                    milestone_num: nextM.orderNum
                };
            }
        }

        // Calculate discount for the *current* (upcoming) order
        const discountData = getLoyaltyDiscount(user);

        const responseData = {
            total_completed_orders: totalOrders,
            loyalty_tier: user.loyalty_tier || 'NORMAL',
            vip_unlocked_at: user.vip_unlocked_at || null,
            milestones: milestonesList,
            next_reward: nextReward,
            is_vip: isVip,
            vip_progress: Math.min(100, (totalOrders / 10) * 100),
            current_order_discount: discountData
        };

        return new Response(JSON.stringify({ success: true, ...responseData }), {
            status: 200, 
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (err) {
        console.error('Error fetching loyalty profile:', err);
        return new Response(JSON.stringify({ error: 'Internal Server Error' }), { status: 500 });
    }
};

export const config = {
    path: '/api/get-loyalty-profile'
};