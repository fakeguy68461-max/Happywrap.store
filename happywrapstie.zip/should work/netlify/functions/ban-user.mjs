import { getStore } from '@netlify/blobs';
import { getSiteUrl } from './lib/getUrl.mjs';
import { verifyAuth } from './lib/auth.mjs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    // Authenticate
    await verifyAuth(req);

    const { userId, banned } = await req.json();

    if (!userId || typeof banned !== 'boolean') {
      return new Response(JSON.stringify({ error: 'Missing or invalid fields' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Update user in Blobs
    const accountsStore = getStore('user-accounts');
    
    // logic in get-users maps id to email, so userId here is actually the email
    const userEmail = userId; 
    
    const userDataStr = await accountsStore.get(userEmail);
    
    if (!userDataStr) {
        return new Response(JSON.stringify({ error: 'User not found' }), {
            status: 404,
            headers: { 'Content-Type': 'application/json' }
        });
    }
    
    const userData = JSON.parse(userDataStr);
    
    // Update banned status
    userData.banned = banned;
    
    // Save back to store
    await accountsStore.set(userEmail, JSON.stringify(userData), {
        metadata: { 
            userId: userData.userId, 
            email: userData.email, 
            verified: userData.verified ? 'true' : 'false',
            provider: userData.provider,
            banned: banned ? 'true' : 'false'
        }
    });

    return new Response(JSON.stringify({ 
      success: true,
      message: `User ${banned ? 'banned' : 'unbanned'} successfully`,
      user: {
        id: userData.email,
        email: userData.email,
        app_metadata: { banned: banned }
      }
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error banning/unbanning user:', error);
    const status = error.message.includes('Unauthorized') || error.message.includes('Forbidden') ? 401 : 500;
    return new Response(JSON.stringify({ 
      error: error.message || 'Failed to update user status' 
    }), {
      status: status,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};


export const config = {
  path: '/api/admin/ban-user'
};