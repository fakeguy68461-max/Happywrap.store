export const orderProcessingTemplate = ({
  CUSTOMER_NAME,
  ORDER_NUMBER,
  ORDER_DATE,
  ORDER_ITEMS,
  SUBTOTAL,
  SHIPPING,
  TAX,
  TOTAL,
  SHIPPING_ADDRESS,
  BOX_DETAILS
}) => `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Processing Confirmation</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f5f5f5;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5;">
    <tr>
      <td align="center" style="padding: 40px 20px;">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">

          <tr>
            <td style="padding: 40px 40px 30px; text-align: center; background-color: #10b981; border-radius: 8px 8px 0 0;">
              <h1 style="margin: 0; color: #ffffff; font-size: 28px; font-weight: bold;">HappyWrap</h1>
            </td>
          </tr>

          <tr>
            <td style="padding: 40px;">
              <h2 style="margin: 0 0 20px; color: #1f2937; font-size: 24px;">Hi ${CUSTOMER_NAME},</h2>
              <p style="margin: 0 0 20px; color: #4b5563; font-size: 16px; line-height: 1.6;">
                Great news! Your order has been confirmed and verified by HappyWrap. Your order will be arriving soon!
              </p>

              <div style="margin: 30px 0; padding: 20px; background-color: #d1fae5; border-left: 4px solid #10b981; border-radius: 4px;">
                <p style="margin: 0; color: #065f46; font-size: 15px; line-height: 1.6;">
                  <strong>Order Status:</strong> Confirmed and Processing<br>
                  We're preparing your items for shipment. You'll receive another email with tracking information once your order ships.
                </p>
              </div>

              <div style="margin-top: 40px; padding-top: 30px; border-top: 2px solid #e5e7eb;">
                <h3 style="margin: 0 0 20px; color: #1f2937; font-size: 20px;">Order Details</h3>

                <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom: 20px;">
                  <tr>
                    <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Order Number:</td>
                    <td style="padding: 8px 0; color: #1f2937; font-size: 14px; font-weight: bold; text-align: right;">#${ORDER_NUMBER}</td>
                  </tr>
                  <tr>
                    <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Order Date:</td>
                    <td style="padding: 8px 0; color: #1f2937; font-size: 14px; text-align: right;">${ORDER_DATE}</td>
                  </tr>
                </table>

                <div style="margin: 30px 0;">
                  ${BOX_DETAILS || ""}
                  <h4 style="margin: 0 0 15px; color: #1f2937; font-size: 16px;">Items Ordered</h4>
                  ${ORDER_ITEMS}
                </div>

                <table width="100%" cellpadding="0" cellspacing="0" style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
                  <tr>
                    <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Subtotal:</td>
                    <td style="padding: 8px 0; color: #1f2937; font-size: 14px; text-align: right;">$${SUBTOTAL}</td>
                  </tr>
                  <tr>
                    <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Shipping:</td>
                    <td style="padding: 8px 0; color: #1f2937; font-size: 14px; text-align: right;">$${SHIPPING}</td>
                  </tr>
                  <tr>
                    <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Tax:</td>
                    <td style="padding: 8px 0; color: #1f2937; font-size: 14px; text-align: right;">$${TAX}</td>
                  </tr>
                  <tr style="border-top: 2px solid #e5e7eb;">
                    <td style="padding: 15px 0 0; color: #1f2937; font-size: 18px; font-weight: bold;">Total:</td>
                    <td style="padding: 15px 0 0; color: #2563eb; font-size: 18px; font-weight: bold; text-align: right;">$${TOTAL}</td>
                  </tr>
                </table>

                <div style="margin-top: 30px; padding: 20px; background-color: #f9fafb; border-radius: 6px;">
                  <h4 style="margin: 0 0 10px; color: #1f2937; font-size: 16px;">Shipping Address</h4>
                  <p style="margin: 0; color: #4b5563; font-size: 14px; line-height: 1.6; white-space: pre-line;">${SHIPPING_ADDRESS}</p>
                </div>
              </div>

              <div style="margin-top: 40px; padding-top: 30px; border-top: 1px solid #e5e7eb;">
                <h3 style="margin: 0 0 15px; color: #1f2937; font-size: 18px;">What Happens Next?</h3>
                <ul style="margin: 0; padding-left: 20px; color: #4b5563; font-size: 14px; line-height: 1.8;">
                  <li>Your order is being processed and prepared for shipment</li>
                  <li>You'll receive a shipping confirmation email with tracking details</li>
                  <li>Your order will arrive within 3-5 business days</li>
                  <li>Track your order anytime in your account dashboard</li>
                </ul>
              </div>

            </td>
          </tr>

          <tr>
            <td style="padding: 30px 40px; background-color: #f9fafb; border-radius: 0 0 8px 8px; text-align: center;">
              <p style="margin: 0 0 10px; color: #6b7280; font-size: 14px;">
                Need help? Contact us at <a href="mailto:support@happywrap.com" style="color: #2563eb; text-decoration: none;">support@happywrap.com</a>
              </p>
              <p style="margin: 0; color: #9ca3af; font-size: 12px;">
                © 2025 HappyWrap. All rights reserved.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>
`;
