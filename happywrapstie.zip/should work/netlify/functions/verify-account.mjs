import { getStore } from '@netlify/blobs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { email, token } = await req.json();

    if (!email || !token) {
      return new Response(JSON.stringify({ error: 'Email and token are required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const accountsStore = getStore('user-accounts');
    const accountDataStr = await accountsStore.get(email);

    if (!accountDataStr) {
      return new Response(JSON.stringify({ error: 'Account not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const accountData = JSON.parse(accountDataStr);

    if (accountData.verified) {
      return new Response(JSON.stringify({ 
        success: true, 
        message: 'Account already verified'
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    if (accountData.verificationToken !== token) {
      return new Response(JSON.stringify({ error: 'Invalid verification token' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    accountData.verified = true;
    accountData.verifiedAt = new Date().toISOString();
    delete accountData.verificationToken;

    await accountsStore.set(email, JSON.stringify(accountData), {
      metadata: { userId: accountData.userId, email, verified: 'true' }
    });

    // Also store in verified-emails for quick lookup
    try {
      const verifiedStore = getStore('verified-emails');
      await verifiedStore.set(email, JSON.stringify({
        userId: accountData.userId,
        email: email,
        verifiedAt: accountData.verifiedAt
      }), {
        metadata: {
          userId: accountData.userId,
          verifiedAt: accountData.verifiedAt
        }
      });
    } catch (verifiedStoreError) {
      console.error('Error updating verified-emails store:', verifiedStoreError);
    }

    console.log('Account verified for:', email);

    return new Response(JSON.stringify({ 
      success: true, 
      message: 'Account verified successfully. You can now log in.'
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error verifying account:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to verify account',
      details: error.message 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

export const config = {
  path: '/api/verify-account'
};
