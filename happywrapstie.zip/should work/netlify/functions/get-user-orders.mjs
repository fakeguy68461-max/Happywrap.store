import { getStore } from '@netlify/blobs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { email, userId, token } = await req.json();
    let userEmail = email;
    let verifiedUserId = null;
    let isAuthenticated = false;

    // 1. Check Netlify Identity Token (if provided)
    if (token) {
       try {
        const verifyResponse = await fetch(`${process.env.URL}/.netlify/identity/user`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        if (verifyResponse.ok) {
            const user = await verifyResponse.json();
            userEmail = user.email;
            verifiedUserId = user.id; // STRICT: Get ID from token
            isAuthenticated = true;
        }
       } catch (e) {
           console.log("Token verification failed", e);
       }
    }

    // 2. Check Custom Auth (if no valid token yet)
    if (!isAuthenticated && email && userId) {
        const accountsStore = getStore('user-accounts');
        const accountDataStr = await accountsStore.get(email);
        
        if (accountDataStr) {
            const accountData = JSON.parse(accountDataStr);
            if (accountData.userId === userId) {
                isAuthenticated = true;
                verifiedUserId = userId; // STRICT: Trust this ID because we verified password/otp via login previously
            }
        }
    }

    if (!isAuthenticated) {
        return new Response(JSON.stringify({ error: 'Unauthorized' }), {
            status: 401,
            headers: { 'Content-Type': 'application/json' }
        });
    }

    // 3. Fetch Orders
    const store = getStore('confirmed-orders');
    const { blobs } = await store.list();
    
    const userOrders = [];
    for (const blob of blobs) {
        try {
            const orderDataString = await store.get(blob.key);
            if (orderDataString) {
                const order = JSON.parse(orderDataString);
                
                // STRICT FILTERING:
                // 1. If order has userId, it MUST match verifiedUserId
                // 2. If order has no userId (legacy), match by email
                
                let isMatch = false;

                if (order.userId && verifiedUserId) {
                    if (order.userId === verifiedUserId) {
                        isMatch = true;
                    }
                } else if (order.email && userEmail) {
                    // Fallback to email for legacy orders or if userId missing in order/auth
                    if (order.email.toLowerCase() === userEmail.toLowerCase()) {
                        isMatch = true;
                    }
                }

                if (isMatch) {
                    userOrders.push(order);
                }
            }
        } catch (err) {
            console.error(`Error processing order ${blob.key}:`, err);
        }
    }

    userOrders.sort((a, b) => {
        const dateA = new Date(a.confirmedAt || a.createdAt || 0);
        const dateB = new Date(b.confirmedAt || b.createdAt || 0);
        return dateB - dateA;
    });

    return new Response(JSON.stringify({ 
        success: true, 
        orders: userOrders 
    }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error fetching user orders:', error);
    return new Response(JSON.stringify({ 
        error: 'Failed to fetch orders',
        details: error.message 
    }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
    });
  }
};

export const config = {
  path: '/api/get-user-orders'
};
