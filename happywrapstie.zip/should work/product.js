// Product Detail Page JavaScript

let currentProduct = null;

// Load product details
async function loadProductDetails() {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id');
    
    if (!productId) {
        window.location.href = 'shop.html';
        return;
    }
    
    try {
        const response = await fetch('products.json');
        const data = await response.json();
        currentProduct = data.products.find(p => p.id === productId);
        
        if (!currentProduct) {
            alert('Product not found');
            window.location.href = 'shop.html';
            return;
        }
        
        displayProductDetails();
        
        // Load reviews and questions from API
        if (typeof loadReviews === 'function') {
            loadReviews(productId);
        }
        
        if (typeof loadQuestions === 'function') {
            loadQuestions(productId);
        }
    } catch (error) {
        console.error('Error loading product:', error);
        alert('Error loading product details');
    }
}

// Display product details
function displayProductDetails() {
    document.getElementById('productImage').src = currentProduct.image;
    document.getElementById('productImage').alt = currentProduct.name;
    document.getElementById('productImage').onerror = function() {
        this.src = 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'500\' height=\'500\'%3E%3Crect width=\'500\' height=\'500\' fill=\'%23f3f4f6\'/%3E%3Ctext x=\'50%25\' y=\'50%25\' dominant-baseline=\'middle\' text-anchor=\'middle\' font-family=\'sans-serif\' font-size=\'24\' fill=\'%236b7280\'%3ENo Image%3C/text%3E%3C/svg%3E';
    };
    
    document.getElementById('productCategory').textContent = getCategoryName(currentProduct.category);
    document.getElementById('productName').textContent = currentProduct.name;
    document.getElementById('productPrice').textContent = formatPrice(currentProduct.price);
    document.getElementById('productDescription').textContent = currentProduct.description;
    
    // Update wishlist button
    const wishlistBtn = document.getElementById('wishlistBtn');
    if (wishlist.isInWishlist(currentProduct.id)) {
        wishlistBtn.textContent = '❤️';
        wishlistBtn.classList.add('active');
    }
    
    // Update page title
    document.title = `${currentProduct.name} - HappyWrap`;
}

// Get category display name
function getCategoryName(category) {
    const names = {
        'electronics': 'Electronics',
        'toys': 'Toys',
        'home-kitchen': 'Home & Kitchen',
        'sports-outdoors': 'Sports & Outdoors',
        'books-media': 'Books & Media'
    };
    return names[category] || category;
}

// Get stored reviews
function getStoredReviews(productId) {
    const stored = localStorage.getItem(`reviews_${productId}`);
    return stored ? JSON.parse(stored) : [];
}

// Get stored questions
function getStoredQuestions(productId) {
    const stored = localStorage.getItem(`questions_${productId}`);
    return stored ? JSON.parse(stored) : [];
}

// Load default reviews
function loadDefaultReviews() {
    const reviewsList = document.getElementById('reviewsList');
    reviewsList.innerHTML = `
        <div class="review-item">
            <div class="review-header">
                <strong>John D.</strong>
                <span class="rating-display">⭐⭐⭐⭐⭐</span>
            </div>
            <p class="review-date">2 days ago</p>
            <p class="review-text">Excellent product! Highly recommend it to everyone.</p>
        </div>
        <div class="review-item">
            <div class="review-header">
                <strong>Sarah M.</strong>
                <span class="rating-display">⭐⭐⭐⭐</span>
            </div>
            <p class="review-date">1 week ago</p>
            <p class="review-text">Great quality and fast shipping. Very satisfied with my purchase.</p>
        </div>
    `;
}

// Load default questions
function loadDefaultQuestions() {
    const questionsList = document.getElementById('questionsList');
    questionsList.innerHTML = `
        <div class="question-item">
            <div class="question-header">
                <strong>Mike R.</strong> asked:
            </div>
            <p class="question-text">Is this compatible with all devices?</p>
            <div class="answer">
                <strong>HappyWrap Team:</strong>
                <p>Yes, it works with all modern devices and operating systems.</p>
            </div>
        </div>
        <div class="question-item">
            <div class="question-header">
                <strong>Emily K.</strong> asked:
            </div>
            <p class="question-text">What's the warranty period?</p>
            <div class="answer">
                <strong>HappyWrap Team:</strong>
                <p>This product comes with a 1-year manufacturer warranty.</p>
            </div>
        </div>
    `;
}

// Initialize product page
document.addEventListener('DOMContentLoaded', () => {
    loadProductDetails();
    
    // Add to cart button
    document.getElementById('addToCartBtn').addEventListener('click', () => {
        if (currentProduct) {
            cart.addItem(currentProduct);
            const btn = document.getElementById('addToCartBtn');
            const originalText = btn.innerHTML;
            btn.innerHTML = '✓ Added to Box!';
            btn.style.backgroundColor = '#10b981';
            
            setTimeout(() => {
                btn.innerHTML = originalText;
                btn.style.backgroundColor = '';
            }, 2000);
        }
    });
    
    // Share product button
    document.getElementById('shareProductBtn').addEventListener('click', async () => {
        const url = window.location.href;
        
        if (navigator.share) {
            try {
                await navigator.share({
                    title: currentProduct.name,
                    text: currentProduct.description,
                    url: url
                });
            } catch (err) {
                copyToClipboard(url);
            }
        } else {
            copyToClipboard(url);
        }
    });
    
    // Wishlist button
    document.getElementById('wishlistBtn').addEventListener('click', () => {
        if (!isAuthenticated()) {
            showNotification(
                'Login Required',
                'Please login to add items to your wishlist',
                'warning'
            );
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 2000);
            return;
        }
        
        const btn = document.getElementById('wishlistBtn');
        
        if (wishlist.isInWishlist(currentProduct.id)) {
            wishlist.removeItem(currentProduct.id);
            btn.textContent = '🤍';
            btn.classList.remove('active');
            showNotification(
                'Removed from Wishlist',
                `${currentProduct.name} has been removed`,
                'info'
            );
        } else {
            wishlist.addItem(currentProduct);
            btn.textContent = '❤️';
            btn.classList.add('active');
            showNotification(
                'Added to Wishlist',
                `${currentProduct.name} is now in your wishlist`,
                'success'
            );
        }
    });
    
    // Leave review button
    document.getElementById('leaveReviewBtn').addEventListener('click', () => {
        if (!requireAuth()) {
            showNotification(
                'Authentication Required',
                'Only authenticated users can leave reviews',
                'warning'
            );
            return;
        }
        document.getElementById('reviewModal').style.display = 'flex';
    });
    
    // Ask question button
    document.getElementById('askQuestionBtn').addEventListener('click', () => {
        if (!requireAuth()) {
            showNotification(
                'Authentication Required',
                'Only authenticated users can ask questions',
                'warning'
            );
            return;
        }
        document.getElementById('questionModal').style.display = 'flex';
    });
    
    // Close modals
    document.getElementById('closeReviewModal').addEventListener('click', () => {
        document.getElementById('reviewModal').style.display = 'none';
    });
    
    document.getElementById('closeQuestionModal').addEventListener('click', () => {
        document.getElementById('questionModal').style.display = 'none';
    });
});

// Copy to clipboard
function copyToClipboard(text) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(() => {
            alert('Product link copied to clipboard!');
        });
    } else {
        // Fallback
        const input = document.createElement('input');
        input.value = text;
        document.body.appendChild(input);
        input.select();
        document.execCommand('copy');
        document.body.removeChild(input);
        alert('Product link copied to clipboard!');
    }
}