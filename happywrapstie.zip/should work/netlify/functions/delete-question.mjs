import { getStore } from '@netlify/blobs';
import { verifyAuth } from './lib/auth.mjs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    await verifyAuth(req);

    const { productId, questionDate } = await req.json();

    if (!productId || !questionDate) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const store = getStore('questions');

    // 1. Update Global All Questions
    const globalData = await store.get('all-questions');
    let globalQuestions;
    
    if (globalData) {
        globalQuestions = JSON.parse(globalData);
    } else {
         const legacyData = await store.get('global-recent');
         globalQuestions = legacyData ? JSON.parse(legacyData) : [];
    }

    const initialGlobalCount = globalQuestions.length;
    globalQuestions = globalQuestions.filter(q => !(q.productId === productId && q.date === questionDate));

    if (globalQuestions.length !== initialGlobalCount) {
        await store.set('all-questions', JSON.stringify(globalQuestions));
    }

    // 2. Update Product Specific
    const productData = await store.get(`product-${productId}`);
    if (productData) {
        let productQuestions = JSON.parse(productData);
        const initialProductCount = productQuestions.length;
        productQuestions = productQuestions.filter(q => q.date !== questionDate);
        
        if (productQuestions.length !== initialProductCount) {
            await store.set(`product-${productId}`, JSON.stringify(productQuestions));
        }
    }

    return new Response(JSON.stringify({ 
      success: true,
      message: 'Question deleted successfully'
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error deleting question:', error);
    const status = error.message.includes('Unauthorized') || error.message.includes('Forbidden') ? 401 : 500;
    return new Response(JSON.stringify({ 
      error: error.message || 'Failed to delete question'
    }), {
      status: status,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

export const config = {
  path: '/api/admin/delete-question'
};
