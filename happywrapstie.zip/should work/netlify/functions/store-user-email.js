import { getStore } from '@netlify/blobs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { email, name, timestamp, userId, provider, fullName } = await req.json();

    if (!email) {
      return new Response(JSON.stringify({ error: 'Email is required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const store = getStore('user-emails');

    const existingEmails = await store.get('emails', { type: 'json' }) || [];

    const emailData = {
      email,
      name: name || fullName || '',
      timestamp: timestamp || new Date().toISOString()
    };

    const emailExists = existingEmails.some(entry => entry.email === email);

    if (!emailExists) {
      existingEmails.push(emailData);
      await store.setJSON('emails', existingEmails);
    }

    // For Google OAuth users, also store in user-accounts database
    if (provider === 'google' && userId) {
      const accountsStore = getStore('user-accounts');
      const existingAccount = await accountsStore.get(email);

      if (!existingAccount) {
        const names = (fullName || name || email.split('@')[0]).split(' ');
        const firstName = names[0] || '';
        const lastName = names.slice(1).join(' ') || '';

        const accountData = {
          userId: userId,
          firstName: firstName,
          lastName: lastName,
          email: email,
          dateOfBirth: null,
          hashedPassword: null,
          verified: true, // Google OAuth users are pre-verified
          provider: 'google',
          createdAt: new Date().toISOString()
        };

        await accountsStore.set(email, JSON.stringify(accountData), {
          metadata: { userId, email, verified: 'true', provider: 'google' }
        });

        console.log('Google OAuth user saved to database:', email);
      }
    }

    return new Response(JSON.stringify({
      success: true,
      message: 'Email stored successfully'
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error storing email:', error);
    return new Response(JSON.stringify({
      error: 'Failed to store email',
      details: error.message
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

export const config = {
  path: '/api/store-user-email'
};
