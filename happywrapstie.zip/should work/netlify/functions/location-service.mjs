import fetch from 'node-fetch';

export default async (req, context) => {
    // Enable CORS
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Content-Type': 'application/json'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 204, headers });
    }

    const API_KEY = process.env.PUBLIC_LOCATIONIQ_KEY;
    if (!API_KEY) {
        return new Response(JSON.stringify({ error: 'Server configuration error: Missing API Key' }), {
            status: 500,
            headers
        });
    }

    const url = new URL(req.url);
    const action = url.searchParams.get('action');
    
    // Lahore Bounds for Viewbox (approximate)
    // viewbox=<x1>,<y1>,<x2>,<y2> (minLon, minLat, maxLon, maxLat)
    // Lahore: 74.00, 31.10 to 74.70, 31.85
    const LAHORE_VIEWBOX = '74.00,31.10,74.70,31.85';

    try {
        let apiUrl = '';
        
        if (action === 'autocomplete') {
            const query = url.searchParams.get('q');
            if (!query) {
                return new Response(JSON.stringify({ error: 'Missing query' }), { status: 400, headers });
            }
            // Strict bounding to Lahore
            apiUrl = `https://api.locationiq.com/v1/autocomplete.php?key=${API_KEY}&q=${encodeURIComponent(query)}&limit=5&countrycodes=pk&viewbox=${LAHORE_VIEWBOX}&bounded=1&format=json`;
        
        } else if (action === 'reverse') {
            const lat = url.searchParams.get('lat');
            const lon = url.searchParams.get('lon');
            if (!lat || !lon) {
                return new Response(JSON.stringify({ error: 'Missing coordinates' }), { status: 400, headers });
            }
            apiUrl = `https://us1.locationiq.com/v1/reverse.php?key=${API_KEY}&lat=${lat}&lon=${lon}&format=json&zoom=18&addressdetails=1&accept-language=en`;
        
        } else {
            return new Response(JSON.stringify({ error: 'Invalid action' }), { status: 400, headers });
        }

        const apiResponse = await fetch(apiUrl);
        if (!apiResponse.ok) {
            const text = await apiResponse.text();
            console.error('LocationIQ API Error:', text);
            return new Response(JSON.stringify({ error: 'External API error' }), { status: apiResponse.status, headers });
        }

        const data = await apiResponse.json();
        return new Response(JSON.stringify(data), { status: 200, headers });

    } catch (error) {
        console.error('Proxy Error:', error);
        return new Response(JSON.stringify({ error: 'Internal Server Error' }), { status: 500, headers });
    }
};

export const config = {
    path: '/api/location-service'
};
