import { getStore } from '@netlify/blobs';
import { normalizeEmail, hashOTP } from './lib/otp-utils.mjs';
import crypto from 'node:crypto';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method Not Allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  const headers = {
    'Content-Type': 'application/json',
    'Cache-Control': 'no-store'
  };

  try {
    const { email, otp } = await req.json();

    if (!email || !otp) {
      return new Response(JSON.stringify({ error: 'Email and OTP are required' }), {
        status: 400,
        headers,
      });
    }

    const normalizedEmail = normalizeEmail(email);
    const store = getStore('otp_codes');
    const key = `otp:email:${normalizedEmail}`;
    
    // 1. Verify OTP
    let otpData = null;
    try {
        const rawData = await store.get(key);
        if (rawData) otpData = JSON.parse(rawData);
    } catch (e) {
        console.error('Error accessing OTP store:', e);
    }

    if (!otpData) {
      return new Response(JSON.stringify({ error: 'OTP not found or expired' }), {
        status: 400,
        headers,
      });
    }

    if (Date.now() > otpData.expiresAt) {
      await store.delete(key);
      return new Response(JSON.stringify({ error: 'OTP expired' }), {
        status: 400,
        headers,
      });
    }

    if (otpData.type !== 'password_reset') {
         return new Response(JSON.stringify({ error: 'Invalid OTP type' }), { status: 400, headers });
    }

    const inputOtp = String(otp).trim();
    if (otpData.otpHash && hashOTP(inputOtp) !== otpData.otpHash) {
        otpData.attempts = (otpData.attempts || 0) + 1;
        await store.setJSON(key, otpData);
        
        if (otpData.attempts >= 5) {
            await store.delete(key);
            return new Response(JSON.stringify({ error: 'Too many failed attempts' }), { status: 400, headers });
        }
        
        return new Response(JSON.stringify({ error: 'Invalid OTP code' }), { status: 200, headers });
    }

    // OTP Verified
    await store.delete(key);

    // 2. Generate Reset Token
    const resetToken = crypto.randomBytes(32).toString('hex');
    const resetStore = getStore('password-resets');
    
    // Expires in 1 hour
    const expiresAt = Date.now() + 60 * 60 * 1000;

    await resetStore.setJSON(resetToken, {
        email: normalizedEmail,
        token: resetToken,
        expiresAt,
        createdAt: Date.now(),
        used: false
    });

    return new Response(JSON.stringify({ 
        success: true, 
        resetToken: resetToken
    }), {
        status: 200,
        headers,
    });

  } catch (error) {
    console.error('Error in verify-password-reset-otp:', error);
    return new Response(JSON.stringify({ error: 'Internal Server Error' }), {
      status: 500,
      headers,
    });
  }
};

export const config = {
  path: '/api/verify-password-reset-otp'
};
