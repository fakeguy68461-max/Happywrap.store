import { getStore } from '@netlify/blobs';
import { orderConfirmationTemplate, formatOrderItems } from '../email-templates/index.js';
import { sendEmailSMTP } from './lib/smtp-mailer.mjs';
import { getSiteUrl } from './lib/getUrl.mjs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { orderId, email, name, orderData } = await req.json();

    if (!orderId || !email || !orderData) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const confirmationToken = generateToken();
    const store = getStore('pending-orders');
    
    await store.set(confirmationToken, JSON.stringify({
      orderId,
      email,
      name,
      orderData,
      createdAt: new Date().toISOString(),
      confirmed: false
    }), {
      metadata: { orderId, email }
    });

    const siteUrl = getSiteUrl();
    const confirmationLink = `${siteUrl}/order-confirm.html?token=${confirmationToken}`;

    const subtotal = orderData.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const shipping = 5.99;
    const tax = subtotal * 0.10;
    const shippingInfo = orderData.shippingInfo || {};
    const shippingAddress = `${shippingInfo.name || name}
${shippingInfo.address || ''}
${shippingInfo.city || ''}, ${shippingInfo.country || ''}
${shippingInfo.postalCode || ''}`;

    const emailSubject = `HappyWrap Order Confirmation Required - Order #${orderId}`;
    const emailBody = orderConfirmationTemplate({
      CUSTOMER_NAME: name || 'Customer',
      ORDER_NUMBER: orderId,
      ORDER_DATE: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
      ORDER_ITEMS: formatOrderItems(orderData.items || []),
      SUBTOTAL: subtotal.toFixed(2),
      SHIPPING: shipping.toFixed(2),
      TAX: tax.toFixed(2),
      TOTAL: (orderData.total || 0).toFixed(2),
      SHIPPING_ADDRESS: shippingAddress,
      CONFIRMATION_LINK: confirmationLink
    });

    let emailSent = false;
    let emailError = null;
    try {
      emailSent = await sendEmailSMTP(email, emailSubject, emailBody);
    } catch (error) {
      console.error('SMTP error:', error);
      emailError = error.message;
    }
    
    console.log('Order confirmation email sent to:', email);
    console.log('Confirmation token:', confirmationToken);
    console.log('Email sent status:', emailSent);

    if (!emailSent) {
      console.warn('Email failed to send via SMTP. Error:', emailError || 'Unknown error');

      // Check if SMTP is configured using the helper pattern
      const smtpEmail = typeof Netlify !== 'undefined' && Netlify.env
        ? Netlify.env.get('SMTP_EMAIL')
        : process.env.SMTP_EMAIL;
      const smtpPassword = typeof Netlify !== 'undefined' && Netlify.env
        ? Netlify.env.get('SMTP_PASSWORD')
        : process.env.SMTP_PASSWORD;
      
      if (!smtpEmail || !smtpPassword) {
        console.error('CRITICAL: SMTP credentials (SMTP_EMAIL and/or SMTP_PASSWORD) are not configured in environment variables');
        return new Response(JSON.stringify({ 
          success: false,
          error: 'Email service is not properly configured. Please contact support or use the direct confirmation link.',
          token: confirmationToken,
          confirmationLink,
          emailSent: false,
          needsConfiguration: true
        }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' }
        });
      }
    }

    return new Response(JSON.stringify({ 
      success: true, 
      message: emailSent 
        ? 'Order confirmation email sent. Please check your inbox (it may take 3-4 minutes to arrive).'
        : 'Order placed successfully. Confirmation link generated.',
      token: confirmationToken,
      confirmationLink,
      emailSent
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error sending order confirmation:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to send confirmation email',
      details: error.message 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

function generateToken() {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}`;
}

export const config = {
  path: '/api/send-order-email'
};
