import { orderProcessingTemplate, formatOrderItems } from '../email-templates/index.js';
import { sendEmailSMTP } from './lib/smtp-mailer.mjs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { orderId, email, name, orderData } = await req.json();

    if (!orderId || !email || !orderData) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const shippingInfo = orderData.shippingInfo || {};
    const shippingAddress = `${shippingInfo.name || name}
${shippingInfo.address || ''}
${shippingInfo.city || ''}, ${shippingInfo.country || ''}
${shippingInfo.postalCode || ''}`;

    // Format Boxes HTML
    let boxDetailsHtml = '';
    if (orderData.boxes && orderData.boxes.length > 0) {
      boxDetailsHtml = `
        <h4 style="margin: 0 0 10px; color: #ec4899; font-size: 16px;">🎁 Box Configurations</h4>
        <div style="background-color: #fff0f5; border: 1px solid #fbcfe8; border-radius: 4px; padding: 15px; margin-bottom: 20px;">
          ${orderData.boxes.map((box, idx) => `
            <div style="margin-bottom: 10px; padding-bottom: 10px; border-bottom: 1px solid #fbcfe8;">
              <p style="margin: 0 0 5px; color: #1f2937;"><strong>Box ${idx + 1}:</strong> <span style="text-transform: capitalize;">${box.boxColor}</span></p>
              <p style="margin: 0 0 5px; color: #4b5563; font-size: 14px;">To: ${box.recipientName}</p>
              <p style="margin: 0; color: #4b5563; font-size: 14px; font-style: italic;">"${box.message}"</p>
            </div>
          `).join('')}
        </div>
      `;
    }

    const emailSubject = `HappyWrap Order #${orderId} - Confirmed and Processing`;
    const emailBody = orderProcessingTemplate({
      CUSTOMER_NAME: name || 'Customer',
      ORDER_NUMBER: orderId,
      ORDER_DATE: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
      ORDER_ITEMS: formatOrderItems(orderData.items || []),
      SUBTOTAL: ((orderData.total || 0) - 5.99 - ((orderData.total || 0) - 5.99) * 0.1).toFixed(2),
      SHIPPING: '5.99',
      TAX: (((orderData.total || 0) - 5.99) * 0.1).toFixed(2),
      TOTAL: (orderData.total || 0).toFixed(2),
      SHIPPING_ADDRESS: shippingAddress,
      BOX_DETAILS: boxDetailsHtml
    });

    const emailSent = await sendEmailSMTP(email, emailSubject, emailBody);
    
    if (!emailSent) {
      console.error('Failed to send post-confirmation email to:', email);
      console.error('Please check SMTP credentials and configuration');
      return new Response(JSON.stringify({ 
        error: 'Failed to send confirmation email. Please try again or contact support.',
        details: 'Email service configuration error'
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }
    
    console.log('Post-confirmation email sent to:', email);
    console.log('Email sent status:', emailSent);

    return new Response(JSON.stringify({
      success: true,
      message: 'Order processing confirmation email sent successfully.'
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error sending post-confirmation email:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to send confirmation email',
      details: error.message 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

export const config = {
  path: '/api/send-confirmation-email'
};
