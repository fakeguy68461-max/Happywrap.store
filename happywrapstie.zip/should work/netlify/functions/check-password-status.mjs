import { getStore } from '@netlify/blobs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { userId } = await req.json();

    if (!userId) {
      return new Response(JSON.stringify({ error: 'Missing userId' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const store = getStore('user-passwords');
    const passwordDataString = await store.get(userId);
    
    if (!passwordDataString) {
      return new Response(JSON.stringify({ 
        hasPassword: false
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const passwordData = JSON.parse(passwordDataString);

    return new Response(JSON.stringify({ 
      hasPassword: passwordData.hasPassword || false,
      passwordSetAt: passwordData.passwordSetAt || null
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error checking password status:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to check password status',
      details: error.message 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

export const config = {
  path: '/api/check-password-status'
};
