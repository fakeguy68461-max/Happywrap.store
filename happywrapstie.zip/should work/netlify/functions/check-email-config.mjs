// netlify/functions/check-email-config.mjs

import { sendEmailSMTP } from './lib/smtp-mailer.mjs'; // correct path to smtp helper

export default async (req, context) => {
  // Read environment variables
  const smtpEmail = process.env.SMTP_EMAIL;
  const smtpPassword = process.env.SMTP_PASSWORD;
  const smtpServer = process.env.SMTP_SERVER;
  const smtpPort = process.env.SMTP_PORT;

  const config = {
    smtpServerConfigured: !!smtpServer,
    smtpServer: smtpServer || 'NOT SET',
    smtpPortConfigured: !!smtpPort,
    smtpPort: smtpPort || 'NOT SET',
    smtpEmailConfigured: !!smtpEmail,
    smtpEmail: smtpEmail
      ? `${smtpEmail.substring(0, 3)}***@${smtpEmail.split('@')[1] || 'NOT SET'}`
      : 'NOT SET',
    smtpPasswordConfigured: !!smtpPassword,
    smtpPasswordLength: smtpPassword ? smtpPassword.length : 0,
    allConfigured: !!(smtpEmail && smtpPassword && smtpServer && smtpPort)
  };

  // Optional: Test sending a dummy email if all configured
  if (config.allConfigured) {
    try {
      // You can uncomment this line to send a test email (optional)
      // await sendEmailSMTP(smtpEmail, 'Test Email', 'This is a test email from Netlify Functions.');
      config.testEmailStatus = 'Ready to send test email';
    } catch (err) {
      config.testEmailStatus = `Error sending test email: ${err.message}`;
    }
  } else {
    config.testEmailStatus = 'Cannot send test email — missing configuration';
  }

  return new Response(JSON.stringify(config, null, 2), {
    status: 200,
    headers: { 'Content-Type': 'application/json' }
  });
};

export const config = {
  path: '/api/check-email-config'
};