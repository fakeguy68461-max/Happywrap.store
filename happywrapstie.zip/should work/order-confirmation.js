export const orderConfirmationTemplate = ({
  CUSTOMER_NAME,
  ORDER_NUMBER,
  ORDER_DATE,
  ORDER_ITEMS,
  SUBTOTAL,
  SHIPPING,
  TAX,
  TOTAL,
  SHIPPING_ADDRESS,
  CONFIRMATION_LINK
}) => `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Confirmation</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f5f5f5;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5;">
    <tr>
      <td align="center" style="padding: 40px 20px;">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          
          <tr>
            <td style="padding: 40px 40px 30px; text-align: center; background-color: #2563eb; border-radius: 8px 8px 0 0;">
              <h1 style="margin: 0; color: #ffffff; font-size: 28px; font-weight: bold;">HappyWrap</h1>
            </td>
          </tr>
          
          <tr>
            <td style="padding: 40px;">
              <h2 style="margin: 0 0 20px; color: #1f2937; font-size: 24px;">Hi ${CUSTOMER_NAME},</h2>
              <p style="margin: 0 0 20px; color: #4b5563; font-size: 16px; line-height: 1.6;">
                Thank you for your order! We're excited to get your items to you. Please confirm your order to proceed with processing.
              </p>

              <p style="margin: 20px 0; color: #4b5563; font-size: 16px; line-height: 1.6;">
                <a href="${CONFIRMATION_LINK}"
                   style="color: #2563eb; text-decoration: underline; font-weight: 600;">
                  Click here to confirm your order
                </a>
              </p>
              
              <div style="margin-top: 40px; padding-top: 30px; border-top: 2px solid #e5e7eb;">
                <h3 style="margin: 0 0 20px; color: #1f2937; font-size: 20px;">Order Details</h3>
                
                <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom: 20px;">
                  <tr>
                    <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Order Number:</td>
                    <td style="padding: 8px 0; color: #1f2937; font-size: 14px; font-weight: bold; text-align: right;">#${ORDER_NUMBER}</td>
                  </tr>
                  <tr>
                    <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Order Date:</td>
                    <td style="padding: 8px 0; color: #1f2937; font-size: 14px; text-align: right;">${ORDER_DATE}</td>
                  </tr>
                </table>
                
                <div style="margin: 30px 0;">
                  <h4 style="margin: 0 0 15px; color: #1f2937; font-size: 16px;">Items Ordered</h4>
                  ${ORDER_ITEMS}
                </div>
                
                <table width="100%" cellpadding="0" cellspacing="0" style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
                  <tr>
                    <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Subtotal:</td>
                    <td style="padding: 8px 0; color: #1f2937; font-size: 14px; text-align: right;">$${SUBTOTAL}</td>
                  </tr>
                  <tr>
                    <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Shipping:</td>
                    <td style="padding: 8px 0; color: #1f2937; font-size: 14px; text-align: right;">$${SHIPPING}</td>
                  </tr>
                  <tr>
                    <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Tax:</td>
                    <td style="padding: 8px 0; color: #1f2937; font-size: 14px; text-align: right;">$${TAX}</td>
                  </tr>
                  <tr style="border-top: 2px solid #e5e7eb;">
                    <td style="padding: 15px 0 0; color: #1f2937; font-size: 18px; font-weight: bold;">Total:</td>
                    <td style="padding: 15px 0 0; color: #2563eb; font-size: 18px; font-weight: bold; text-align: right;">$${TOTAL}</td>
                  </tr>
                </table>
                
                <div style="margin-top: 30px; padding: 20px; background-color: #f9fafb; border-radius: 6px;">
                  <h4 style="margin: 0 0 10px; color: #1f2937; font-size: 16px;">Shipping Address</h4>
                  <p style="margin: 0; color: #4b5563; font-size: 14px; line-height: 1.6; white-space: pre-line;">${SHIPPING_ADDRESS}</p>
                </div>
              </div>
              
              <div style="margin-top: 40px; padding-top: 30px; border-top: 1px solid #e5e7eb;">
                <h3 style="margin: 0 0 15px; color: #1f2937; font-size: 18px;">What's Next?</h3>
                <ol style="margin: 0; padding-left: 20px; color: #4b5563; font-size: 14px; line-height: 1.8;">
                  <li>Click the confirmation button above to verify your order</li>
                  <li>We'll process your order and prepare it for shipment</li>
                  <li>You'll receive a shipping confirmation with tracking information</li>
                  <li>Your order will arrive within 3-5 business days</li>
                </ol>
              </div>
              
              <div style="margin-top: 30px; padding: 20px; background-color: #fef3c7; border-left: 4px solid #f59e0b; border-radius: 4px;">
                <p style="margin: 0; color: #92400e; font-size: 13px; line-height: 1.6;">
                  <strong>Important:</strong> This confirmation link will expire in 24 hours. If you didn't place this order, please ignore this email or contact our support team.
                </p>
              </div>
            </td>
          </tr>
          
          <tr>
            <td style="padding: 30px 40px; background-color: #f9fafb; border-radius: 0 0 8px 8px; text-align: center;">
              <p style="margin: 0 0 10px; color: #6b7280; font-size: 14px;">
                Need help? Contact us at <a href="mailto:support@happywrap.com" style="color: #2563eb; text-decoration: none;">support@happywrap.com</a>
              </p>
              <p style="margin: 0; color: #9ca3af; font-size: 12px;">
                © 2025 HappyWrap. All rights reserved.
              </p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
`;

export const formatOrderItems = (items) => {
  return items.map(item => `
    <div style="display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #e5e7eb;">
      <div>
        <p style="margin: 0 0 5px; color: #1f2937; font-size: 14px; font-weight: 600;">${item.name}</p>
        <p style="margin: 0; color: #6b7280; font-size: 13px;">Quantity: ${item.quantity}</p>
      </div>
      <p style="margin: 0; color: #1f2937; font-size: 14px; font-weight: 600;">$${(item.price * item.quantity).toFixed(2)}</p>
    </div>
  `).join('');
};
