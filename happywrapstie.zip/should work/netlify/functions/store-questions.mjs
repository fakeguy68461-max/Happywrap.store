import { getStore } from '@netlify/blobs';

export default async (req, context) => {
    if (req.method !== 'POST') {
        return new Response(JSON.stringify({ error: 'Method Not Allowed' }), {
            status: 405,
            headers: { 'Content-Type': 'application/json' }
        });
    }

    try {
        const question = await req.json();
        
        // Validate question data
        if (!question.productId || !question.userName || !question.question) {
            return new Response(JSON.stringify({ error: 'Missing required fields' }), {
                status: 400,
                headers: { 'Content-Type': 'application/json' }
            });
        }
        
        // Validate question length
        if (question.question.length < 10) {
            return new Response(JSON.stringify({ error: 'Question must be at least 10 characters' }), {
                status: 400,
                headers: { 'Content-Type': 'application/json' }
            });
        }
        
        const store = getStore('questions');
        
        // Get existing questions
        const existingData = await store.get(`product-${question.productId}`);
        const questions = existingData ? JSON.parse(existingData) : [];
        
        // Add new question
        const newQuestion = {
            ...question,
            date: new Date().toISOString(),
            answered: false,
            answer: "Thank you for your question! A HappyWrap representative will answer you shortly."
        };
        questions.push(newQuestion);
        
        // Save back to store
        await store.set(`product-${question.productId}`, JSON.stringify(questions));
        
        // Update global questions list (all questions)
        const allQuestionsData = await store.get('all-questions');
        let allQuestions;

        if (allQuestionsData) {
            allQuestions = JSON.parse(allQuestionsData);
        } else {
            // Migration: Try to get data from legacy 'global-recent' if 'all-questions' doesn't exist yet
            const legacyData = await store.get('global-recent');
            allQuestions = legacyData ? JSON.parse(legacyData) : [];
        }
        
        // Unshift adds to the beginning (newest first)
        allQuestions.unshift(newQuestion);
        
        // No limit on questions to ensure they are permanently hosted
        await store.set('all-questions', JSON.stringify(allQuestions));
        
        return new Response(JSON.stringify({ 
            success: true,
            message: 'Question stored successfully',
            question: newQuestion
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error) {
        console.error('Error storing question:', error);
        return new Response(JSON.stringify({ 
            error: 'Failed to store question',
            details: error.message
        }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }
};

export const config = {
    path: '/api/store-questions'
};