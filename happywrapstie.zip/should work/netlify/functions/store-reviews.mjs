import { getStore } from '@netlify/blobs';

export default async (req, context) => {
    if (req.method !== 'POST') {
        return new Response(JSON.stringify({ error: 'Method Not Allowed' }), {
            status: 405,
            headers: { 'Content-Type': 'application/json' }
        });
    }

    try {
        const review = await req.json();
        
        // Validate review data
        if (!review.productId || !review.userName || !review.rating || !review.comment) {
            return new Response(JSON.stringify({ error: 'Missing required fields' }), {
                status: 400,
                headers: { 'Content-Type': 'application/json' }
            });
        }
        
        // Validate rating is between 1-5
        if (review.rating < 1 || review.rating > 5) {
            return new Response(JSON.stringify({ error: 'Rating must be between 1 and 5' }), {
                status: 400,
                headers: { 'Content-Type': 'application/json' }
            });
        }
        
        const store = getStore('reviews');
        
        // Get existing reviews
        const existingData = await store.get(`product-${review.productId}`);
        const reviews = existingData ? JSON.parse(existingData) : [];
        
        // Add new review
        const newReview = {
            ...review,
            date: new Date().toISOString()
        };
        reviews.push(newReview);
        
        // Save back to store
        await store.set(`product-${review.productId}`, JSON.stringify(reviews));
        
        // Update global recent reviews
        const recentData = await store.get('global-recent');
        let recentReviews = recentData ? JSON.parse(recentData) : [];
        
        recentReviews.unshift(newReview);
        if (recentReviews.length > 20) {
            recentReviews = recentReviews.slice(0, 20);
        }
        await store.set('global-recent', JSON.stringify(recentReviews));
        
        return new Response(JSON.stringify({ 
            success: true,
            message: 'Review stored successfully',
            review: newReview
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error) {
        console.error('Error storing review:', error);
        return new Response(JSON.stringify({ 
            error: 'Failed to store review',
            details: error.message
        }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }
};

export const config = {
    path: '/api/store-reviews'
};
