import { getStore } from '@netlify/blobs';
import { verifyAuth } from './lib/auth.mjs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    // Authenticate Admin
    await verifyAuth(req);

    const { userId, isAdmin } = await req.json();

    if (!userId) {
      return new Response(JSON.stringify({ error: 'User ID is required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const accountsStore = getStore('user-accounts');
    // We need to find the user by ID. 
    // Since blob keys are emails, we might need to search or just assume userId IS email if frontend sends it.
    // In admin-functions.js, `toggleAdminStatus` passes `user.id`. 
    // In `get-users.mjs`, `user.id` was set to `userData.email`.
    // So `userId` here IS the email.
    
    const email = userId; 
    const accountDataStr = await accountsStore.get(email);

    if (!accountDataStr) {
      return new Response(JSON.stringify({ error: 'User not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const accountData = JSON.parse(accountDataStr);
    
    // Prevent modifying the super-admin
    if (accountData.email === 'killerskull913@gmail.com') {
         return new Response(JSON.stringify({ error: 'Cannot modify the main admin' }), {
            status: 403,
            headers: { 'Content-Type': 'application/json' }
        });
    }

    accountData.isAdmin = isAdmin;
    
    // Update legacy role array for compatibility
    if (isAdmin) {
        accountData.roles = [...(accountData.roles || []).filter(r => r !== 'admin'), 'admin'];
    } else {
        accountData.roles = (accountData.roles || []).filter(r => r !== 'admin');
    }

    await accountsStore.set(email, JSON.stringify(accountData), {
        metadata: { 
            userId: accountData.userId, 
            email, 
            verified: String(accountData.verified) 
        }
    });

    return new Response(JSON.stringify({ 
      success: true, 
      message: `User ${isAdmin ? 'promoted to' : 'demoted from'} admin`
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error setting admin status:', error);
    return new Response(JSON.stringify({ 
      error: error.message || 'Failed to update user' 
    }), {
      status: error.message.includes('Unauthorized') ? 401 : 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

export const config = {
  path: '/api/admin/set-admin-status'
};
