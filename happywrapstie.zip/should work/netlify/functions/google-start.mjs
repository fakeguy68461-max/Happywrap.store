export default async (req, context) => {
  // 1️⃣ Get the Google client ID from environment variables
  const googleClientId = process.env.GOOGLE_CLIENT_ID;

  if (!googleClientId) {
    return new Response('Google client not found', { status: 500 });
  }

  // 2️⃣ Construct redirect URI for callback
  const url = new URL(req.url);
  const redirectUri = `${url.origin}/api/google-callback`;

  // 3️⃣ Define the OAuth scope (basic profile + email)
  const scope = 'https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile';

  // 4️⃣ Build the Google OAuth URL
  const googleAuthUrl =
    'https://accounts.google.com/o/oauth2/v2/auth?' +
    `client_id=${encodeURIComponent(googleClientId)}` +
    `&redirect_uri=${encodeURIComponent(redirectUri)}` +
    `&response_type=code` +
    `&scope=${encodeURIComponent(scope)}` +
    `&access_type=offline` +
    `&prompt=select_account`;

  // 5️⃣ Redirect the user directly to Google OAuth page
  return new Response(null, {
    status: 302,
    headers: {
      Location: googleAuthUrl
    }
  });
};

// 6️⃣ Netlify Function configuration
export const config = {
  path: '/api/google-start'
};