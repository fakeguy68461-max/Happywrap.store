# WhatsApp OTP Verification Testing

Since this project does not integrate with a real WhatsApp API provider (like Twilio or Meta Business API) for sending messages, the OTP flow is simulated for testing purposes.

## How to Test

1. **Checkout**: Proceed to checkout and place an order.
2. **Select Method**: Choose "WhatsApp Verification".
3. **Enter Number**: Enter a valid phone number and click "Send Verification Code".
4. **Get OTP**: 
   - Open your browser's Developer Console (F12 or Right Click -> Inspect -> Console).
   - You will see a log message: `✅ TEST MODE - GENERATED OTP: 123456`.
   - An alert might also appear with the code.
5. **Verify**: Enter this 6-digit code on the verification page.
6. **Success**: You should be redirected to the Order Confirmation page.

## Security Note

For production, the code that exposes the OTP in the API response and console logs **must be removed**. 
Currently, it is enabled to allow you to verify the full flow without real SMS delivery.
Security headers (`X-Content-Type-Options`, `X-Frame-Options`, `X-XSS-Protection`) have been added to the API responses to improve security.
