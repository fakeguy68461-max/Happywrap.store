document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const orderId = urlParams.get('orderId');
    const total = urlParams.get('total');

    if (!orderId) {
        alert('Invalid order information');
        window.location.href = 'checkout.html';
        return;
    }

    const orderNumberEl = document.getElementById('orderNumber');
    const orderTotalEl = document.getElementById('orderTotal');
    
    if (orderNumberEl) orderNumberEl.textContent = orderId;
    if (orderTotalEl) orderTotalEl.textContent = total || '$0.00';

    const whatsappForm = document.getElementById('whatsappForm');
    const phoneInput = document.getElementById('phoneInput');
    const countryCode = document.getElementById('countryCode');
    const phoneError = document.getElementById('phoneError');
    const submitBtn = document.getElementById('submitBtn');
    const loadingState = document.getElementById('loadingState');

    // Validate phone on input
    if (phoneInput) {
        phoneInput.addEventListener('input', () => {
            // Remove non-numeric characters
            phoneInput.value = phoneInput.value.replace(/\D/g, '');

            if (phoneInput.validity.valid) {
                phoneInput.classList.remove('error');
                if (phoneError) phoneError.style.display = 'none';
            }
        });
    }

    if (whatsappForm) {
        whatsappForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            const phone = phoneInput.value.trim();
            const code = countryCode.value;

            // Validate phone
            if (!phone || !phoneInput.validity.valid) {
                phoneInput.classList.add('error');
                if (phoneError) phoneError.style.display = 'block';
                return;
            }

            const fullPhoneNumber = `${code}${phone}`;

            // Get order data from sessionStorage
            const orderDataStr = sessionStorage.getItem('verificationOrderData');
            if (!orderDataStr) {
                alert('Order data not found. Please return to checkout.');
                window.location.href = 'checkout.html';
                return;
            }

            const orderData = JSON.parse(orderDataStr);

            // Show loading state
            submitBtn.disabled = true;
            loadingState.style.display = 'block';

            try {
                // Save WhatsApp number to database
                const response = await fetch('/api/save-whatsapp-verification', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        orderId: orderId,
                        phoneNumber: fullPhoneNumber,
                        orderData: {
                            items: orderData.items,
                            total: parseFloat(total) || orderData.total,
                            shippingInfo: orderData.shippingInfo,
                            boxes: orderData.boxes, // Include boxes
                            paymentMethod: orderData.paymentMethod // Include payment method
                        }
                    })
                });

                const result = await response.json();

                if (response.ok && result.success) {
                    // Store phone number for verification step
                    sessionStorage.setItem('verificationPhone', fullPhoneNumber);
                    
                    // For testing purposes: Log the OTP if returned
                    if (result.otp) {
                        console.log('✅ TEST MODE - GENERATED OTP:', result.otp);
                        alert('TEST MODE: Your OTP is ' + result.otp); // Also show alert for easier testing
                    }

                    // Redirect to code verification page
                    window.location.href = `verification-code.html?orderId=${orderId}`;
                } else {
                    throw new Error(result.error || 'Failed to save phone number');
                }
            } catch (error) {
                console.error('Error saving WhatsApp number:', error);
                alert('Failed to save phone number. Please try again or use email verification.');
                submitBtn.disabled = false;
                loadingState.style.display = 'none';
            }
        });
    }
});
