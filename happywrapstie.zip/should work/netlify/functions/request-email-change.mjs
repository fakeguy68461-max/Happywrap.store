import { emailChangeVerificationTemplate } from '../email-templates/email-change-verification.js';
import { getStore } from '@netlify/blobs';
import { sendEmailSMTP } from './lib/smtp-mailer.mjs';
import { getSiteUrl } from './lib/getUrl.mjs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { userId, userName, oldEmail, newEmail } = await req.json();

    if (!userId || !oldEmail || !newEmail) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    if (oldEmail === newEmail) {
      return new Response(JSON.stringify({ error: 'New email must be different from current email' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Check if user account exists and is verified
    const accountsStore = getStore('user-accounts');
    const accountDataStr = await accountsStore.get(oldEmail);

    if (!accountDataStr) {
      return new Response(JSON.stringify({ error: 'Account not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const accountData = JSON.parse(accountDataStr);

    // Only allow email change for verified accounts
    if (!accountData.verified) {
      return new Response(JSON.stringify({
        error: 'You must verify your current email address before changing it. Please check your inbox for the verification link.',
        needsVerification: true
      }), {
        status: 403,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Check if new email is already in use
    const existingAccount = await accountsStore.get(newEmail);
    if (existingAccount) {
      return new Response(JSON.stringify({ error: 'This email address is already in use by another account' }), {
        status: 409,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const verificationToken = generateToken();
    const expiresAt = Date.now() + (24 * 60 * 60 * 1000);

    const emailChangeStore = getStore('email-changes');
    await emailChangeStore.setJSON(verificationToken, {
      userId,
      oldEmail,
      newEmail,
      expiresAt,
      createdAt: Date.now()
    });

    const siteUrl = getSiteUrl();
    const verificationLink = `${siteUrl}/api/verify-email-change?token=${verificationToken}`;

    const emailSubject = 'HappyWrap - Verify Your Email Change';
    const emailBody = emailChangeVerificationTemplate({
      USER_NAME: userName || 'User',
      OLD_EMAIL: oldEmail,
      NEW_EMAIL: newEmail,
      VERIFICATION_LINK: verificationLink,
      EXPIRATION_TIME: '24 hours'
    });

    const emailSent = await sendEmailSMTP(newEmail, emailSubject, emailBody);
    
    if (!emailSent) {
      console.error('Failed to send email change verification to:', newEmail);
      console.error('Please check SMTP credentials and configuration');
      return new Response(JSON.stringify({ 
        error: 'Failed to send verification email. Please try again or contact support.',
        details: 'Email service configuration error'
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }
    
    console.log('Email change verification sent to:', newEmail);
    console.log('Verification token:', verificationToken);
    console.log('Email sent status:', emailSent);

    return new Response(JSON.stringify({ 
      success: true, 
      message: 'Verification email sent to new email address. Please note that emails may take 3-4 minutes to arrive. Check your spam folder if you don\'t see it in your inbox.'
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error requesting email change:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to process email change request',
      details: error.message 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

function generateToken() {
  return Array.from({ length: 32 }, () => 
    Math.floor(Math.random() * 16).toString(16)
  ).join('');
}

export const config = {
  path: '/api/request-email-change'
};
