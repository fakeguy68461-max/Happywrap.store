import { getStore } from '@netlify/blobs';
import bcrypt from 'bcryptjs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { token, newPassword } = await req.json();

    if (!token || !newPassword) {
      return new Response(JSON.stringify({ error: 'Token and new password are required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    if (newPassword.length < 6) {
      return new Response(JSON.stringify({ error: 'Password must be at least 6 characters long' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Get reset token data
    const passwordResetStore = getStore('password-resets');
    const resetData = await passwordResetStore.get(token, { type: 'json' });

    if (!resetData) {
      return new Response(JSON.stringify({ error: 'Invalid or expired reset token' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Check if token has expired
    if (Date.now() > resetData.expiresAt) {
      await passwordResetStore.delete(token);
      return new Response(JSON.stringify({ error: 'This password reset link has expired. Please request a new one.' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Check if token has already been used
    if (resetData.used) {
      return new Response(JSON.stringify({ error: 'This password reset link has already been used.' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Get user account
    const accountsStore = getStore('user-accounts');
    const accountDataStr = await accountsStore.get(resetData.email);

    if (!accountDataStr) {
      return new Response(JSON.stringify({ error: 'Account not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const accountData = JSON.parse(accountDataStr);

    // Hash the new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // Update account with new password
    accountData.hashedPassword = hashedPassword;
    accountData.passwordChangedAt = new Date().toISOString();

    // Save updated account
    await accountsStore.set(resetData.email, JSON.stringify(accountData), {
      metadata: { userId: accountData.userId, email: resetData.email, verified: accountData.verified ? 'true' : 'false' }
    });

    // Mark token as used
    resetData.used = true;
    resetData.usedAt = Date.now();
    await passwordResetStore.setJSON(token, resetData);

    console.log('Password reset successful for:', resetData.email);

    return new Response(JSON.stringify({
      success: true,
      message: 'Password has been reset successfully. You can now log in with your new password.'
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error resetting password:', error);
    return new Response(JSON.stringify({
      error: 'Failed to reset password',
      details: error.message
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

export const config = {
  path: '/api/reset-password'
};
