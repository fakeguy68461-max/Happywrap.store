import { getStore } from '@netlify/blobs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method Not Allowed' }), { status: 405 });
  }

  try {
    const { orderId, rating, comment } = await req.json();

    if (!orderId || !rating) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), { status: 400 });
    }

    // 1. Get original order to verify it exists
    const ordersStore = getStore('confirmed-orders');
    const orderData = await ordersStore.get(orderId, { type: 'json' });

    if (!orderData) {
      return new Response(JSON.stringify({ error: 'Order not found' }), { status: 404 });
    }

    // Ensure order is arrived
    if (orderData.status !== 'arrived' && orderData.status !== 'Arrived') {
        return new Response(JSON.stringify({ error: 'Feedback can only be submitted for arrived orders' }), { status: 403 });
    }

    // 2. Store in completed-orders
    const completedStore = getStore('completed-orders');
    
    const feedbackData = {
        orderId,
        rating,
        comment,
        submittedAt: new Date().toISOString(),
        customerName: orderData.name || 'Customer',
        orderData: orderData
    };

    await completedStore.setJSON(orderId, feedbackData, {
        metadata: {
            orderId,
            rating,
            submittedAt: feedbackData.submittedAt
        }
    });

    // 3. Update status in confirmed-orders (optional, but good for tracking)
    // We don't delete from confirmed-orders because Admin might still want to see history?
    // User request says "saved in orders completed section which is a new section".
    // It doesn't explicitly say remove from "Orders".
    // But usually completed orders move out of active.
    // I'll keep it simple: Just add to completed-orders.

    return new Response(JSON.stringify({ success: true }), { status: 200 });

  } catch (error) {
    console.error('Error submitting feedback:', error);
    return new Response(JSON.stringify({ error: 'Internal Server Error' }), { status: 500 });
  }
};

export const config = {
  path: '/api/submit-feedback'
};