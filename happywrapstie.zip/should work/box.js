// Shopping Box Page JavaScript

// Display box items
function displayBox() {
    // Assuming 'cart' object is available globally from main.js or similar
    // We keep the internal data structure as 'cart' to avoid breaking data persistence
    const cartItems = cart.getItems();
    const emptyBox = document.getElementById('emptyBox');
    const boxWithItems = document.getElementById('boxWithItems');
    
    if (cartItems.length === 0) {
        emptyBox.style.display = 'block';
        boxWithItems.style.display = 'none';
        return;
    }
    
    emptyBox.style.display = 'none';
    boxWithItems.style.display = 'block';
    
    const boxItemsList = document.getElementById('boxItemsList');
    boxItemsList.innerHTML = cartItems.map(item => `
        <div class="cart-item" data-product-id="${item.id}">
            <img src="${item.image}" alt="${item.name}" class="cart-item-image"
                 onerror="this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'100\' height=\'100\'%3E%3Crect width=\'100\' height=\'100\' fill=\'%23f3f4f6\'/%3E%3Ctext x=\'50%25\' y=\'50%25\' dominant-baseline=\'middle\' text-anchor=\'middle\' font-family=\'sans-serif\' font-size=\'12\' fill=\'%236b7280\'%3ENo Image%3C/text%3E%3C/svg%3E'">
            <div class="cart-item-details">
                <h3 class="cart-item-name">${item.name}</h3>
                <p class="cart-item-price">${formatPrice(item.price)}</p>
                ${item.options && item.options.colors ? `<p class="cart-item-colors" style="font-size: 0.85em; color: #666; margin-top: 4px;">Colors: ${item.options.colors.join(', ')}</p>` : ''}
            </div>
            <div class="quantity-controls">
                <button class="quantity-btn" onclick="updateItemQuantity('${item.id}', ${item.quantity - 1})">-</button>
                <span class="quantity-value">${item.quantity}</span>
                <button class="quantity-btn" onclick="updateItemQuantity('${item.id}', ${item.quantity + 1})">+</button>
            </div>
            <div style="text-align: right;">
                <p style="font-weight: 600; margin-bottom: 10px;">${formatPrice(item.price * item.quantity)}</p>
                <button class="remove-btn" onclick="removeItem('${item.id}')">Remove</button>
            </div>
        </div>
    `).join('');
    
    updateBoxSummary();
}

// Update item quantity
window.updateItemQuantity = function(productId, newQuantity) {
    if (newQuantity < 1) {
        if (confirm('Remove this item from cart?')) {
            cart.removeItem(productId);
        }
    } else {
        cart.updateQuantity(productId, newQuantity);
    }
    displayBox();
};

// Remove item
window.removeItem = function(productId) {
    if (confirm('Are you sure you want to remove this item?')) {
        cart.removeItem(productId);
        displayBox();
    }
};

// Update box summary
function updateBoxSummary() {
    const subtotal = cart.getSubtotal();
    const shipping = subtotal > 0 ? 5.99 : 0;
    const tax = subtotal * 0.10;
    const total = subtotal + shipping + tax;
    
    document.getElementById('subtotal').textContent = formatPrice(subtotal);
    document.getElementById('shipping').textContent = formatPrice(shipping);
    document.getElementById('tax').textContent = formatPrice(tax);
    document.getElementById('total').textContent = formatPrice(total);
}

// Initialize box page
document.addEventListener('DOMContentLoaded', () => {
    // Check for pending order verification
    const pendingOrderId = localStorage.getItem('pendingOrderId');
    const pendingOrderToken = localStorage.getItem('pendingOrderToken');

    if (pendingOrderId && pendingOrderToken) {
        const notificationDiv = document.createElement('div');
        notificationDiv.id = 'pendingOrderNotification';
        notificationDiv.style.cssText = 'background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px auto; max-width: 1200px; border-radius: 8px;';
        notificationDiv.innerHTML = `
            <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 15px;">
                <div>
                    <p style="margin: 0; color: #92400e; font-size: 14px; font-weight: 600;">
                        Order #${pendingOrderId} is awaiting verification
                    </p>
                    <p style="margin: 5px 0 0; color: #92400e; font-size: 13px;">
                        Please check your email and click the verification link to complete your order.
                    </p>
                </div>
                <div style="display: flex; gap: 10px;">
                    <a href="order-confirm.html?token=${pendingOrderToken}" class="btn btn-primary" style="padding: 8px 16px; font-size: 13px; white-space: nowrap;">
                        Verify Now
                    </a>
                    <button onclick="document.getElementById('pendingOrderNotification').remove();" class="btn btn-outline" style="padding: 8px 16px; font-size: 13px;">
                        Dismiss
                    </button>
                </div>
            </div>
        `;

        const cartContainer = document.querySelector('.cart-container .container');
        if (cartContainer) {
            cartContainer.insertBefore(notificationDiv, cartContainer.firstChild);
        }
    }

    displayBox();
});
