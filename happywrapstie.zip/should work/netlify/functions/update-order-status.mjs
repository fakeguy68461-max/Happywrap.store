import { getStore } from '@netlify/blobs';
import { sendEmailSMTP } from './lib/smtp-mailer.mjs';
import { getSiteUrl } from './lib/getUrl.mjs';
import { verifyAuth } from './lib/auth.mjs';
import { processLoyaltyUpdate, revertLoyaltyUpdate } from './lib/loyalty.mjs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method Not Allowed' }), { status: 405 });
  }

  try {
    // 1. Robust Auth Check
    const user = await verifyAuth(req);
    // Double check role just in case verifyAuth changes
    if (!user.app_metadata?.roles?.includes('admin')) {
        return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403 });
    }

    const { orderId, status } = await req.json();

    if (!orderId || !status) {
      return new Response(JSON.stringify({ error: 'Order ID and status are required' }), { status: 400 });
    }

    const store = getStore('confirmed-orders');
    const orderData = await store.get(orderId, { type: 'json' });

    if (!orderData) {
      return new Response(JSON.stringify({ error: 'Order not found' }), { status: 404 });
    }

    // prevent Status Rollback logic if needed, but assuming Admin knows what they are doing.
    // User requested "Ensure no status rollback occurs after successful admin updates".
    // This usually means "don't let the system automatically revert it".
    // Since we are writing to the store here, it persists.

    const oldStatus = orderData.status;
    orderData.status = status;

    // Update metadata for faster listing
    await store.setJSON(orderId, orderData, {
        metadata: {
            email: orderData.email,
            confirmedAt: orderData.confirmedAt || orderData.createdAt,
            status: status
        }
    });

    // Email Notifications
    const siteUrl = getSiteUrl();

    // 1. Payment Confirmed Email
    if (status === 'payment_confirmed' && oldStatus !== 'payment_confirmed') {
        const emailSubject = `Payment Confirmed - Order #${orderId}`;
        const emailBody = `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2 style="color: #10b981;">Payment Confirmed! ✅</h2>
                <p>Hi ${orderData.name || 'Customer'},</p>
                <p>Thank you for your payment. Your order #${orderId} has been confirmed and is now being processed.</p>
                <p>We will notify you when it's on the way.</p>
                <p>Thank you for choosing HappyWrap!</p>
            </div>
        `;
        
        try {
            await sendEmailSMTP(orderData.email, emailSubject, emailBody);
            console.log(`Payment confirmed email sent to ${orderData.email}`);
        } catch (emailErr) {
            console.error('Failed to send payment confirmed email:', emailErr);
        }
    }

    // 2. Order Arrived Email
    if ((status === 'arrived' || status === 'Arrived') && oldStatus !== 'arrived' && oldStatus !== 'Arrived') {
        
        // --- Loyalty System Update ---
        try {
            const userStore = getStore('user-accounts');
            // Try to find a user with this email
            const userString = await userStore.get(orderData.email);
            
            let user;
            if (userString) {
                user = JSON.parse(userString);
            } else {
                // Create stub user for Guest/OAuth loyalty tracking
                console.log(`Creating new loyalty profile for ${orderData.email}`);
                user = { 
                    email: orderData.email,
                    userId: `user_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
                    createdAt: new Date().toISOString(),
                    // Loyalty fields will be initialized by processLoyaltyUpdate
                };
            }

            const updatedUser = processLoyaltyUpdate(user, orderId);
            
            if (updatedUser) {
                await userStore.set(orderData.email, JSON.stringify(updatedUser), {
                    metadata: { 
                        userId: updatedUser.userId, 
                        email: updatedUser.email, 
                        verified: updatedUser.verified ? 'true' : 'false' 
                    }
                });
                console.log(`Loyalty updated for user ${orderData.email}. Total orders: ${updatedUser.total_completed_orders}`);
            } else {
                console.log(`Loyalty update skipped for user ${orderData.email} (already processed or no change).`);
            }
        } catch (loyaltyErr) {
            console.error('Failed to update loyalty stats:', loyaltyErr);
            // Don't fail the request, just log it
        }
        // -----------------------------

        const feedbackLink = `${siteUrl}/feedback.html?orderId=${orderId}`;
        const emailSubject = `Your Order #${orderId} has Arrived! - HappyWrap`;
        const emailBody = `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2 style="color: #10b981;">Your Order has Arrived! 🎁</h2>
                <p>Hi ${orderData.name || 'Customer'},</p>
                <p>We hope you are enjoying your purchase. Your order #${orderId} has been marked as arrived.</p>
                
                <p>We would love to hear your feedback!</p>
                
                <div style="text-align: center; margin: 30px 0;">
                    <a href="${feedbackLink}" style="background: #2563eb; color: white; padding: 15px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; font-size: 16px;">Leave a Review</a>
                </div>
                
                <p style="margin-top: 20px; color: #666; font-size: 14px;">If you haven't received your order yet, please reply to this email.</p>
            </div>
        `;
        
        try {
            await sendEmailSMTP(orderData.email, emailSubject, emailBody);
            console.log(`Arrived email sent to ${orderData.email}`);
        } catch (emailErr) {
            console.error('Failed to send arrived email:', emailErr);
        }
    }

    // 3. Order Refunded/Cancelled Logic
    if (['cancelled', 'refunded', 'reversed'].includes(status.toLowerCase()) && oldStatus !== status) {
        try {
            const userStore = getStore('user-accounts');
            const userString = await userStore.get(orderData.email);
            
            if (userString) {
                let user = JSON.parse(userString);
                const updatedUser = revertLoyaltyUpdate(user, orderId);
                
                if (updatedUser) {
                    await userStore.set(orderData.email, JSON.stringify(updatedUser), {
                        metadata: { 
                            userId: updatedUser.userId, 
                            email: updatedUser.email, 
                            verified: updatedUser.verified ? 'true' : 'false' 
                        }
                    });
                    console.log(`Loyalty REVERTED for user ${orderData.email}. Total orders: ${updatedUser.total_completed_orders}`);
                } else {
                    console.log(`Loyalty revert skipped for user ${orderData.email} (order not found in history).`);
                }
            }
        } catch (loyaltyErr) {
            console.error('Failed to revert loyalty stats:', loyaltyErr);
        }
    }

    return new Response(JSON.stringify({ success: true, status: status }), { status: 200 });

  } catch (error) {
    console.error('Error updating order status:', error);
    const status = error.message.includes('Unauthorized') || error.message.includes('Forbidden') ? 401 : 500;
    return new Response(JSON.stringify({ error: error.message }), { status: status });
  }
};

export const config = {
  path: '/api/admin/update-order-status'
};