import { getStore } from '@netlify/blobs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { token } = await req.json();

    if (!token) {
      return new Response(JSON.stringify({ error: 'Token is required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const store = getStore('email-verifications');
    const verificationDataString = await store.get(token);

    if (!verificationDataString) {
      return new Response(JSON.stringify({ 
        error: 'Invalid or expired verification link',
        success: false 
      }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const verificationData = JSON.parse(verificationDataString);

    // ✅ NEW: Check if token is expired (24 hours)
    const tokenAge = Date.now() - new Date(verificationData.createdAt).getTime();
    const maxAge = 24 * 60 * 60 * 1000; // 24 hours
    
    if (tokenAge > maxAge) {
      console.log(`Verification token expired for ${verificationData.email}`);
      return new Response(JSON.stringify({ 
        error: 'Verification link has expired. Please request a new one.',
        success: false,
        expired: true
      }), {
        status: 410,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    if (verificationData.verified) {
      return new Response(JSON.stringify({ 
        error: 'Email has already been verified',
        success: false,
        alreadyVerified: true
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const verifiedData = {
      ...verificationData,
      verified: true,
      verifiedAt: new Date().toISOString()
    };

    // Update verification token store
    await store.set(token, JSON.stringify(verifiedData), {
      metadata: { 
        userId: verificationData.userId, 
        email: verificationData.email,
        verified: true 
      }
    });

    // Store in verified-emails for quick lookup
    const verifiedStore = getStore('verified-emails');
    await verifiedStore.set(verificationData.email, JSON.stringify(verifiedData), {
      metadata: { 
        userId: verificationData.userId,
        verifiedAt: verifiedData.verifiedAt
      }
    });

    // Update user-accounts store (primary store used by login)
    try {
      const accountsStore = getStore('user-accounts');
      const accountDataStr = await accountsStore.get(verificationData.email);

      if (accountDataStr) {
        const accountData = JSON.parse(accountDataStr);
        accountData.verified = true;
        accountData.verifiedAt = verifiedData.verifiedAt;

        await accountsStore.set(verificationData.email, JSON.stringify(accountData), {
          metadata: {
            userId: accountData.userId,
            email: verificationData.email,
            verified: 'true'
          }
        });

        console.log(`✅ User account ${verificationData.email} marked as verified in user-accounts store`);
      } else {
        console.warn(`⚠️ Account ${verificationData.email} not found in user-accounts store`);
      }
    } catch (accountUpdateError) {
      console.error('Error updating user-accounts verification status:', accountUpdateError);
    }

    // Also update users store for backwards compatibility
    try {
      const usersStore = getStore('users');
      const userDataString = await usersStore.get(verificationData.userId);

      if (userDataString) {
        const userData = JSON.parse(userDataString);
        userData.emailVerified = true;
        userData.verifiedAt = verifiedData.verifiedAt;
        userData.accountStatus = 'active';

        await usersStore.set(verificationData.userId, JSON.stringify(userData), {
          metadata: {
            email: userData.email,
            emailVerified: true
          }
        });

        console.log(`✅ User account ${verificationData.userId} activated and marked as verified in users store`);
      }
    } catch (userUpdateError) {
      console.error('Error updating users store verification status:', userUpdateError);
    }

    console.log(`✅ Email ${verificationData.email} verified successfully for user ${verificationData.userId}`);

    return new Response(JSON.stringify({ 
      success: true,
      message: 'Email verified successfully! You can now log in.',
      email: verificationData.email,
      userId: verificationData.userId
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('❌ Error verifying email:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to verify email',
      details: error.message,
      success: false
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

export const config = {
  path: '/api/verify-email'
};