import { getStore } from '@netlify/blobs';
import { sendEmailSMTP } from './lib/smtp-mailer.mjs';
import { emailVerificationTemplate } from '../email-templates/index.js';
import { getSiteUrl } from './lib/getUrl.mjs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { email } = await req.json();

    if (!email) {
      return new Response(JSON.stringify({ error: 'Email is required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const accountsStore = getStore('user-accounts');
    const accountDataStr = await accountsStore.get(email);

    if (!accountDataStr) {
      return new Response(JSON.stringify({
        error: 'No account found with this email address'
      }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const accountData = JSON.parse(accountDataStr);

    if (accountData.verified) {
      return new Response(JSON.stringify({
        error: 'This account is already verified. Please log in.',
        alreadyVerified: true
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Generate new verification token
    const verificationToken = generateToken();
    accountData.verificationToken = verificationToken;

    // Update account with new token
    await accountsStore.set(email, JSON.stringify(accountData), {
      metadata: { userId: accountData.userId, email, verified: 'false' }
    });

    // Send verification email
    const siteUrl = getSiteUrl();
    const verificationLink = `${siteUrl}/verify-account.html?token=${verificationToken}&email=${encodeURIComponent(email)}`;

    const emailSubject = 'Verify Your Email - HappyWrap';
    const emailBody = emailVerificationTemplate({
      USER_NAME: `${accountData.firstName} ${accountData.lastName}`,
      USER_EMAIL: email,
      VERIFICATION_LINK: verificationLink,
      EXPIRATION_TIME: '24 hours'
    });

    const emailSent = await sendEmailSMTP(email, emailSubject, emailBody);

    if (!emailSent) {
      console.error('Failed to send verification email to:', email);
      return new Response(JSON.stringify({
        error: 'Failed to send verification email. Please try again later.'
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    console.log('Verification email resent to:', email);

    return new Response(JSON.stringify({
      success: true,
      message: 'Verification email sent. Please check your inbox.'
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error resending verification email:', error);
    return new Response(JSON.stringify({
      error: 'Failed to resend verification email',
      details: error.message
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

function generateToken() {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}`;
}

export const config = {
  path: '/api/resend-account-verification'
};
