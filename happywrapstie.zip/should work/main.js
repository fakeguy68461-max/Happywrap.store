// Main JavaScript - Core Functionality

// Update navigation based on auth state
function updateNavigation() {
    const customUser = localStorage.getItem('custom_user_data');
    const netlifyUser = (typeof netlifyIdentity !== 'undefined') ? netlifyIdentity.currentUser() : null;
    const navAuthLink = document.getElementById('navAuthLink');
    
    if (navAuthLink) {
        if (customUser || netlifyUser) {
            navAuthLink.textContent = 'Account';
            navAuthLink.href = 'account.html';
        } else {
            navAuthLink.textContent = 'Login';
            navAuthLink.href = 'login.html';
        }
    }
}

// Box Management
class Cart {
    constructor() {
        this.items = this.loadCart();
    }

    loadCart() {
        const saved = localStorage.getItem('happywrap_cart');
        return saved ? JSON.parse(saved) : [];
    }

    saveCart() {
        localStorage.setItem('happywrap_cart', JSON.stringify(this.items));
        this.updateBoxCount();
    }

    addItem(product, quantity = 1, options = null) {
        // Create a unique key for comparison (id + options)
        const compareOptions = (itemOptions, newOptions) => {
            if (!itemOptions && !newOptions) return true;
            if (!itemOptions || !newOptions) return false;
            return JSON.stringify(itemOptions) === JSON.stringify(newOptions);
        };

        const existingItem = this.items.find(item => 
            item.id === product.id && compareOptions(item.options, options)
        );
        
        if (existingItem) {
            existingItem.quantity += quantity;
        } else {
            this.items.push({
                id: product.id,
                name: product.name,
                price: product.price,
                image: product.image,
                category: product.category,
                quantity: quantity,
                options: options
            });
        }
        
        this.saveCart();
        return true;
    }

    removeItem(productId) {
        this.items = this.items.filter(item => item.id !== productId);
        this.saveCart();
    }

    updateQuantity(productId, quantity) {
        const item = this.items.find(item => item.id === productId);
        if (item) {
            item.quantity = Math.max(1, quantity);
            this.saveCart();
        }
    }

    getItems() {
        return this.items;
    }

    getTotalItems() {
        return this.items.reduce((total, item) => total + item.quantity, 0);
    }

    getSubtotal() {
        return this.items.reduce((total, item) => total + (item.price * item.quantity), 0);
    }

    clearCart() {
        this.items = [];
        this.saveCart();
    }

    updateBoxCount() {
        const boxCountElements = document.querySelectorAll('.box-count');
        const count = this.getTotalItems();
        boxCountElements.forEach(el => {
            el.textContent = count;
            el.style.display = count > 0 ? 'inline-block' : 'none';
        });
    }
}

// Wishlist Management
class Wishlist {
    constructor() {
        this.items = this.loadWishlist();
    }

    loadWishlist() {
        const customUser = localStorage.getItem('custom_user_data');
        if (!customUser) return [];
        
        const userData = JSON.parse(customUser);
        const userId = userData.id || userData.userId || userData.email;
        const saved = localStorage.getItem(`happywrap_wishlist_${userId}`);
        return saved ? JSON.parse(saved) : [];
    }

    saveWishlist() {
        const customUser = localStorage.getItem('custom_user_data');
        if (!customUser) return;
        
        const userData = JSON.parse(customUser);
        const userId = userData.id || userData.userId || userData.email;
        localStorage.setItem(`happywrap_wishlist_${userId}`, JSON.stringify(this.items));
    }

    addItem(product) {
        const customUser = localStorage.getItem('custom_user_data');
        if (!customUser) {
            showNotification(
                'Login Required',
                'Please login to add items to wishlist',
                'warning'
            );
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 2000);
            return false;
        }

        if (!this.items.find(item => item.id === product.id)) {
            this.items.push(product);
            this.saveWishlist();
        }
        return true;
    }

    removeItem(productId) {
        this.items = this.items.filter(item => item.id !== productId);
        this.saveWishlist();
    }

    isInWishlist(productId) {
        return this.items.some(item => item.id === productId);
    }

    getItems() {
        return this.items;
    }
}

// Initialize cart and wishlist
const cart = new Cart();
const wishlist = new Wishlist();

// Update cart count on page load
document.addEventListener('DOMContentLoaded', () => {
    cart.updateBoxCount();
    updateNavigation();
});

// Utility Functions
function formatPrice(price) {
    return `PKR ${price.toFixed(2)}`;
}

function generateOrderNumber() {
    return Math.floor(1000000 + Math.random() * 9000000).toString();
}

// Check if user is authenticated - uses global auth state when available
function isAuthenticated() {
    // First check global auth state if available
    if (typeof window.authStatus !== 'undefined' && window.authStatus !== 'loading') {
        return window.authStatus === 'authenticated';
    }
    // Fallback to direct check
    const customUser = localStorage.getItem('custom_user_data');
    const netlifyUser = (typeof netlifyIdentity !== 'undefined') ? netlifyIdentity.currentUser() : null;
    return customUser !== null || netlifyUser !== null;
}

// Wait for auth resolution before requiring auth
async function requireAuth(callback) {
    // Wait for auth to resolve if available
    if (typeof window.waitForAuthResolution === 'function') {
        const authStatus = await window.waitForAuthResolution();
        if (authStatus !== 'authenticated') {
            showNotification(
                'Login Required',
                'Please login to continue',
                'warning'
            );
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 2000);
            return false;
        }
        if (callback) callback();
        return true;
    }

    // Fallback to synchronous check
    if (!isAuthenticated()) {
        showNotification(
            'Login Required',
            'Please login to continue',
            'warning'
        );
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 2000);
        return false;
    }
    if (callback) callback();
    return true;
}

// Order Management
class OrderHistory {
    constructor() {
        this.orders = this.loadOrders();
    }

    loadOrders() {
        const customUser = localStorage.getItem('custom_user_data');
        if (!customUser) return [];
        
        const userData = JSON.parse(customUser);
        const userId = userData.id || userData.userId || userData.email;
        const saved = localStorage.getItem(`happywrap_orders_${userId}`);
        return saved ? JSON.parse(saved) : [];
    }

    saveOrders() {
        const customUser = localStorage.getItem('custom_user_data');
        if (!customUser) return;
        
        const userData = JSON.parse(customUser);
        const userId = userData.id || userData.userId || userData.email;
        localStorage.setItem(`happywrap_orders_${userId}`, JSON.stringify(this.orders));
    }

    addOrder(orderData) {
        const order = {
            id: generateOrderNumber(),
            date: new Date().toISOString(),
            items: orderData.items,
            total: orderData.total,
            shippingInfo: orderData.shippingInfo,
            paymentMethod: orderData.paymentMethod, // Include payment method
            status: 'Processing'
        };

        this.orders.unshift(order);
        this.saveOrders();
        return order;
    }

    getOrders() {
        return this.orders;
    }

    getOrderById(orderId) {
        return this.orders.find(order => order.id === orderId);
    }
}

const orderHistory = new OrderHistory();

// Export for use in other files
window.cart = cart;
window.wishlist = wishlist;
window.orderHistory = orderHistory;
window.formatPrice = formatPrice;
window.isAuthenticated = isAuthenticated;
window.requireAuth = requireAuth;
window.updateNavigation = updateNavigation;

// Night Mode Toggle
function initNightMode() {
    const customUser = localStorage.getItem('custom_user_data');
    if (!customUser) return;
    
    const userData = JSON.parse(customUser);
    const userId = userData.id || userData.userId || userData.email;
    const savedMode = localStorage.getItem(`night_mode_${userId}`);
    if (savedMode === 'dark') {
        document.body.classList.add('dark-mode');
    }
    
    let toggleBtn = document.getElementById('nightModeToggle');
    if (!toggleBtn) {
        toggleBtn = document.createElement('button');
        toggleBtn.id = 'nightModeToggle';
        toggleBtn.className = 'night-mode-toggle show';
        toggleBtn.innerHTML = document.body.classList.contains('dark-mode') ? '☀️' : '🌙';
        toggleBtn.setAttribute('aria-label', 'Toggle night mode');
        toggleBtn.addEventListener('click', toggleNightMode);
        document.body.appendChild(toggleBtn);
    }
}

function toggleNightMode() {
    const customUser = localStorage.getItem('custom_user_data');
    if (!customUser) return;
    
    const userData = JSON.parse(customUser);
    const userId = userData.id || userData.userId || userData.email;
    document.body.classList.toggle('dark-mode');
    const isDark = document.body.classList.contains('dark-mode');
    
    const toggleBtn = document.getElementById('nightModeToggle');
    if (toggleBtn) {
        toggleBtn.innerHTML = isDark ? '☀️' : '🌙';
    }
    
    localStorage.setItem(`night_mode_${userId}`, isDark ? 'dark' : 'light');
    
    showNotification(
        isDark ? 'Dark Mode Enabled' : 'Light Mode Enabled',
        isDark ? 'Easy on the eyes for night browsing' : 'Bright and clear for daytime',
        'success'
    );
}

// Notification System
function showNotification(title, message, type = 'info') {
    const existingToast = document.querySelector('.notification-toast');
    if (existingToast) {
        existingToast.remove();
    }
    
    const toast = document.createElement('div');
    toast.className = `notification-toast ${type}`;
    
    const icons = {
        info: 'ℹ️',
        success: '✅',
        error: '⚠️',
        warning: '⚡'
    };
    
    toast.innerHTML = `
        <div class="notification-icon">${icons[type] || icons.info}</div>
        <div class="notification-content">
            <strong>${title}</strong>
            <p>${message}</p>
        </div>
        <button class="notification-close" onclick="this.parentElement.remove()">×</button>
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => toast.classList.add('show'), 100);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 400);
    }, 5000);
}

function showPersistentNotification(title, message, type = 'info') {
    const existingModal = document.getElementById('persistentNotificationModal');
    if (existingModal) {
        existingModal.remove();
    }
    
    const modal = document.createElement('div');
    modal.id = 'persistentNotificationModal';
    modal.className = 'modal';
    modal.style.display = 'flex';
    
    const icons = {
        info: 'ℹ️',
        success: '✅',
        error: '⚠️',
        warning: '📧'
    };
    
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 500px;">
            <div style="text-align: center; font-size: 60px; margin-bottom: 20px;">${icons[type] || icons.info}</div>
            <h2 style="text-align: center; margin-bottom: 15px;">${title}</h2>
            <p style="text-align: center; color: var(--gray); line-height: 1.6; margin-bottom: 30px;">${message}</p>
            <div style="display: flex; justify-content: center; gap: 10px;">
                <button class="btn btn-primary" onclick="document.getElementById('persistentNotificationModal').remove()">I Understand</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

// Initialize night mode on page load
document.addEventListener('DOMContentLoaded', () => {
    const customUser = localStorage.getItem('custom_user_data');
    if (customUser) {
        initNightMode();
    }
});

window.showNotification = showNotification;
window.showPersistentNotification = showPersistentNotification;
window.toggleNightMode = toggleNightMode;