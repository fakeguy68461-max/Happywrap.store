export const signupWelcomeTemplate = ({
  USER_NAME,
  USER_EMAIL,
  VERIFY_EMAIL_LINK,
  ACCOUNT_DASHBOARD_LINK = 'https://example.com/account.html',
  SHOP_LINK = 'https://example.com/shop.html'
}) => `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome to HappyWrap!</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f5f5f5;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5;">
    <tr>
      <td align="center" style="padding: 40px 20px;">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          
          <tr>
            <td style="padding: 40px 40px 30px; text-align: center; background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%); border-radius: 8px 8px 0 0;">
              <h1 style="margin: 0 0 10px; color: #ffffff; font-size: 32px; font-weight: bold;">Welcome to HappyWrap! 🎉</h1>
              <p style="margin: 0; color: #dbeafe; font-size: 16px;">Your shopping journey starts here</p>
            </td>
          </tr>
          
          <tr>
            <td style="padding: 40px;">
              <h2 style="margin: 0 0 20px; color: #1f2937; font-size: 24px;">Hi ${USER_NAME}!</h2>
              
              <p style="margin: 0 0 20px; color: #4b5563; font-size: 16px; line-height: 1.6;">
                Thank you for joining HappyWrap! We're thrilled to have you as part of our community. Get ready to discover amazing products and enjoy a seamless shopping experience.
              </p>
              
              ${VERIFY_EMAIL_LINK ? `
              <div style="margin: 30px 0; text-align: center;">
                <a href="${VERIFY_EMAIL_LINK}" 
                   style="display: inline-block; background-color: #2563eb; color: #ffffff; padding: 16px 40px; text-decoration: none; border-radius: 6px; font-size: 16px; font-weight: bold;">
                  Verify Your Email
                </a>
              </div>
              <p style="margin: 0 0 30px; color: #6b7280; font-size: 14px; text-align: center; line-height: 1.6;">
                Please verify your email address to unlock all features
              </p>
              ` : ''}
              
              <div style="margin: 40px 0; padding: 30px; background-color: #f0f9ff; border-radius: 8px; border-left: 4px solid #2563eb;">
                <h3 style="margin: 0 0 15px; color: #1f2937; font-size: 18px;">🚀 Getting Started</h3>
                <p style="margin: 0 0 20px; color: #4b5563; font-size: 14px; line-height: 1.6;">
                  Here are some tips to make the most of your HappyWrap account:
                </p>
                
                <div style="margin: 20px 0;">
                  <div style="margin-bottom: 20px;">
                    <h4 style="margin: 0 0 8px; color: #1f2937; font-size: 16px;">
                      🛍️ Browse Our Collections
                    </h4>
                    <p style="margin: 0; color: #6b7280; font-size: 14px; line-height: 1.6;">
                      Explore thousands of products across Electronics, Toys, Home & Kitchen, Sports & Outdoors, and Books & Media.
                    </p>
                  </div>
                  
                  <div style="margin-bottom: 20px;">
                    <h4 style="margin: 0 0 8px; color: #1f2937; font-size: 16px;">
                      ❤️ Create Your Wishlist
                    </h4>
                    <p style="margin: 0; color: #6b7280; font-size: 14px; line-height: 1.6;">
                      Save your favorite items and keep track of products you love. Never lose sight of that perfect item again!
                    </p>
                  </div>
                  
                  <div style="margin-bottom: 20px;">
                    <h4 style="margin: 0 0 8px; color: #1f2937; font-size: 16px;">
                      🎯 Personalize Your Profile
                    </h4>
                    <p style="margin: 0; color: #6b7280; font-size: 14px; line-height: 1.6;">
                      Update your account settings, manage your shipping addresses, and customize your shopping preferences.
                    </p>
                  </div>
                  
                  <div>
                    <h4 style="margin: 0 0 8px; color: #1f2937; font-size: 16px;">
                      📦 Track Your Orders
                    </h4>
                    <p style="margin: 0; color: #6b7280; font-size: 14px; line-height: 1.6;">
                      View your order history, track shipments, and manage returns all from your account dashboard.
                    </p>
                  </div>
                </div>
              </div>
              
              <div style="margin: 30px 0; text-align: center;">
                <a href="${ACCOUNT_DASHBOARD_LINK}" 
                   style="display: inline-block; background-color: #ffffff; color: #2563eb; padding: 14px 30px; text-decoration: none; border: 2px solid #2563eb; border-radius: 6px; font-size: 15px; font-weight: 600; margin-right: 10px;">
                  View Your Account
                </a>
                <a href="${SHOP_LINK}" 
                   style="display: inline-block; background-color: #10b981; color: #ffffff; padding: 14px 30px; text-decoration: none; border-radius: 6px; font-size: 15px; font-weight: 600;">
                  Start Shopping
                </a>
              </div>
              
              <div style="margin-top: 40px; padding-top: 30px; border-top: 1px solid #e5e7eb;">
                <h3 style="margin: 0 0 15px; color: #1f2937; font-size: 18px;">Your Account Details</h3>
                <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f9fafb; border-radius: 6px; padding: 20px;">
                  <tr>
                    <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Email Address:</td>
                    <td style="padding: 8px 0; color: #1f2937; font-size: 14px; font-weight: 600; text-align: right;">${USER_EMAIL}</td>
                  </tr>
                  <tr>
                    <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Account Name:</td>
                    <td style="padding: 8px 0; color: #1f2937; font-size: 14px; font-weight: 600; text-align: right;">${USER_NAME}</td>
                  </tr>
                </table>
              </div>
              
              <div style="margin-top: 40px; padding: 25px; background-color: #fef3c7; border-radius: 8px; text-align: center;">
                <p style="margin: 0 0 10px; color: #92400e; font-size: 16px; font-weight: bold;">
                  🎁 Welcome Gift
                </p>
                <p style="margin: 0; color: #78350f; font-size: 14px; line-height: 1.6;">
                  As a thank you for joining us, enjoy <strong>free shipping</strong> on your first order! No minimum purchase required.
                </p>
              </div>
              
              <div style="margin-top: 30px; padding: 20px; background-color: #f9fafb; border-radius: 6px;">
                <p style="margin: 0 0 10px; color: #1f2937; font-size: 14px; font-weight: 600;">
                  Need Help?
                </p>
                <p style="margin: 0; color: #6b7280; font-size: 13px; line-height: 1.6;">
                  Our support team is here to help! If you have any questions or need assistance, don't hesitate to reach out.
                </p>
              </div>
            </td>
          </tr>
          
          <tr>
            <td style="padding: 30px 40px; background-color: #f9fafb; border-radius: 0 0 8px 8px; text-align: center;">
              <p style="margin: 0 0 15px; color: #6b7280; font-size: 14px;">
                Have questions? We're here to help!<br>
                Contact us at <a href="mailto:support@happywrap.com" style="color: #2563eb; text-decoration: none;">support@happywrap.com</a>
              </p>
              <div style="margin: 20px 0;">
                <a href="#" style="display: inline-block; margin: 0 10px; color: #6b7280; text-decoration: none; font-size: 12px;">Privacy Policy</a>
                <span style="color: #d1d5db;">|</span>
                <a href="#" style="display: inline-block; margin: 0 10px; color: #6b7280; text-decoration: none; font-size: 12px;">Terms of Service</a>
                <span style="color: #d1d5db;">|</span>
                <a href="#" style="display: inline-block; margin: 0 10px; color: #6b7280; text-decoration: none; font-size: 12px;">Help Center</a>
              </div>
              <p style="margin: 15px 0 0; color: #9ca3af; font-size: 12px;">
                © 2025 HappyWrap. All rights reserved.
              </p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
`;
