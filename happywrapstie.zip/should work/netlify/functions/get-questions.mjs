import { getStore } from '@netlify/blobs';

export default async (req, context) => {
    if (req.method !== 'GET') {
        return new Response(JSON.stringify({ error: 'Method Not Allowed' }), {
            status: 405,
            headers: { 'Content-Type': 'application/json' }
        });
    }

    try {
        console.log('Fetching questions (MJS handler)...');
        const url = new URL(req.url);
        const productId = url.searchParams.get('productId');
        
        let questions = [];

        try {
            const store = getStore('questions');
            
            if (!productId) {
                // Get all global questions
                const data = await store.get('all-questions');
                if (data) {
                    questions = JSON.parse(data);
                } else {
                    // Fallback: Show legacy data if migration hasn't happened yet
                    const legacyData = await store.get('global-recent');
                    questions = legacyData ? JSON.parse(legacyData) : [];
                }
            } else {
                // Get questions for this product
                const data = await store.get(`product-${productId}`);
                questions = data ? JSON.parse(data) : [];
            }
        } catch (storeError) {
            console.error('Warning: Failed to fetch from blob store (questions):', storeError);
            // Return empty list instead of 500 to keep page functional
            questions = [];
        }
        
        // Sort by date (newest first)
        if (questions && questions.length > 0) {
            questions.sort((a, b) => new Date(b.date) - new Date(a.date));
        }
        
        return new Response(JSON.stringify({ 
            success: true,
            questions: questions
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error) {
        console.error('Error fetching questions:', error);
        return new Response(JSON.stringify({ error: 'Failed to fetch questions' }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }
};

export const config = {
    path: '/api/get-questions'
};