import { getStore } from '@netlify/blobs';
import { verifyAuth } from './lib/auth.mjs';

export default async (req, context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    await verifyAuth(req);

    const { reviewId, productId, reviewDate } = await req.json();

    if (!reviewId && (!productId || !reviewDate)) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const store = getStore('reviews');

    // 1. Update Global Recent Reviews
    const globalData = await store.get('global-recent');
    let globalReviews = globalData ? JSON.parse(globalData) : [];
    
    const initialGlobalCount = globalReviews.length;
    
    // Filter out by reviewId or (productId + date)
    globalReviews = globalReviews.filter(r => {
        if (reviewId) return r.id !== reviewId;
        return !(r.productId === productId && r.date === reviewDate);
    });

    if (globalReviews.length !== initialGlobalCount) {
        await store.set('global-recent', JSON.stringify(globalReviews));
    }

    // 2. Update Product Specific Reviews
    if (productId) {
        const productData = await store.get(`product-${productId}`);
        if (productData) {
            let productReviews = JSON.parse(productData);
            const initialProductCount = productReviews.length;
            
            productReviews = productReviews.filter(r => {
                if (reviewId) return r.id !== reviewId;
                return r.date !== reviewDate;
            });
            
            if (productReviews.length !== initialProductCount) {
                await store.set(`product-${productId}`, JSON.stringify(productReviews));
            }
        }
    }

    return new Response(JSON.stringify({ 
      success: true,
      message: 'Review deleted successfully'
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error deleting review:', error);
    const status = error.message.includes('Unauthorized') || error.message.includes('Forbidden') ? 401 : 500;
    return new Response(JSON.stringify({ 
      error: error.message || 'Failed to delete review'
    }), {
      status: status,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

export const config = {
  path: '/api/admin/delete-review'
};