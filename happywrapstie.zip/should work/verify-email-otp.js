document.addEventListener('DOMContentLoaded', () => {
    const codeForm = document.getElementById('codeForm');
    const codeInput = document.getElementById('codeInput');
    const codeError = document.getElementById('codeError');
    const verifyBtn = document.getElementById('verifyBtn');
    const resendLink = document.getElementById('resendLink');
    const titleElement = document.querySelector('.code-title');
    const messageElement = document.querySelector('.code-message');

    // Parse URL params
    const urlParams = new URLSearchParams(window.location.search);
    const type = urlParams.get('type') || 'order';
    let email = urlParams.get('email'); // Normalized email to verify against
    
    // Fallback to sessionStorage if not in URL
    if (!email) {
        email = sessionStorage.getItem('verificationEmail');
    }

    const orderId = urlParams.get('orderId'); // For order type
    
    // UI Text Updates
    if (type === 'signup') {
        if (titleElement) titleElement.textContent = 'Verify Your Account';
        if (messageElement) messageElement.textContent = `We've sent a verification code to ${email}. Enter it below to create your account.`;
        if (verifyBtn) verifyBtn.textContent = 'Verify Account';
    } else if (type === 'password_reset') {
        if (titleElement) titleElement.textContent = 'Password Reset';
        if (messageElement) messageElement.textContent = `Enter the code sent to ${email} to reset your password.`;
        if (verifyBtn) verifyBtn.textContent = 'Verify & Reset';
    } else if (type === 'email_change') {
        if (titleElement) titleElement.textContent = 'Verify New Email';
        if (messageElement) messageElement.textContent = `We've sent a code to your new email (${email}). Verify it to update your account.`;
        if (verifyBtn) verifyBtn.textContent = 'Verify Email';
    }

    // Input Validation
    if (codeInput) {
        codeInput.addEventListener('input', () => {
            codeInput.value = codeInput.value.replace(/\D/g, '');
            if (codeInput.value.length === 6) {
                if (codeError) codeError.style.display = 'none';
                codeInput.style.borderColor = 'var(--primary)';
            }
        });
    }

    if (codeForm) {
        codeForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            if (codeInput.value.length !== 6) {
                if (codeError) {
                    codeError.style.display = 'block';
                    codeError.textContent = 'Please enter a valid 6-digit code.';
                }
                codeInput.style.borderColor = '#ef4444';
                return;
            }

            if (verifyBtn) {
                verifyBtn.disabled = true;
                verifyBtn.textContent = 'Verifying...';
            }
            if (codeError) codeError.style.display = 'none';

            let endpoint = '/api/verify-email-otp'; // Default (Order)
            let body = { email, otp: codeInput.value, orderId };

            if (type === 'signup') {
                endpoint = '/api/verify-signup-otp';
                body = { email, otp: codeInput.value };
            } else if (type === 'password_reset') {
                endpoint = '/api/verify-password-reset-otp';
                body = { email, otp: codeInput.value };
            } else if (type === 'email_change') {
                endpoint = '/api/verify-email-change-otp';
                body = { email, otp: codeInput.value };
            }

            try {
                const response = await fetch(endpoint, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(body)
                });

                const data = await response.json();

                if (response.ok && (data.verified || data.success)) {
                    // Success Handlers
                    if (type === 'signup') {
                        localStorage.setItem('verification_success', JSON.stringify({ verified: true }));
                        window.location.href = 'login.html';
                    } else if (type === 'password_reset') {
                        // Redirect to reset password page with token
                        window.location.href = `reset-password.html?token=${data.resetToken}`;
                    } else if (type === 'email_change') {
                        alert('Email changed successfully! Please login again.');
                        // Logout user and reset auth state
                        if (typeof netlifyIdentity !== 'undefined') netlifyIdentity.logout();
                        localStorage.removeItem('custom_user_data');
                        localStorage.removeItem('user_name');
                        localStorage.removeItem('google_needs_password');

                        // Update global auth state if available
                        if (typeof window.setAuthStatus === 'function') {
                            window.authInitialized = true;
                            window.setAuthStatus('unauthenticated');
                        }

                        window.location.href = 'login.html';
                    } else {
                         // Order - Auto-login user after order verification
                         if (data.user) {
                             localStorage.setItem('custom_user_data', JSON.stringify(data.user));
                             const fullName = data.user.firstName + (data.user.lastName ? ' ' + data.user.lastName : '');
                             localStorage.setItem('user_name', fullName);

                             // Update global auth state if available
                             if (typeof window.setAuthStatus === 'function') {
                                 window.authInitialized = true;
                                 window.setAuthStatus('authenticated');
                             }
                         }
                         sessionStorage.removeItem('verificationEmail');
                         
                         // Check for payment method and redirect accordingly
                         let orderData = {};
                         try {
                             const storedData = sessionStorage.getItem('verificationOrderData');
                             if (storedData) {
                                 orderData = JSON.parse(storedData);
                             }
                         } catch (e) {
                             console.error('Error parsing order data', e);
                         }

                         if (orderData.paymentMethod === 'jazzcash') {
                              const totalFormatted = encodeURIComponent(formatPrice(orderData.total || 0));
                              window.location.href = `jazz-cash.html?orderId=${orderId}&total=${totalFormatted}`;
                         } else {
                              window.location.href = `order-confirm.html?orderId=${orderId}&source=otp`;
                         }
                    }
                } else {
                    throw new Error(data.error || 'Invalid verification code');
                }
            } catch (error) {
                console.error('Verification error:', error);
                if (codeError) {
                    codeError.textContent = error.message || 'Verification failed. Please try again.';
                    codeError.style.display = 'block';
                }
                if (codeInput) codeInput.style.borderColor = '#ef4444';
                if (verifyBtn) {
                    verifyBtn.disabled = false;
                    verifyBtn.textContent = 'Verify';
                }
            }
        });
    }

    if (resendLink) {
        resendLink.addEventListener('click', async (e) => {
            e.preventDefault();
            
            if (!email) {
                alert('Missing information to resend code.');
                return;
            }
            
            if (confirm('Resend verification code?')) {
                 try {
                     const response = await fetch('/api/generate-email-otp', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            email: email,
                            type: type,
                            orderId: orderId, // Only if type is order
                            // Need to pass other params? 
                            // generate-email-otp needs names etc for signup.
                            // But for resend, data is already in pending store?
                            // generate-email-otp RE-WRITES pending store? 
                            // Yes.
                            // So we need to pass data again or update generate to not overwrite if exists?
                            // Or just accept that Resend might need data. 
                            // Use sessionStorage to store temp data?
                        })
                    });
                    
                    // Note: If generate-email-otp requires payload (signup data) and we don't send it, it might fail or overwrite with null.
                    // For signup, we should probably check if we can handle resend gracefully without re-submitting data.
                    // Ideally, we shouldn't overwrite pending data if it exists, only update OTP.
                    // But generate-email-otp overwrites.
                    // Simple fix: Alert user to go back and retry if simple resend fails, 
                    // OR we assume user won't resend too often.
                    
                    if (response.ok) {
                        alert('A new code has been sent to your email.');
                    } else {
                        // If it failed (e.g. missing signup data), tell user to restart
                        alert('Unable to resend code. Please try starting the process again.');
                    }
                 } catch(err) {
                     console.error(err);
                     alert('Error resending code.');
                 }
            }
        });
    }
});