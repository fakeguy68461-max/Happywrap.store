document.addEventListener('DOMContentLoaded', () => {
    const codeForm = document.getElementById('codeForm');
    const codeInput = document.getElementById('codeInput');
    const codeError = document.getElementById('codeError');
    const verifyBtn = document.getElementById('verifyBtn');
    const resendLink = document.getElementById('resendLink');

    if (codeInput) {
        codeInput.addEventListener('input', () => {
            codeInput.value = codeInput.value.replace(/\D/g, '');
            if (codeInput.value.length === 6) {
                if (codeError) codeError.style.display = 'none';
                codeInput.style.borderColor = 'var(--primary)';
            }
        });
    }

    if (codeForm) {
        codeForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            if (codeInput.value.length !== 6) {
                if (codeError) codeError.style.display = 'block';
                codeInput.style.borderColor = '#ef4444';
                return;
            }

            if (verifyBtn) {
                verifyBtn.disabled = true;
                verifyBtn.textContent = 'Verifying...';
            }
            if (codeError) codeError.style.display = 'none';

            const urlParams = new URLSearchParams(window.location.search);
            const orderId = urlParams.get('orderId');
            const phone = sessionStorage.getItem('verificationPhone');

            if (!phone || !orderId) {
                if (codeError) {
                    codeError.textContent = 'Missing order information. Please start over.';
                    codeError.style.display = 'block';
                }
                if (verifyBtn) {
                    verifyBtn.disabled = false;
                    verifyBtn.textContent = 'Verify Order';
                }
                return;
            }

            try {
                const response = await fetch('/api/verify-otp', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        phone: phone,
                        otp: codeInput.value,
                        orderId: orderId
                    })
                });

                const data = await response.json();

                if (response.ok && data.verified) {
                    if (data.user) {
                         localStorage.setItem('custom_user_data', JSON.stringify(data.user));
                         const fullName = data.user.firstName + (data.user.lastName ? ' ' + data.user.lastName : '');
                         localStorage.setItem('user_name', fullName);
                    }
                    // Clear phone from session storage
                    sessionStorage.removeItem('verificationPhone');
                    
                    // Check for payment method and redirect accordingly
                    let orderData = {};
                    try {
                        const storedData = sessionStorage.getItem('verificationOrderData');
                        if (storedData) {
                            orderData = JSON.parse(storedData);
                        }
                    } catch (e) {
                        console.error('Error parsing order data', e);
                    }

                    if (orderData.paymentMethod === 'jazzcash') {
                         const totalFormatted = encodeURIComponent(formatPrice(orderData.total || 0));
                         window.location.href = `jazz-cash.html?orderId=${orderId}&total=${totalFormatted}`;
                    } else {
                         window.location.href = `order-confirm.html?orderId=${orderId}&source=otp`;
                    }
                } else {
                    throw new Error(data.error || 'Invalid verification code');
                }
            } catch (error) {
                console.error('Verification error:', error);
                if (codeError) {
                    codeError.textContent = error.message || 'Verification failed. Please try again.';
                    codeError.style.display = 'block';
                }
                if (codeInput) codeInput.style.borderColor = '#ef4444';
                if (verifyBtn) {
                    verifyBtn.disabled = false;
                    verifyBtn.textContent = 'Verify Order';
                }
            }
        });
    }

    if (resendLink) {
        resendLink.addEventListener('click', async (e) => {
            e.preventDefault();
            
            const urlParams = new URLSearchParams(window.location.search);
            const orderId = urlParams.get('orderId');
            const phone = sessionStorage.getItem('verificationPhone');
            
            if (!orderId || !phone) {
                alert('Missing order info. Please restart checkout.');
                return;
            }
            
            const originalText = resendLink.textContent;
            resendLink.textContent = 'Sending...';
            resendLink.style.pointerEvents = 'none'; // Disable click
            
            try {
                const response = await fetch('/api/generate-otp', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        phone: phone,
                        orderId: orderId
                    })
                });
                
                const data = await response.json();
                
                if (response.ok && data.success) {
                    alert('A new code has been sent to your WhatsApp number.');
                } else {
                    throw new Error(data.error || 'Failed to resend code');
                }
            } catch (err) {
                console.error('Resend error:', err);
                alert('Error resending code: ' + err.message);
            } finally {
                resendLink.textContent = originalText;
                resendLink.style.pointerEvents = 'auto';
            }
        });
    }
});
