# Email Templates

This directory contains professionally designed email templates for HappyWrap. All templates are mobile-responsive and use inline CSS for maximum email client compatibility.

## Available Templates

### 1. Order Confirmation Email (`order-confirmation.js`)
Sent when a customer places an order and needs to confirm it via email.

**Variables:**
- `CUSTOMER_NAME` - Customer's full name
- `ORDER_NUMBER` - Unique order identifier
- `ORDER_DATE` - Formatted order date
- `ORDER_ITEMS` - HTML formatted list of ordered items
- `SUBTOTAL` - Order subtotal (formatted with 2 decimals)
- `SHIPPING` - Shipping cost (formatted with 2 decimals)
- `TAX` - Tax amount (formatted with 2 decimals)
- `TOTAL` - Total order amount (formatted with 2 decimals)
- `SHIPPING_ADDRESS` - Full shipping address (multi-line)
- `CONFIRMATION_LINK` - URL for order confirmation

**Usage:**
```javascript
import { orderConfirmationTemplate, formatOrderItems } from './email-templates/index.js';

const emailBody = orderConfirmationTemplate({
  CUSTOMER_NAME: 'John Doe',
  ORDER_NUMBER: '12345',
  ORDER_DATE: 'January 1, 2025',
  ORDER_ITEMS: formatOrderItems(items),
  SUBTOTAL: '99.99',
  SHIPPING: '5.99',
  TAX: '9.99',
  TOTAL: '115.97',
  SHIPPING_ADDRESS: 'John Doe\n123 Main St\nNew York, USA\n10001',
  CONFIRMATION_LINK: 'https://example.com/confirm?token=abc123'
});
```

### 2. Password Reset Email (`password-reset.js`)
Sent when a user requests to reset their password.

**Variables:**
- `USER_NAME` - User's display name
- `RESET_LINK` - Secure password reset URL
- `EXPIRATION_TIME` - How long the link is valid (default: '1 hour')

**Usage:**
```javascript
import { passwordResetTemplate } from './email-templates/index.js';

const emailBody = passwordResetTemplate({
  USER_NAME: 'John Doe',
  RESET_LINK: 'https://example.com/reset-password?token=abc123',
  EXPIRATION_TIME: '1 hour'
});
```

**Integration with Netlify Identity:**
To use this template with Netlify Identity, configure your site's Identity settings to use a custom password reset email template. You can do this by:
1. Going to Site Settings > Identity > Emails in the Netlify dashboard
2. Customizing the password recovery email template
3. Using the variables provided by Netlify Identity

### 3. Signup Welcome Email (`signup-welcome.js`)
Sent to new users after they create an account.

**Variables:**
- `USER_NAME` - New user's display name
- `USER_EMAIL` - User's email address
- `VERIFY_EMAIL_LINK` - Email verification URL (optional)
- `ACCOUNT_DASHBOARD_LINK` - Link to account page (default: '/account.html')
- `SHOP_LINK` - Link to shop page (default: '/shop.html')

**Usage:**
```javascript
import { signupWelcomeTemplate } from './email-templates/index.js';

const emailBody = signupWelcomeTemplate({
  USER_NAME: 'John Doe',
  USER_EMAIL: 'john@example.com',
  VERIFY_EMAIL_LINK: 'https://example.com/verify?token=abc123',
  ACCOUNT_DASHBOARD_LINK: 'https://example.com/account.html',
  SHOP_LINK: 'https://example.com/shop.html'
});
```

**Integration with Netlify Identity:**
To send this welcome email when users sign up:
1. Create a serverless function that listens for identity-signup events
2. Use the Netlify Identity webhook to trigger the function
3. Send the welcome email using the template

### 4. Post-Confirmation Email (`index.js` - `postConfirmationTemplate`)
Sent after a customer confirms their order.

**Variables:**
- `CUSTOMER_NAME` - Customer's full name
- `ORDER_NUMBER` - Order identifier
- `ORDER_DATE` - Formatted date
- `ORDER_ITEMS` - HTML formatted list of items
- `TOTAL` - Total amount (formatted with 2 decimals)
- `SHIPPING_ADDRESS` - Full shipping address
- `ESTIMATED_DELIVERY` - Delivery timeframe (e.g., '3-5 business days')
- `TRACKING_LINK` - Tracking URL (optional)

## Helper Functions

### `formatOrderItems(items)`
Formats an array of order items into HTML for email display.

**Parameters:**
- `items` - Array of objects with `name`, `quantity`, and `price` properties

**Returns:** HTML string

### `renderTemplate(templateFunction, variables)`
Safely renders a template with error handling.

**Parameters:**
- `templateFunction` - The template function to render
- `variables` - Object containing template variables

**Returns:** Rendered HTML string

### `createEmailPayload(to, subject, htmlBody, fromEmail, fromName)`
Creates a standardized email payload object.

## Email Service Configuration

These templates work with your configured email service (SendGrid or AWS SES). Make sure you have the following environment variables set:

**For SendGrid:**
- `SENDGRID_API_KEY` - Your SendGrid API key
- `FROM_EMAIL` - Verified sender email address

**For AWS SES:**
- `AWS_SES_REGION` - AWS region (e.g., us-east-1)
- `AWS_ACCESS_KEY_ID` - AWS access key
- `AWS_SECRET_ACCESS_KEY` - AWS secret key
- `FROM_EMAIL` - Verified sender email address

## Template Features

All templates include:
- ✅ Mobile-responsive design
- ✅ Inline CSS for email client compatibility
- ✅ Professional HappyWrap branding
- ✅ Clear call-to-action buttons
- ✅ Security notices where appropriate
- ✅ Support contact information
- ✅ Consistent styling and layout

## Customization

To customize the templates:
1. Edit the template files directly
2. Maintain the variable placeholders (e.g., `${CUSTOMER_NAME}`)
3. Use inline styles for all CSS
4. Test emails across different email clients
5. Keep the HappyWrap branding consistent

## Testing

When testing templates locally without an email service configured:
- The system will log email content to the console
- Confirmation links will be displayed in logs
- No actual emails will be sent

## Support

For issues or questions about the email templates, contact the development team or refer to the email service provider documentation.
