
exports.handler = async (event, context) => {
    // Only allow POST requests
    if (event.httpMethod !== 'POST') {
        return {
            statusCode: 405,
            body: JSON.stringify({ error: 'Method Not Allowed' })
        };
    }

    try {
        const data = JSON.parse(event.body);
        
        // Log the submission
        console.log('Form submission received:', data);
        
        // In production, you would send an email here using a service like SendGrid
        // Example with SendGrid:
        // const sgMail = require('@sendgrid/mail');
        // sgMail.setApiKey(process.env.SENDGRID_API_KEY);
        // await sgMail.send({
        //     to: 'your-email@example.com',
        //     from: 'noreply@happywrap.com',
        //     subject: 'New Form Submission',
        //     text: JSON.stringify(data, null, 2)
        // });
        
        return {
            statusCode: 200,
            body: JSON.stringify({ 
                success: true, 
                message: 'Form submitted successfully' 
            })
        };
    } catch (error) {
        console.error('Error processing form:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ 
                error: 'Failed to process form submission' 
            })
        };
    }
};