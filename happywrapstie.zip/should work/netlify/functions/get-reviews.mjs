import { getStore } from '@netlify/blobs';

export default async (req, context) => {
    if (req.method !== 'GET') {
        return new Response(JSON.stringify({ error: 'Method Not Allowed' }), {
            status: 405,
            headers: { 'Content-Type': 'application/json' }
        });
    }

    try {
        const url = new URL(req.url);
        const productId = url.searchParams.get('productId');
        
        const store = getStore('reviews');
        
        let reviews = [];
        
        if (!productId) {
            // Get global recent reviews
            const data = await store.get('global-recent');
            reviews = data ? JSON.parse(data) : [];
        } else {
            // Get reviews for this product
            const data = await store.get(`product-${productId}`);
            reviews = data ? JSON.parse(data) : [];
        }
        
        // Sort by date (newest first)
        if (reviews && reviews.length > 0) {
            reviews.sort((a, b) => new Date(b.date) - new Date(a.date));
        }
        
        return new Response(JSON.stringify({ 
            success: true,
            reviews: reviews
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error) {
        console.error('Error fetching reviews:', error);
        return new Response(JSON.stringify({ error: 'Failed to fetch reviews' }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }
};

export const config = {
    path: '/api/get-reviews'
};
